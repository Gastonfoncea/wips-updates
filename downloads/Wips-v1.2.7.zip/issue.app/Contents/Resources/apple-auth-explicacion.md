# Auth explicado desde cero

## Imaginate un bar

Tu app es un bar. Adentro hay una barra (OpenAI) que sirve tragos que vos pagas. Necesitas controlar quien entra.

**Antes:** le dabas a todos la misma llave. Si alguien la copiaba, entraba gratis. No podias saber quien era ni echarlos sin cambiarle la llave a todos.

**Ahora:** hay un bouncer (el proxy). Cada persona muestra su DNI (Apple ID), el bouncer le da una pulsera temporal (JWT) que dura 1 hora. Si alguien hace quilombo, le sacas la pulsera solo a esa persona.

---

## Los actores

```
┌──────────┐      ┌──────────┐      ┌──────────┐      ┌──────────┐
│   Apple   │      │  Tu App  │      │  Proxy   │      │  OpenAI  │
│ (el DNI)  │      │ (el user)│      │(bouncer) │      │ (la API) │
└──────────┘      └──────────┘      └──────────┘      └──────────┘
```

- **Apple** = la entidad que verifica identidad. Todos los usuarios de Mac/iPhone ya tienen un Apple ID.
- **Tu App** = Wips, corriendo en la Mac del usuario.
- **Proxy** = tu servidor en Vercel. Es el unico que tiene la API key de OpenAI.
- **OpenAI** = la API que clasifica, chatea, genera summaries.
- **Redis** = la memoria del bouncer (ya lo explico).

---

## Paso a paso

### 1. Login (una sola vez)

```
Usuario presiona "Sign In with Apple"
        │
        ▼
    ┌────────┐    "che Apple, soy yo"     ┌────────┐
    │  App   │ ──────────────────────────▶ │ Apple  │
    │        │ ◀────────────────────────── │        │
    └────────┘   "si, es el, toma este     └────────┘
                  identity token firmado"
        │
        │  manda el identity token al proxy
        ▼
    ┌────────┐   "Apple dice que es real"  ┌────────┐
    │  App   │ ──────────────────────────▶ │ Proxy  │
    │        │ ◀────────────────────────── │        │
    └────────┘   "ok, toma tu JWT (1h)     └────────┘
                  y tu refresh token (30d)"
```

El **identity token** es un papelito firmado por Apple que dice "este es el usuario X, y es posta". El proxy verifica esa firma contra las claves publicas de Apple (nadie puede falsificarlo).

### 2. Usar la app (cada request)

```
    ┌────────┐   request + JWT             ┌────────┐        ┌────────┐
    │  App   │ ──────────────────────────▶ │ Proxy  │──────▶ │ OpenAI │
    │        │ ◀────────────────────────── │        │◀────── │        │
    └────────┘   respuesta                 └────────┘        └────────┘
```

Cada vez que la app clasifica una entry, chatea, o pide un summary, manda el JWT en el header. El proxy verifica que el JWT sea valido y no este expirado, y recien ahi le pasa el request a OpenAI con la API key real.

### 3. El JWT expira (cada 1 hora)

```
    ┌────────┐  request + JWT viejo        ┌────────┐
    │  App   │ ──────────────────────────▶ │ Proxy  │
    │        │ ◀────────────────────────── │        │
    └────────┘   "401 - no autorizado"     └────────┘
        │
        │  manda el refresh token
        ▼
    ┌────────┐  "dame uno nuevo"           ┌────────┐
    │  App   │ ──────────────────────────▶ │ Proxy  │
    │        │ ◀────────────────────────── │        │
    └────────┘  "ok, JWT nuevo + refresh   └────────┘
                 token nuevo"
```

Esto pasa automaticamente. El usuario no se entera. `APIKeyProvider.executeRequest()` detecta el 401, refresca, y reintenta.

### 4. Revocacion (si alguien abusa o borra su cuenta)

```
    ┌────────┐  "el usuario X revoco"      ┌────────┐
    │ Apple  │ ──────────────────────────▶ │ Proxy  │ ──▶ borra sesiones de Redis
    └────────┘   webhook POST              └────────┘
```

---

## Que es el JWT?

Un JWT (JSON Web Token) es un string que tiene 3 partes separadas por puntos:

```
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIwMDEyMzQiLCJ0eXBlIjoiYWNjZXNzIn0.firma
│                      │                                                │
│  HEADER              │  PAYLOAD                                       │ FIRMA
│  (algoritmo)         │  (datos: quien es, cuando expira)              │
```

- **Payload**: dice "este es el usuario 001234, tipo access, expira en 1h"
- **Firma**: esta firmada con un secreto que solo tu proxy conoce (`PROXY_JWT_SECRET`). Si alguien cambia el payload, la firma no matchea y el proxy lo rechaza.

Nadie puede fabricar un JWT valido sin conocer el secreto. Y el secreto solo esta en Vercel, nunca en la app.

---

## Donde entra Redis?

Redis es una base de datos ultrarapida que vive en la nube (usas Upstash). Es **la memoria del bouncer**. Guarda 3 cosas:

| Que guarda | Key en Redis | Para que |
|---|---|---|
| Datos del usuario | `user:apple_id_123` | Saber quien es (email, nombre, cuando se registro) |
| Refresh tokens | `refresh:abc123...` | Validar que el refresh token es real y de quien es |
| Rate limiting | `rate:user:apple_id_123` | Contar cuantos requests hizo en la ultima ventana de tiempo |

**Por que no una base de datos normal?** Porque esto es serverless (Vercel). No hay un servidor corriendo 24/7. Cada request es una funcion que se prende, ejecuta, y se apaga. Redis persiste los datos entre esas ejecuciones, y es lo suficientemente rapido para no agregar latencia.

**Por que no guardar todo en el JWT?** El JWT es stateless — el proxy no necesita consultar nada para validarlo (solo verifica la firma). Pero el refresh token si necesita estado: tenes que saber si fue usado, si fue revocado, de quien es. Eso vive en Redis.

---

## Resumen de cada pieza

| Pieza | Que es | Donde vive | Duracion |
|---|---|---|---|
| Apple ID | La identidad del usuario | Apple | Permanente |
| Identity token | Prueba de que Apple verifico al usuario | Se usa una vez en login | Minutos |
| Access token (JWT) | Pulsera para hacer requests | En memoria de la app | 1 hora |
| Refresh token | Ticket para pedir una pulsera nueva | Keychain de la app + Redis | 30 dias |
| `PROXY_JWT_SECRET` | El secreto para firmar JWTs | Vercel env vars | Permanente |
| Datos de sesion | Quien esta logueado, rate limits | Redis (Upstash) | Segun TTL |
