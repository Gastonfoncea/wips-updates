# GitActivityService

Servicio que lee commits recientes de un repositorio git vinculado a un proyecto.

## Que hace

Lee el historial de commits de un repo usando el comando `git log`. No guarda nada — cada vez que se lo llama, consulta git directamente.

## Como funciona git log

Cada repositorio git tiene una carpeta oculta `.git/` en su raiz. Ahi adentro git guarda TODO el historial del proyecto: cada commit, cada branch, cada cambio. Es como una base de datos interna.

Cuando ejecutamos `git log`, no estamos leyendo archivos nosotros. Le pedimos al programa `git` (que vive en `/usr/bin/git`) que consulte su base de datos y nos devuelva la info.

Le decimos:

```bash
/usr/bin/git log --format=%h|%aI|%aN|%s --since=7.days --no-merges -50
```

Que significa cada flag:

| Flag | Que hace |
|---|---|
| `--format=%h\|%aI\|%aN\|%s` | Formato de salida: hash corto, fecha ISO, autor, mensaje. Separados por `\|` |
| `--since=7.days` | Solo commits de los ultimos 7 dias |
| `--no-merges` | Excluye merge commits (son ruido, no representan trabajo real) |
| `-50` | Maximo 50 resultados |

Ejemplo de salida:

```
a1b2c3d|2026-03-20T14:30:00-03:00|Gaston|fix auth flow
e4f5g6h|2026-03-19T10:15:00-03:00|Gaston|add sidebar toggle
i7j8k9l|2026-03-18T09:00:00-03:00|Gaston|update tests
```

El servicio parsea cada linea, la separa por `|`, y arma un struct `GitCommit` con hash, fecha, autor y mensaje.

## Por que no guardamos los commits en un JSON

Porque git ya ES la base de datos. Los commits son permanentes — no se borran solos. Cada vez que necesitamos la info, le preguntamos a git y nos la da fresca. Guardar una copia seria duplicar datos sin razon.

Esto es diferente a las sesiones de Claude Code que teniamos antes: esos archivos JSONL eran temporales y podian desaparecer o cambiar de formato.

## Que es sandbox

macOS tiene un sistema de seguridad llamado **sandbox** (caja de arena). Cuando una app se distribuye por la App Store, corre dentro de una sandbox: solo puede acceder a sus propios archivos y a nada mas del sistema.

Imaginate que la app vive en una burbuja. Dentro de la burbuja tiene sus carpetas, sus datos, sus configuraciones. Pero NO puede ver el escritorio del usuario, ni sus documentos, ni otros repos en su disco. Esta aislada.

```
┌─────────────── macOS ───────────────────┐
│                                         │
│  ┌──── Sandbox de Wips ────┐            │
│  │                         │            │
│  │  ~/Library/             │            │
│  │    Application Support/ │            │
│  │      Wips/              │            │
│  │        projects.json    │  Escritorio│
│  │        entries.json     │  Documentos│
│  │                         │  Repos     │
│  │  (solo esto puede ver)  │  (NO)      │
│  └─────────────────────────┘            │
│                                         │
└─────────────────────────────────────────┘
```

Esto es bueno para el usuario: una app maliciosa no podria leer tus archivos privados. Pero para nosotros es un problema: necesitamos acceder al repo git del usuario, que esta FUERA de nuestra sandbox.

## Que es un bookmark

Un **bookmark** es un permiso persistente que el usuario nos da para acceder a una carpeta fuera de la sandbox.

El flujo es asi:

### 1. El usuario vincula un repo (una sola vez)

Cuando el usuario clickea "vincular repo", macOS le muestra un dialogo del sistema (NSOpenPanel) para elegir la carpeta. Al elegirla, el usuario esta diciendo "le doy permiso a esta app para acceder aca".

### 2. Creamos un bookmark

Tomamos ese permiso y lo convertimos en un **security-scoped bookmark**: un blob de datos (tipo `Data`) que representa "tengo permiso para acceder a esta carpeta". Lo guardamos en `Project.repoBookmark`.

### 3. En cada uso, resolvemos el bookmark

Cada vez que la app necesita acceder al repo (al abrir la app, al leer commits), hace esto:

```
1. Toma el bookmark guardado (Data)
2. Lo resuelve: convierte el Data en una URL real del filesystem
3. Llama a url.startAccessingSecurityScopedResource()
   → macOS verifica el permiso y abre la puerta
4. Ahora puede leer/escribir en esa carpeta
```

Si el bookmark esta "stale" (la carpeta se movio o algo cambio), intentamos recrearlo. Si falla, no accedemos y seguimos sin error.

### Por que no pedimos permiso cada vez?

Porque seria horrible para el usuario. Imaginate que cada vez que abris la app te salte un dialogo "Selecciona tu repo". Los bookmarks son la forma de pedir permiso UNA vez y recordarlo para siempre.

## Donde vive en el codigo

```
issue/
├── Core/
│   ├── Services/
│   │   └── GitActivity/
│   │       └── GitActivityService.swift    ← el servicio
│   └── Config/
│       └── AppConfig.swift                 ← constantes (GitActivity enum)
├── App/
│   └── AppState.swift                      ← donde se crea (DI container)
```

## Configuracion

Definida en `AppConfig.GitActivity`:

| Constante | Valor | Que controla |
|---|---|---|
| `defaultDays` | 7 | Cuantos dias atras buscar commits |
| `maxCommits` | 50 | Maximo de commits por consulta |
| `processTimeout` | 10s | Tiempo limite para que git responda |

## API publica

```swift
// Obtener commits recientes de un proyecto
let commits = await gitActivityService.recentCommits(for: proyecto)

// Con dias custom
let commits = await gitActivityService.recentCommits(for: proyecto, days: 14)
```

Retorna `[GitCommit]` — array vacio si algo falla (nunca crashea).

## Manejo de errores

El servicio NUNCA tira errores al usuario. Si algo falla (no hay repo, bookmark roto, git no responde), loguea via OSLog y retorna un array vacio. El ViewModel que lo consuma puede decidir si mostrar algo o simplemente no mostrar la seccion.

## Estado actual

- Servicio creado y compilando
- Instanciado en AppState
- NO conectado a ningun ViewModel todavia
- Pendiente: definir UI y decidir donde mostrar los commits
