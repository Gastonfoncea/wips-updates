# Spec: Rediseno del InputView - Barra tipo Spotlight

## Problema

El panel de input actual (Cmd+I) es un dialogo vertical tipo formulario de 420x360px que se siente pesado para una tarea simple: escribir texto y enviarlo. Tiene un picker segmentado "Issue / Pregunta" que agrega friccion sin valor real (la clasificacion automatica por IA ya resuelve esto), y no ofrece una forma clara de elegir a que proyecto va la entry. El usuario quiere capturar pensamientos rapidamente -- la interfaz actual lo frena en vez de ayudarlo.

## Contexto Tecnico

### Archivos clave

- **`InputPanelController.swift`** (`/issue/Services/`): Controlador del `NSPanel` flotante. Contiene `InputPanelView` como struct privada con el layout actual (header, picker segmentado, text editor, preview de imagenes, barra de acciones). Focus automatico via `findTextView(in:)` con delay de 0.15s. El panel usa `styleMask: [.titled, .closable, .fullSizeContentView]`, `isFloatingPanel`, `titlebarAppearsTransparent`. Dimensiones fijas: 420x360.

- **`InputViewModel.swift`** (`/issue/Features/Home/ViewModels/`): ViewModel con `inputText`, `inputMode` (enum `InputMode: .issue | .question`), `pendingImages`, `submitEntry()`. El `submitEntry()` chequea `inputMode`: si es `.question`, fuerza clasificacion a `.tarea/.question` sin IA; si es `.issue`, clasifica con IA. Usa `selectedProject` (de `sidebarVM.selectedProject`) para determinar el proyecto destino.

- **`EntryStore.swift`** (`/issue/Services/`): Persistencia basada en proyecto. `add(_:)` agrega al array en memoria y guarda al `currentProjectID`. **Punto critico**: si el usuario elige en el input panel un proyecto diferente al cargado en el sidebar, `add()` guardaria en el proyecto equivocado. Se necesita un metodo que persista directamente en el archivo JSON del proyecto destino.

- **`ProjectStore.swift`** (`/issue/Services/`): `projects: [Project]` con `.all` (virtual, no se persiste), `.general` (default), y proyectos del usuario.

- **`SidebarViewModel.swift`** (`/issue/Features/Home/ViewModels/`): `selectedProject: Project` es `@Published`. El `InputViewModel` tiene referencia al sidebarVM.

- **`AppTheme.swift`** (`/issue/Shared/Extensions/`): Tokens semanticos: `background`, `cardBackground`, `inputBackground`, `textPrimary`, `textSecondary`, `textMuted`, `borderDefault`, `borderFocused`, `hoverOverlay`, `selectedOverlay`, `shadowColor`. Tiene `ThemedView` modifier y `LinearButtonStyle`.

- **`ProjectTabsView.swift`** (`/issue/Shared/Components/`): Componente existente de tabs horizontales scrollables para proyectos con estilo selected/unselected. Patron visual a reutilizar como referencia.

- **`issueApp.swift`** (`/issue/App/`): `AppDelegate` crea `InputPanelController` y lo conecta al shortcut Cmd+I. Dos modos: shortcut global (`hideMainWindow: true`) y notificacion `.openInputView` (`hideMainWindow: false`).

### Dependencias de InputMode

El enum `InputMode` y la propiedad `inputMode` solo se usan en dos archivos: `InputPanelController.swift` (picker en la vista) e `InputViewModel.swift` (logica condicional en `submitEntry()`). Eliminacion limpia, sin impacto externo.

## Historias de Usuario

1. **Como** usuario que captura ideas frecuentemente, **quiero** un input centrado en pantalla tipo barra de busqueda que aparezca con Cmd+I y acepte foco inmediato, **para** escribir y enviar mi pensamiento en menos de 3 segundos.

2. **Como** usuario con multiples proyectos, **quiero** ver mis proyectos como chips arriba del campo de texto con el proyecto actual preseleccionado, **para** cambiar el destino de la entry con un click sin pasos adicionales.

3. **Como** usuario, **quiero** que el input sea texto plano sin opciones de modo (Issue/Pregunta), **para** simplificar la captura y dejar que la IA clasifique automaticamente.

## Criterios de Aceptacion

### CA-1: Layout tipo barra centrada (Spotlight/Raycast)

- **Given** el usuario presiona Cmd+I o se dispara `.openInputView`
- **When** el panel aparece
- **Then** se muestra como una barra horizontal centrada en pantalla con ancho de ~600px y altura dinamica (~160-200px base, expandible si hay imagenes)
- **Then** el fondo del panel tiene efecto de material difuminado (vibrancy) usando `NSVisualEffectView`
- **Then** los bordes son redondeados (~16px cornerRadius)
- **Then** el panel se posiciona verticalmente en el tercio superior de la pantalla (como Spotlight, no centrado exacto)

### CA-2: Foco automatico inmediato

- **Given** el panel se acaba de abrir
- **When** aparece visible en pantalla
- **Then** el campo de texto tiene foco automatico y el usuario puede escribir inmediatamente sin hacer click
- **Then** el cursor parpadea en el campo de texto

### CA-3: Selector de proyectos como chips horizontales

- **Given** el panel esta abierto
- **When** el usuario mira la zona superior (arriba del campo de texto)
- **Then** ve una fila horizontal scrollable de chips con los proyectos
- **Then** el proyecto seleccionado en el sidebar aparece preseleccionado (chip activo: fondo `selectedOverlay`, texto `textPrimary`, font `.semibold`)
- **Then** los chips inactivos usan fondo transparente, texto `textSecondary`, font `.regular`
- **Then** el proyecto "Todos" (.all) NO aparece en los chips
- **Then** si el proyecto del sidebar es "Todos", se preselecciona "General" como fallback

### CA-4: Cambio de proyecto destino

- **Given** el panel esta abierto con un proyecto preseleccionado
- **When** el usuario hace click en otro chip de proyecto
- **Then** ese proyecto se marca como seleccionado visualmente
- **Then** la entry se enviara a ese proyecto al hacer submit
- **Then** este cambio NO afecta la seleccion del sidebar en la ventana principal

### CA-5: Campo de texto plano sin picker de modo

- **Given** el panel esta abierto
- **When** el usuario mira la zona central
- **Then** ve un campo de texto unico (placeholder: "Que estas pensando?") sin picker, sin segmented control, sin selector de tipo
- **Then** el campo usa `textPrimary` para texto escrito, `textMuted` para placeholder
- **Then** el campo usa `inputBackground` como fondo
- **Then** NO existe el enum `InputMode` ni el picker "Issue / Pregunta"

### CA-6: Enviar con Enter, cerrar con Escape

- **Given** el usuario escribio texto en el campo
- **When** presiona Enter (Return)
- **Then** la entry se envia siempre via clasificacion IA (nunca fuerza tipo manualmente)
- **Then** la entry se persiste en el proyecto seleccionado en los chips (no necesariamente el del sidebar)
- **Then** el panel se cierra automaticamente y el campo se limpia
- **When** presiona Escape (sin texto o con texto)
- **Then** el panel se cierra sin enviar, descartando el texto

### CA-7: Boton de envio y accion de adjuntar

- **Given** el panel esta abierto
- **When** el usuario mira la zona de acciones (extremo derecho del campo o debajo)
- **Then** ve un boton de envio compacto (icono flecha o texto "Agregar") deshabilitado cuando no hay texto
- **Then** ve un icono de paperclip para adjuntar imagenes via file importer
- **Then** los estilos siguen el design system (`LinearButtonStyle` o tokens del theme)

### CA-8: Soporte de imagenes adjuntas

- **Given** el panel esta abierto
- **When** el usuario arrastra una imagen sobre el panel o selecciona via file picker
- **Then** la imagen se agrega a `pendingImages`
- **Then** los thumbnails aparecen debajo del campo de texto en fila horizontal compacta
- **Then** cada thumbnail tiene boton de remover (X)
- **Then** la altura del panel crece para acomodar los thumbnails

### CA-9: Cerrar al hacer click fuera

- **Given** el panel esta abierto
- **When** el usuario hace click fuera del panel
- **Then** el panel se cierra sin enviar
- **Then** se restaura la ventana principal si estaba oculta (mismo flujo que `close()` actual)

## Casos Borde

- **0 proyectos (solo "General")**: Se muestra solo el chip "General" preseleccionado. Sin scroll.
- **15+ proyectos**: Fila de chips scrollable horizontalmente con `ScrollView(.horizontal, showsIndicators: false)`.
- **Proyecto del sidebar es "Todos" (.all)**: Se preselecciona "General" como fallback ya que no se puede crear una entry "en todos".
- **Texto multilinea (pegar)**: El campo acepta multilinea (usar `TextEditor` o `TextField(axis: .vertical)`). La altura crece hasta un maximo razonable.
- **Entry enviada a proyecto diferente al cargado en el sidebar**: La entry debe persistirse en el JSON del proyecto destino sin corromper el estado del feed actual. Se necesita un metodo en `EntryStore` que escriba directamente al archivo del proyecto destino (ver Notas de Implementacion).
- **Panel abierto desde shortcut global (app en background)**: `NSApplication.shared.activate` trae el panel al frente, ventana principal se oculta. Al cerrar se restaura. Mismo flujo actual.
- **Sin API key de OpenAI**: El clasificador devuelve un default. No es responsabilidad del input panel manejar esto.
- **Enter vs Shift+Enter para multilinea**: Si se usa `TextEditor`, Enter envia y Shift+Enter (o Opt+Enter) agrega nueva linea. Si se usa `TextField(axis: .vertical)`, `.onSubmit` captura Enter naturalmente.

## Fuera de Alcance

- No incluye creacion de proyectos desde el panel de input. Si necesita un proyecto nuevo, lo crea desde el sidebar.
- No incluye vista previa de clasificacion IA antes de enviar.
- No incluye historial de entries recientes en el panel.
- No incluye navegacion por teclado entre chips de proyecto (Tab/flechas). Iteracion futura.
- No incluye animaciones de entrada/salida del panel (fade, slide). El implementador puede agregar algo sutil si quiere, pero no es requerimiento.

## Notas de Implementacion

### Archivos a modificar

1. **`InputPanelController.swift`** (`/issue/Services/`):
   - Reemplazar `InputPanelView` completamente con el nuevo layout horizontal.
   - Cambiar dimensiones del `NSPanel`: ancho ~600px, alto dinamico ~180px base.
   - Posicion vertical: en vez de `panel.center()`, calcular Y para ubicar el panel en el tercio superior de la pantalla (`screenFrame.midY + screenFrame.height * 0.15` aprox).
   - Para vibrancy: crear un `NSVisualEffectView` con material `.hudWindow` (o `.popover`) y state `.active` como `contentView` del panel, y agregar el `NSHostingView` como subview de este.
   - Para cerrar al click fuera: usar `panel.hidesOnDeactivate = true` o agregar un monitor de eventos con `NSEvent.addLocalMonitorForEvents(matching: .leftMouseDown)`.
   - Eliminar `pickerSection` de la vista.
   - Agregar fila de chips de proyecto usando los tokens del theme.
   - Mantener `findTextView(in:)` para focus automatico.

2. **`InputViewModel.swift`** (`/issue/Features/Home/ViewModels/`):
   - Eliminar `enum InputMode` y `@Published var inputMode`.
   - Agregar `@Published var selectedInputProject: Project` que se sincroniza con `sidebarVM.selectedProject` (o `.general` si es `.all`).
   - Agregar `func prepareForOpen()` que setea `selectedInputProject` al proyecto actual del sidebar (para que cada apertura refleje el estado actual).
   - Modificar `submitEntry()`: eliminar logica de `capturedMode`. Siempre clasificar con IA. Usar `selectedInputProject` en vez de `selectedProject` como proyecto destino.
   - Exponer `availableProjects: [Project]` computado que filtra `.all` del array de `projectStore.projects`.

3. **`EntryStore.swift`** (`/issue/Services/`):
   - Agregar metodo `addEntry(_ entry: Entry, toProject project: Project)` que lee el JSON del proyecto destino, agrega la entry, y escribe de vuelta -- **sin modificar `entries` ni `currentProjectID` en memoria**. Esto permite enviar entries a proyectos que no estan cargados en el feed.
   - Si el proyecto destino coincide con `currentProjectID`, usar el `add()` normal para que el feed se actualice reactivamente.

### Archivos que NO cambian

- `ShortcutManager.swift`: Cmd+I se mantiene igual.
- `AppState.swift`: sin cambios.
- `ProjectStore.swift`: se usa tal cual.
- `SidebarViewModel.swift`: se lee pero no se modifica.
- `AppTheme.swift`, `Color+Theme.swift`: se reutilizan tokens.
- `issueApp.swift`: no deberia necesitar cambios, verificar que `setupInputPanel` sigue compatible.

### Patrones a seguir

- **Chips de proyecto**: Seguir el patron visual de `ProjectTabsView`, adaptando a tokens del theme en vez de colores hardcodeados.
- **Tema**: Usar `@Environment(\.appTheme)` en la nueva vista. `ThemedView()` ya se aplica en `InputPanelController.open()`.
- **Focus**: Mantener el patron actual de `findTextView(in:)` con el dispatch async.
- **Vibrancy en NSPanel**: Pasar el `NSHostingView` como subview de un `NSVisualEffectView` configurado con `material = .hudWindow`, `blendingMode = .behindWindow`, `state = .active`.

### Referencia visual del layout

```
+--------------------------------------------------------------+
|                                                              |
|  [General]  [issue]  [Mi proyecto]  [Otro]                   |
|                                                              |
|  +--------------------------------------------------------+  |
|  | Que estas pensando?                       [clip]  [->] |  |
|  +--------------------------------------------------------+  |
|                                                              |
|  [img1] [img2]          (solo si hay imagenes adjuntas)      |
|                                                              |
+--------------------------------------------------------------+
            ^--- barra centrada, tercio superior, vibrancy
```
