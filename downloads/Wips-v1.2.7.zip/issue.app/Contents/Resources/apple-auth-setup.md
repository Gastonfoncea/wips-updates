# Apple Sign In — Guia de configuracion

## Contexto: que estamos haciendo y por que

Wips usa un proxy (Vercel) para hablar con la API de OpenAI. El proxy guarda la API key de OpenAI y la app se autentica con el proxy usando un token estatico (`WIPS_PROXY_TOKEN`). El problema: ese token esta embebido en el binario de la app, y como los usuarios son devs, lo pueden extraer y usar el proxy para sus propias cosas.

La solucion: reemplazar el token estatico por autenticacion real con Apple Sign In. Cada usuario se autentica con su Apple ID, recibe credenciales temporales (JWT), y el proxy verifica esas credenciales en cada request.

### Conceptos clave

**JWT (JSON Web Token):** Un string firmado que funciona como credencial temporal. Contiene el ID del usuario y una fecha de expiracion, firmado con un secreto que solo el proxy conoce. Dura 1 hora y se renueva automaticamente. A diferencia del token estatico (que es siempre igual y sirve para siempre), un JWT expira y esta ligado a un usuario especifico.

**Redis:** Base de datos en memoria, ultra rapida. Funciona como un diccionario clave-valor (`set(clave, valor)` y `get(clave)`). No tiene tablas ni SQL — es simplemente poner y leer valores por clave. Cada entrada puede tener un TTL (time to live) para que se borre sola despues de X tiempo. Usamos Upstash, que da un Redis serverless gratis.

El proxy usa Redis para guardar tres cosas:
- **Usuarios** (`user:{appleID}`) — quien se registro, sin TTL
- **Refresh tokens** (`refresh:{token}` → `userID`) — con TTL de 30 dias, para renovar sesiones
- **Rate limiting** (`rate:ip:xxx`) — contadores con TTL de 60 segundos

Lo necesitamos en Redis y no en memoria porque Vercel es serverless: cada request puede correr en una instancia distinta que no comparte memoria con las anteriores.

**PROXY_JWT_SECRET:** La clave secreta con la que el proxy firma los JWT. Se genera con `openssl rand -hex 32` (32 bytes aleatorios en hexadecimal). Vive solo en Vercel como variable de entorno, nunca sale del servidor. Sin este secreto, nadie puede fabricar un JWT valido.

---

## Parte 1: Proxy y Redis (backend)

> Estado: COMPLETADO

### Paso 1 — Crear base de datos Redis en Upstash

1. Ir a console.upstash.com
2. Crear cuenta (podes usar GitHub login)
3. Click "Create Database"
4. Nombre: `wips-auth`, region: la mas cercana (ej: `us-east-1`)
5. Plan: Free (10K requests/dia, sobra para lo que necesitamos)
6. En la seccion "REST API", copiar:
   - `UPSTASH_REDIS_REST_URL` — la URL para conectarse
   - `UPSTASH_REDIS_REST_TOKEN` — el token de autenticacion (click en el icono del ojo para verlo sin `****`)

### Paso 2 — Generar JWT secret

Correr en la terminal:
```bash
openssl rand -hex 32
```
Esto genera un string random de 64 caracteres. Guardalo — es tu `PROXY_JWT_SECRET`. Si lo perdes, podes generar uno nuevo, pero todos los JWT existentes dejarian de ser validos (los usuarios tendrian que hacer sign in de nuevo).

### Paso 3 — Configurar variables en Vercel

1. Ir al dashboard del proyecto `majestic-proxy` en Vercel
2. Settings > Environment Variables
3. Agregar estas 3 variables. Marcar **Production** y **Preview** en cada una:

| Variable | Que es | Valor |
|---|---|---|
| `UPSTASH_REDIS_REST_URL` | URL de conexion a Redis | La URL que copiaste de Upstash |
| `UPSTASH_REDIS_REST_TOKEN` | Token de auth de Redis | El token que copiaste de Upstash |
| `PROXY_JWT_SECRET` | Clave para firmar JWT | El string de 64 chars que generaste |

Nota: `APPLE_SERVICES_ID` solo hace falta si usas un Services ID distinto a `com.gastonfoncea.wips` (por defecto no hace falta).

### Paso 4 — Deploy

```bash
cd issue-proxy
git push origin feature/appleAuth
```

Vercel detecta el push y hace deploy automatico. Para verificar que funciona:

```bash
curl -X POST https://majestic-proxy.vercel.app/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refreshToken": "test"}'
```

Debe devolver:
```json
{"error":"invalid_refresh_token"}
```
con status HTTP 401. Eso significa que el endpoint existe, Redis esta conectado, y rechaza tokens invalidos correctamente.

Tambien podes probar el endpoint de login:
```bash
curl -X POST https://majestic-proxy.vercel.app/api/auth/apple \
  -H "Content-Type: application/json" \
  -d '{"identityToken": "fake", "userID": "test"}'
```

Debe devolver `{"error":"authentication_failed"}` con 401 (porque el identity token es falso).

### Que se deployó

| Endpoint | Que hace |
|---|---|
| `POST /api/auth/apple` | Recibe el identity token de Apple, lo verifica contra los servidores de Apple, crea el usuario en Redis, devuelve access token (JWT, 1h) + refresh token (opaco, 30 dias) |
| `POST /api/auth/refresh` | Recibe un refresh token, lo busca en Redis, rota el token (el viejo se invalida), devuelve un par nuevo |
| `POST /api/auth/apple-revoke` | Webhook que Apple llama si el usuario revoca el acceso. Borra todas las sesiones del usuario en Redis |
| `POST /api/openai` | Requiere JWT (`Authorization: Bearer <jwt>`). El token estatico legacy (`X-Issue-Token`) fue removido del proxy |

---

## Parte 2: Apple Developer Portal

> Estado: PENDIENTE

### Paso 1 — Habilitar Sign in with Apple en el App ID

1. Ir a developer.apple.com/account
2. Certificates, Identifiers & Profiles > Identifiers
3. Buscar `com.gastonfoncea.wips`
4. Click en el identifier para editarlo
5. Scroll hasta Capabilities > marcar **Sign In with Apple**
6. Save

Esto le dice a Apple que tu app tiene permiso para usar Sign In with Apple. Sin esto, la sheet de autenticacion no aparece.

### Paso 2 — Registrar webhook de revocacion (opcional, se puede hacer despues)

Esto es para que Apple avise al proxy cuando un usuario revoca el acceso a tu app desde la configuracion de su Apple ID.

1. En el Apple Developer portal > Services > Sign in with Apple
2. Agregar Server-to-Server Notification Endpoint:
   `https://majestic-proxy.vercel.app/api/auth/apple-revoke`

---

## Parte 3: App (Xcode)

> Estado: PENDIENTE

### Paso 1 — Agregar capability en Xcode

1. Abrir `issue.xcodeproj` en Xcode
2. Click en el proyecto en el navegador > Target `issue`
3. Tab **Signing & Capabilities**
4. Click en **+ Capability** (boton arriba a la izquierda)
5. Buscar "Sign in with Apple" > doble click para agregar

El entitlement ya esta en el codigo (`issue.entitlements`), pero Xcode necesita que lo agregues desde la UI para sincronizar el provisioning profile con Apple. Si tenes automatic signing activado, Xcode regenera el profile automaticamente.

### Paso 2 — Verificar que compila

```bash
xcodebuild -scheme issue -destination 'platform=macOS' build -allowProvisioningUpdates
```

Si da error de provisioning profile, ir a Signing & Capabilities y verificar que:
- Automatic signing esta activado
- El Team esta seleccionado
- No hay errores en rojo

---

## Parte 4: Testing del flujo completo

> Estado: PENDIENTE

1. Build & Run en Xcode (Cmd+R)
2. Abrir Settings (Cmd+,)
3. En la seccion "Cuenta" deberia aparecer el boton "Sign in with Apple"
4. Click en el boton — macOS muestra la sheet nativa de Apple Sign In
5. Autenticarse con tu Apple ID
6. La app envia el identity token al proxy, el proxy lo verifica con Apple, crea el usuario en Redis, y devuelve los tokens
7. La app guarda el refresh token en Keychain y el access token en memoria
8. A partir de ahi, todas las requests de AI usan el JWT en vez del token estatico
9. El indicador de estado deberia mostrar "Sesion iniciada con Apple"

### Verificar que el refresh funciona

El access token dura 1 hora. Despues de eso:
- Alguna request de AI va a recibir 401 del proxy
- La app automaticamente intenta refrescar el token (llama a `/api/auth/refresh`)
- Si funciona, reintenta la request original — el usuario no se entera
- Si falla (ej: refresh token expirado despues de 30 dias), muestra la seccion de Sign In de nuevo

### Verificar que el fallback funciona

Si un usuario tiene su propia API key de OpenAI configurada en Settings, la app la usa directamente (no pasa por el proxy). Esto sigue funcionando igual que antes — el auth con Apple solo aplica al modo proxy.

### Si algo falla

- **Consola de Xcode:** Buscar logs de `AuthService` — logea cada paso del flujo (sign in, refresh, errores)
- **Vercel Functions:** En el dashboard de Vercel > Logs tab — muestra errores de los endpoints de auth
- **Upstash Console:** Podes ver los datos en Redis directamente (usuarios, tokens, contadores)
- **Provisioning:** Si la capability no aparece, desmarcar y volver a marcar automatic signing en Xcode

---

## Resumen de archivos

### Proxy (issue-proxy/)

| Archivo | Que hace |
|---|---|
| `lib/redis.ts` | Cliente Redis: usuarios, refresh tokens, rate limiting |
| `lib/jwt.ts` | Verificar tokens de Apple, generar/verificar JWT propios |
| `lib/auth-middleware.ts` | Middleware de auth dual (JWT + legacy) |
| `api/auth/apple.ts` | Endpoint de login con Apple |
| `api/auth/refresh.ts` | Endpoint de refresh de tokens |
| `api/auth/apple-revoke.ts` | Webhook de revocacion de Apple |
| `api/openai.ts` | Proxy a OpenAI (modificado para auth dual + rate limit en Redis) |

### App (issue/)

| Archivo | Que hace |
|---|---|
| `Core/Services/Auth/AuthService.swift` | Servicio principal de auth: estado, sign in, refresh, sign out |
| `Core/Services/Auth/AuthError.swift` | Errores tipados de autenticacion |
| `Core/Services/Auth/AppleSignInCoordinator.swift` | Puente entre ASAuthorizationController y async/await |
| `Features/Auth/AuthView.swift` | UI del boton de Apple Sign In y estado |
| `Core/Services/APIKeyProvider.swift` | Modificado: usa JWT, tiene executeRequest() con retry en 401 |
| `App/AppState.swift` | Modificado: crea e inyecta AuthService |
| `App/issueApp.swift` | Modificado: checkCredentialState() al iniciar |
| `Features/Settings/SettingsView.swift` | Modificado: seccion de cuenta arriba de API key |
| `issue.entitlements` | Modificado: agregado permiso de Apple Sign In |

### Variables de entorno (Vercel)

| Variable | Donde se configura |
|---|---|
| `UPSTASH_REDIS_REST_URL` | Vercel > Settings > Environment Variables |
| `UPSTASH_REDIS_REST_TOKEN` | Vercel > Settings > Environment Variables |
| `PROXY_JWT_SECRET` | Vercel > Settings > Environment Variables |
| `OPENAI_API_KEY` | Ya existia en Vercel |
| `ISSUE_APP_TOKEN` | REMOVIDO — ya no se usa (auth legacy eliminado) |
