# Bug Tracking

Registro de bugs que requieren 3+ iteraciones para resolver.

---

## BUG-001: Dynamic Island pill no toca el borde de pantalla

**Componente**: `InputPanelView.swift` + `InputPanelController.swift`
**Iteraciones**: 5
**Estado**: Resuelto

### Síntomas
- El pill animado del floating input (Cmd+I) no tocaba el borde inferior de la pantalla
- Había un gap visible entre el pill y el borde

### Causas raíz identificadas
1. **`screen.visibleFrame` vs `screen.frame`**: `visibleFrame` descuenta el dock, `screen.frame` da los bounds físicos reales
2. **`.mask()` con offscreen rendering**: El approach con `.mask(alignment: .bottom)` requería composición offscreen cada frame, causando lag al escribir
3. **`.animation()` separados**: Usar `.animation(_:value:)` individuales en mask y opacity creaba timing desincronizado
4. **`panel.hasShadow = true`**: Generaba un borde gris visible alrededor del panel transparente
5. **Contenido SwiftUI no anclado al bottom**: Faltaba `.frame(maxHeight: .infinity, alignment: .bottom)` para empujar el contenido al fondo del NSPanel

### Solución final
- Reemplazar `.mask()` con `.background(alignment: .bottom)` — el pill es solo el background shape animando de chico a grande, sin offscreen rendering
- Usar `screen.frame.minY` (no `visibleFrame`) para posicionar el panel
- `panel.hasShadow = false` para eliminar el borde gris
- Single `withAnimation(.spring(response: 0.3, dampingFraction: 0.85))` en `.onAppear` en vez de `.animation()` separados
- `.frame(maxHeight: .infinity, alignment: .bottom)` + `.ignoresSafeArea()` para anclar al fondo

### Lecciones
- En macOS, `NSWindow.setFrameOrigin` via `animator()` NO es animatable — usar `setFrame(_:display:)` con `allowsImplicitAnimation`
- `.mask()` en SwiftUI fuerza offscreen rendering, malo para views con input de texto frecuente
- `.background(alignment:)` es la alternativa performante para reveal animations
- `NSPanel.hasShadow` agrega un contorno visible en panels con `backgroundColor = .clear`

---

## BUG-002: Input panel no aparece en el Space activo (Cmd+I cross-Space)

**Componente**: `InputPanelController.swift`
**Iteraciones**: 4
**Estado**: Resuelto

### Síntomas
- Cmd+I solo funcionaba en el desktop donde estaba la ventana principal (sin apps maximizadas)
- En otros Spaces, el panel no aparecía o macOS switcheaba al Space del dashboard
- Al cerrar el panel (Enter/Escape), macOS volvía al desktop del dashboard

### Causas raíz identificadas
1. **Falta `.nonactivatingPanel`**: Sin este styleMask, mostrar el panel activaba la app completa y macOS cambiaba al Space de la ventana principal
2. **`.nonactivatingPanel` solo no alcanza**: Sin activar la app, macOS no muestra ventanas de una app inactiva en otro Space — el panel se creaba pero quedaba invisible
3. **`NSApp.activate()` cambia de Space**: Activar una app regular (`.regular` policy) hace que macOS switchee al Space donde están sus ventanas
4. **Restore inmediato de `.regular` policy**: Restaurar la policy en el siguiente run-loop (`DispatchQueue.main.async`) causaba que macOS viera la ventana principal y switcheara — funcionaba inconsistentemente (Desktop 3 sí, Desktop 2 no)
5. **`NSScreen.main` devuelve pantalla incorrecta**: Cuando la app está en otro Space, `NSScreen.main` apunta a la pantalla de la ventana principal, no a donde está el usuario
6. **`NSApp.hide(nil)` en mismo Space**: El truco de `hide()`/`unhideWithoutActivation()` al cerrar causaba que el dashboard desapareciera y volviera sin foco cuando el usuario estaba en el mismo Space

### Solución final
Dos caminos según contexto, detectado con `NSWindow.isOnActiveSpace`:

**Mismo Space que el dashboard:**
- `panel.makeKeyAndOrderFront(nil)` simple
- Sin cambio de activation policy
- Sin `hide()`/`unhide()` al cerrar

**Otro Space (cross-Space):**
- `NSApp.setActivationPolicy(.accessory)` antes de activar — apps accessory no causan cambio de Space
- `panel.orderFrontRegardless()` + `makeKey()` + `NSApp.activate(ignoringOtherApps: true)`
- Policy se restaura a `.regular` en `cleanUpPanel()` (no inmediatamente)
- `NSApp.hide(nil)` al cerrar desactiva la app y da foco a la app detrás
- `NSApp.unhideWithoutActivation()` después de 0.1s restaura ventanas sin reactivar

**Común a ambos caminos:**
- `styleMask: [.nonactivatingPanel, .fullSizeContentView]`
- `collectionBehavior: [.canJoinAllSpaces, .fullScreenAuxiliary]`
- `hidesOnDeactivate = false`
- Detección de pantalla por posición del mouse cursor en vez de `NSScreen.main`

### Lecciones
- **`.nonactivatingPanel` no es suficiente solo**: Permite recibir teclado sin activar la app, pero macOS no muestra ventanas de apps inactivas en otros Spaces
- **Patrón Spotlight/Alfred**: Temporalmente `.accessory` → `activate()` → restaurar `.regular` al cerrar. Las apps accessory no tienen ventanas que causen cambio de Space al activarse
- **Timing del restore es crítico**: Restaurar `.regular` inmediatamente (mismo run-loop o siguiente) causa race conditions con el cambio de Space. Restaurar al cerrar el panel es seguro porque la app ya se desactivó
- **`NSApp.hide()` + `unhideWithoutActivation()`**: Patrón para desactivar una app sin API directa de `deactivate()`. `hide()` activa la siguiente app; `unhideWithoutActivation()` restaura ventanas sin reactivar
- **Bifurcar mismo-Space vs cross-Space**: No aplicar hacks cross-Space cuando el usuario está en el mismo Space que la ventana principal — causa bugs innecesarios
- **`NSScreen.main` miente cross-Space**: Usar `NSEvent.mouseLocation` + `NSMouseInRect` para encontrar la pantalla correcta

---

## BUG-003: Rectángulo gris visible detrás del panel centrado (NSHostingView background)

**Componente**: `InputPanelViewCustom.swift` + `InputPanelController.swift`
**Iteraciones**: 10+
**Estado**: Resuelto

### Síntomas
- Al usar variantes centradas del input panel, aparecía un rectángulo gris claro con esquinas cuadradas detrás del contenido SwiftUI redondeado
- Panel A (Dynamic Island, posicionado en el borde inferior) nunca lo mostraba
- El rectángulo cambiaba de tamaño según el contenido y a veces era más alto que el panel

### Causas raíz (dos problemas independientes)

**1. `.frame(maxWidth: .infinity)`** en la cadena de modifiers. Cuando se usa `maxWidth: .infinity` dentro de un NSHostingView en un NSPanel transparente, SwiftUI/AppKit expone el fondo default del NSHostingView (gris del sistema) en el área expandida. Usar solo `.frame(maxHeight: .infinity)` (sin maxWidth) lo resuelve — el ancho del contenido `.frame(width:)` debe coincidir con el `PanelConfig.width`.

**2. Overlays y shadows dentro de `.background { }`**. Agregar `.overlay()` o `.shadow()` al shape dentro del bloque `.background { }` también causa que NSHostingView exponga el fondo gris. Estos efectos decorativos deben ir como `.overlay()` en el contenido principal, FUERA del `.background { }`.

**3. `.background(Color.clear)` en el controller**. Envolver la vista SwiftUI en un `.background(Color.clear)` extra desde el controller también lo provoca — agrega una capa extra que interfiere.

### Solución final

El `.background { }` dentro de un NSHostingView/NSPanel transparente debe ser **mínimo**: solo el shape + fill + frame. Todo lo decorativo va afuera.

```swift
// BIEN — background limpio, decoración como overlay
.background {
    RoundedRectangle(cornerRadius: 16)
        .fill(gradient)
        .frame(width: 560, height: 100)
}
.overlay(RoundedRectangle(cornerRadius: 16).fill(shineGradient))  // glass shine
.overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(borderGradient)) // glass border
.frame(maxHeight: .infinity)  // solo maxHeight, NO maxWidth
.ignoresSafeArea()

// MAL — overlays/shadows dentro del .background
.background {
    RoundedRectangle(cornerRadius: 16)
        .fill(gradient)
        .frame(width: 560, height: 100)
        .overlay(...)   // ← provoca el rectángulo gris
        .shadow(...)    // ← provoca el rectángulo gris
}

// MAL — maxWidth: .infinity
.frame(maxWidth: .infinity, maxHeight: .infinity)  // ← expone fondo gris

// MAL — .background(Color.clear) extra en el controller
let view = MyView().modifier(ThemedView()).background(Color.clear)  // ← interfiere
```

### Lecciones
- **`.background { }` en NSHostingView debe ser mínimo**: solo shape + fill + frame. Cualquier overlay, strokeBorder, o shadow dentro del bloque background provoca que NSHostingView exponga su fondo default
- **Decoración como `.overlay()` del contenido**: shine, bordes gradient, y shadows van como modifiers en el contenido principal, fuera de `.background { }`
- **Nunca usar `maxWidth: .infinity`** en SwiftUI views dentro de NSHostingView con NSPanel transparente
- **No agregar `.background(Color.clear)` al wrappear la vista** desde el controller — interfiere con el layout del hosting view
- **El ancho del `.frame(width:)` del contenido debe coincidir con el `PanelConfig.width`**

---

## BUG-004: Overlays causan rectángulo gris con `.background(alignment: .bottom)`

**Componente**: `InputViewTest.swift`
**Iteraciones**: 4
**Estado**: Resuelto

### Síntomas
- Al agregar `.overlay()` (fill, stroke, o shadow) al contenido del panel con layout `alignment: .bottom`, reaparecía el rectángulo gris de BUG-003
- Sin overlays, el mismo layout con `.regularMaterial` funcionaba perfecto

### Causa raíz

Cuando se usa `.background(alignment: .bottom)` con un pill de height fijo (ej: 100px), el pill se ancla al fondo del view. Pero los `.overlay()` del contenido cubren el **alto completo del view** (que incluye el PanelConfig height), no solo el área del pill. En el gap entre el tope del view y el tope del pill, el overlay expone el fondo gris del NSHostingView:

- **Fill overlay** (`.fill(color.opacity(0.5))`): semi-transparente sobre el gap → gris visible
- **Stroke overlay**: dibuja el borde en el frame completo, no en el pill
- **Shadow**: genera sombra del frame completo

```swift
// MAL — overlays cubren todo el alto, no solo el pill
.background(alignment: .bottom) {
    RoundedRectangle(cornerRadius: 18)
        .fill(.regularMaterial)
        .frame(width: 720, height: 100)          // pill de 100px, anclado al fondo
}
.overlay(RoundedRectangle(cornerRadius: 18)
    .fill(color.opacity(0.5)))                     // ← cubre TODO el view height, no solo 100px
.overlay(RoundedRectangle(cornerRadius: 18)
    .stroke(borderColor))                          // ← idem
.shadow(...)                                       // ← idem
.frame(maxHeight: .infinity, alignment: .bottom)   // view height > pill height

// BIEN — solo background, sin overlays
.background(alignment: .bottom) {
    RoundedRectangle(cornerRadius: 18)
        .fill(.regularMaterial)
        .frame(width: 720, height: 100)
}
.frame(maxHeight: .infinity, alignment: .bottom)
```

### Solución final
No usar `.overlay()`, `.stroke()`, ni `.shadow()` sobre el contenido cuando el layout usa `alignment: .bottom`. El background con material es suficiente. Si se necesita borde o shadow, aplicarlos dentro del pill shape (pero respetando BUG-003: solo shape + fill + frame dentro de `.background { }`).

### Lecciones
- **`.overlay()` hereda el frame del contenido, no del background**: con `alignment: .bottom`, el contenido ocupa todo el alto del panel, pero el background pill es más chico — los overlays cubren el gap y exponen el gris
- **SwiftUI Materials (`.regularMaterial`, `.thinMaterial`) funcionan** en NSHostingView con NSPanel transparente, siempre que la estructura del `.background { }` sea mínima
- **Con layout bottom-aligned**: la única decoración segura es lo que está DENTRO del `.background { }` (shape + fill + frame), nada más
