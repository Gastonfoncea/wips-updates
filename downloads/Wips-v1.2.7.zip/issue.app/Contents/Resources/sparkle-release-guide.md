# Guia de publicacion de updates con Sparkle

## Resumen

Wips usa [Sparkle 2](https://sparkle-project.org/) para auto-updates fuera de la App Store. El flujo es:

1. Pusheas un tag `v*` → el pipeline de GitHub Actions buildea, firma, notariza, y crea un GitHub Release con el `.dmg`
2. El pipeline tambien firma el `.zip` con Sparkle y actualiza el `appcast.xml` en el repo `wips-updates`
3. Los usuarios reciben el update automaticamente

## Arquitectura

```
wips (repo principal)          wips-updates (repo del appcast)
│                              │
├─ .github/workflows/          ├─ appcast.xml  ← GitHub Pages lo sirve
│   └─ release.yml             │                  en https://gastonfoncea.github.io/wips-updates/appcast.xml
│       │                      │
│       ├─ Build + Archive     │
│       ├─ Notarize            │
│       ├─ Firmar con Sparkle ─┤
│       └─ Actualizar appcast ─┘
│
└─ issue/Info.plist
    ├─ SUFeedURL → apunta al appcast
    └─ SUPublicEDKey → clave publica EdDSA
```

## Que hace la app

- Al iniciar, `SPUStandardUpdaterController` revisa el appcast cada ~24h
- Si encuentra una version mas nueva, le muestra al usuario una ventana de update
- El usuario puede tambien buscar manualmente desde Settings → Actualizaciones → "Buscar ahora"

## Como publicar un update

### Paso 1 — Bumpear version

En Xcode, target **issue** → General:
- **Version** (CFBundleShortVersionString): la version visible (ej: `1.1.0`)
- **Build** (CFBundleVersion): numero incremental (ej: `2`)

Ambos deben ser mayores que la version anterior.

### Paso 2 — Push del tag

```bash
git tag v1.1.0
git push origin v1.1.0
```

Esto dispara el workflow `release.yml` que:
1. Buildea y archiva la app
2. Firma con Developer ID
3. Notariza con Apple
4. Crea el `.zip` y `.dmg`
5. Firma el `.zip` con la clave EdDSA de Sparkle
6. Actualiza `appcast.xml` en `wips-updates`
7. Crea el GitHub Release con el `.dmg`

### Paso 3 — Verificar

- Revisar que el GitHub Release se creo correctamente
- Revisar que `appcast.xml` se actualizo: https://gastonfoncea.github.io/wips-updates/appcast.xml
- Abrir Wips → Settings → "Buscar ahora" para confirmar que detecta el update

## Estructura del appcast.xml

Cada release agrega un `<item>` al appcast:

```xml
<item>
  <title>Version 1.1.0</title>
  <sparkle:version>2</sparkle:version>
  <sparkle:shortVersionString>1.1.0</sparkle:shortVersionString>
  <description><![CDATA[
    <h2>Novedades</h2>
    <ul>
      <li>Nueva feature X</li>
      <li>Fix de bug Y</li>
    </ul>
  ]]></description>
  <enclosure
    url="https://github.com/Gastonfoncea/wips/releases/download/v1.1.0/Wips.zip"
    sparkle:edSignature="FIRMA_BASE64"
    length="TAMAÑO_EN_BYTES"
    type="application/octet-stream"/>
</item>
```

## Publicacion manual (sin pipeline)

Si el pipeline no esta listo o falla, podes hacerlo a mano:

### 1. Archive en Xcode
Product → Archive → Distribute App → Developer ID → Export

### 2. Crear el zip
```bash
ditto -c -k --keepParent "Wips.app" "Wips.zip"
```

### 3. Firmar con Sparkle
```bash
# Buscar el tool:
find ~/Library/Developer/Xcode/DerivedData -name "sign_update" -type f

# Firmar:
/ruta/a/sign_update "Wips.zip"
```

Esto imprime algo como:
```
sparkle:edSignature="xxxxx" length="12345678"
```

### 4. Subir el zip a GitHub Releases

### 5. Actualizar appcast.xml
Agregar un nuevo `<item>` con la version, URL del zip, firma, y tamaño. Push al repo `wips-updates`.

## Secrets necesarios en GitHub Actions

Los que ya existen:
- `APPLE_CERTIFICATE_P12` — certificado Developer ID
- `APPLE_CERTIFICATE_PASSWORD` — password del .p12
- `APPLE_TEAM_ID` — Team ID de Apple
- `APPLE_ID` — Apple ID para notarizacion
- `APPLE_ID_PASSWORD` — App-specific password

Nuevos para Sparkle:
- `SPARKLE_PRIVATE_KEY` — clave privada EdDSA (exportar del Keychain)
- `WIPS_UPDATES_TOKEN` — Personal Access Token con permisos de push al repo `wips-updates`

## Clave privada de Sparkle

La clave privada esta en tu Keychain local. Para exportarla (necesario para CI):

```bash
# Buscar el tool:
find ~/Library/Developer/Xcode/DerivedData -name "generate_keys" -type f

# Exportar (imprime la clave privada):
/ruta/a/generate_keys -x
```

Guardar ese valor como secret `SPARKLE_PRIVATE_KEY` en GitHub.

## Notas

- Sparkle compara `sparkle:version` (build number) para decidir si hay update
- El `.zip` es lo que Sparkle descarga — el `.dmg` es para descarga manual desde GitHub
- La clave publica esta en `Info.plist` (`SUPublicEDKey`), la privada solo en CI secrets y tu Keychain
- Si cambias las claves, todos los usuarios existentes dejaran de recibir updates (la firma no matchea)
