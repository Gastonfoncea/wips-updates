# Spec: Feed Notion-like (Rediseno de UI del Home)

## Problema

El feed actual usa cards pesadas (CategoryCardView, TaskCardView, CustomCategoryCardView) con headers prominentes, circulos de color, bordes, contadores numericos y botones "Ver todos". Esto genera una interfaz cargada que distrae del contenido real: el texto de las entries. El usuario quiere una experiencia mas parecida a un documento/page donde las entries se leen y editan como texto plano, con jerarquia tipografica clara y colores sutiles como acentos, no como bloques de fondo.

## Contexto Tecnico

### Arquitectura actual relevante

- **FeedView.swift** (`/issue/Features/Home/Views/FeedView.swift`): Vista principal. Tiene dos modos: `grouped` (cards por categoria) y `timeline` (lista plana). El modo timeline ya es mas minimal y sirve como punto de partida conceptual.
- **FeedViewModel.swift** (`/issue/Features/Home/ViewModels/FeedViewModel.swift`): Contiene TODA la logica de negocio (filtrado, agrupacion, drag&drop, CRUD). No necesita cambios estructurales. Ya expone `categoriesWithEntries`, `customCategoriesWithEntries`, `pinnedEntries`, `timelineEntries`.
- **EntryRow.swift** (`/issue/Features/Home/Views/Components/EntryRow.swift`): Componente de fila actual. Muestra texto readonly con hover para boton delete. Click en tareas hace toggle. No tiene edicion inline.
- **EntryStore.swift** (`/issue/Services/EntryStore.swift`): Ya tiene `update(_ entry: Entry)` que persiste cambios. Se puede usar para guardar ediciones de texto.
- **Entry model** (`/issue/Core/Models/Entry.swift`): `text: String` es mutable (`var`). Tiene `category`, `type`, `isCompleted`, `isPinned`, `isArchived`, `attachmentFileNames`.
- **AppTheme** (`/issue/Shared/Extensions/AppTheme.swift`): Sistema de tema con tokens semanticos (`textPrimary`, `textSecondary`, `textMuted`, `hoverOverlay`, etc.). Soporta dark/light.
- **Color+Theme.swift** (`/issue/Shared/Extensions/Color+Theme.swift`): Colores por categoria (`Color.from(category:)`) y por tipo de tarea (`Color.from(type:)`).
- **CardHeaderView, TaskCheckbox, SectionSeparator, ShowAllButton**: Componentes shared actuales que se reutilizan o reemplazan.
- **GroupedEntries** (`/issue/Shared/Components/GroupedEntries.swift`): Agrupa entries por DateBucket (Hoy, Ayer, Esta semana, Anteriores).

### Lo que NO existe y se necesita

- No hay metodo `updateEntryText` en FeedViewModel (hay que agregarlo, es trivial).
- No hay estado de "entry en edicion" (entry ID que esta siendo editada inline).
- No hay TextField/TextEditor inline en EntryRow.

## Historias de Usuario

1. **Como** usuario de la app, **quiero** ver mis entries como un documento limpio con secciones claras y tipografia jerarquica, **para** poder escanear y leer mi contenido sin distraccion visual.

2. **Como** usuario de la app, **quiero** hacer click en cualquier entry para editarla directamente en el lugar, **para** corregir o ampliar mi texto sin necesitar un modal o panel separado.

3. **Como** usuario de la app, **quiero** distinguir visualmente el tipo de cada entry (tarea, idea, conocimiento, etc.) de forma sutil, **para** mantener la organizacion sin que los colores dominen la interfaz.

## Criterios de Aceptacion

### CA-1: Layout tipo documento

- **Given** el usuario esta en la vista del feed de un proyecto
- **When** mira la pantalla
- **Then** ve un layout tipo page/documento con:
  - El contenido centrado con max-width (~720px) y padding lateral generoso
  - Las secciones de categoria separadas por un header ligero (texto + linea sutil), no por cards con bordes y fondos
  - Las entries listadas directamente bajo el header de seccion, sin padding ni backgrounds de card
  - Espacio vertical generoso entre secciones (24px), espacio compacto entre entries (2-4px)

### CA-2: Jerarquia tipografica clara

- **Given** el feed tiene entries de multiples categorias
- **When** el usuario escanea el contenido
- **Then** puede distinguir claramente:
  - **Titulo del proyecto**: `.title3` (20-22pt), semibold, `textPrimary`
  - **Headers de seccion (categoria)**: `.subheadline` (13pt), semibold, `textSecondary`, con tracking
  - **Texto de entry**: `.body` (14pt), regular, `textPrimary`
  - **Metadata (fecha, tipo)**: `.caption2` (10pt), `textMuted`
  - Los tamanios son consistentes y la jerarquia se lee sin esfuerzo

### CA-3: Colores como acento, no como fondo

- **Given** las entries pertenecen a categorias con colores asignados
- **When** el usuario mira la lista
- **Then** los colores de categoria se usan unicamente en:
  - Un indicador lateral minimo (linea vertical de 2px a la izquierda del header de seccion, o un dot de 6px)
  - El icono sutil de la categoria junto al header de seccion
  - El checkbox de las tareas (mantener `TaskCheckbox` existente)
  - NO hay fondos de color, NO hay circulos de color grandes, NO hay bordes coloreados en las entries

### CA-4: Entries de tarea con checkbox interactivo

- **Given** una entry es de tipo `.tarea`
- **When** se muestra en el feed
- **Then** muestra un checkbox a la izquierda del texto (reutilizar `TaskCheckbox` con su color de acento)
- **When** el usuario hace click en el checkbox
- **Then** la tarea se marca/desmarca como completada (usar `feedVM.toggleEntry`)
- **When** la tarea esta completada
- **Then** el texto muestra strikethrough y color `textMuted`

### CA-5: Entries no-tarea con icono sutil

- **Given** una entry NO es de tipo `.tarea` (es idea, conocimiento, inspiracion, bitacora, fecha importante)
- **When** se muestra en el feed
- **Then** muestra un icono SF Symbol sutil (10pt, `textMuted`) a la izquierda, usando `category.iconName`
- **Then** el icono NO usa el color de la categoria (es monocromatico, `textMuted`)

### CA-6: Inline editing al hacer click

- **Given** una entry se muestra en el feed (modo lectura)
- **When** el usuario hace click en el texto de la entry
- **Then** el `Text` se reemplaza por un `TextField` (o `TextEditor` para multilinea) con el texto actual
- **Then** el campo tiene focus automatico y el cursor se posiciona al final del texto
- **Then** el campo no tiene borde visible (se ve como texto plano, "borderless editing")

### CA-7: Guardar edicion

- **Given** una entry esta en modo edicion (TextField activo)
- **When** el usuario presiona Enter (o hace click fuera del campo)
- **Then** el texto editado se guarda via `feedVM.updateEntryText(entry, newText:)`
- **Then** el campo vuelve a modo lectura (`Text`)
- **When** el usuario presiona Escape
- **Then** se descarta el cambio y vuelve a modo lectura con el texto original

### CA-8: Solo una entry en edicion a la vez

- **Given** una entry esta en modo edicion
- **When** el usuario hace click en otra entry
- **Then** la primera guarda sus cambios y sale de edicion
- **Then** la nueva entry entra en modo edicion

### CA-9: Hover state minimal

- **Given** el mouse esta sobre una entry
- **When** el usuario hace hover
- **Then** se muestra un fondo sutil (`hoverOverlay`) en la fila
- **Then** aparecen controles inline al final de la fila: icono de menu (tres puntos verticales) que abre el context menu existente
- **When** el mouse sale
- **Then** el fondo y controles desaparecen con animacion suave

### CA-10: Seccion de entries fijadas (pinned)

- **Given** hay entries con `isPinned == true`
- **When** se muestra el feed
- **Then** las entries fijadas aparecen al tope del documento, bajo el header del proyecto
- **Then** la seccion usa un header ligero "Fijadas" (no card) con icono pin sutil
- **Then** las entries fijadas de tipo `fechaImportante` tienen un background sutil (`fechaImportante.opacity(0.06)`) para destacar

### CA-11: Entries con attachments

- **Given** una entry tiene imagenes adjuntas (`attachmentFileNames` no vacio)
- **When** se muestra en el feed
- **Then** los thumbnails aparecen debajo del texto de la entry (no a la izquierda), en una fila horizontal
- **Then** el tamano de thumbnail es 36x36px con border-radius 4px
- **Then** click en thumbnail abre preview (mantener `ImagePreviewSheet` existente)

### CA-12: Secciones de tareas con sub-agrupacion por tipo

- **Given** la categoria es `.tarea`
- **When** se muestran las entries de tarea
- **Then** se agrupan por `EntryType` (Feature, Bug, Thought, Question, Unclassified)
- **Then** cada sub-grupo tiene un sub-header minimo: linea vertical de 2px del color del tipo + nombre del tipo en `caption`, tracking 1.5, `textMuted`
- **Then** las completadas se agrupan al final bajo un toggle colapsable "Completadas (N)" (mantener patron actual de `CompletedSection`)

### CA-13: Context menu y acciones completas

- **Given** el usuario hace right-click en una entry o click en el icono de menu (hover)
- **When** se abre el context menu
- **Then** tiene las mismas opciones que hoy: Toggle completar, Fijar/Desfijar, Archivar, Mover a..., Eliminar
- **Then** Eliminar muestra confirmacion (mantener alert actual)

### CA-14: Drag & drop entre secciones

- **Given** una entry se arrastra
- **When** se suelta sobre la zona de otra seccion de categoria
- **Then** se reclasifica la entry (mantener `feedVM.handleDrop` existente)
- **Then** la zona de drop se indica con un borde sutil punteado o un fondo `hoverOverlay` en toda la seccion

## Casos Borde

- **Entry con texto muy largo**: El texto debe hacer wrap natural (multilinea). En modo edicion, usar `TextField` con `axis: .vertical` y `lineLimit(1...10)`.
- **Entry vacia despues de editar**: Si el usuario borra todo el texto y presiona Enter, no guardar -- restaurar el texto original. No queremos entries sin texto.
- **Edicion con attachments visibles**: Los thumbnails debajo del texto deben permanecer visibles durante la edicion.
- **Proyecto "Todos" (virtual aggregate)**: Funciona igual -- el FeedViewModel ya maneja esto. Las entries se agrupan por categoria normalmente.
- **Busqueda activa con entry en edicion**: Si el usuario empieza a tipear en la barra de busqueda mientras una entry esta en edicion, la edicion se guarda y se sale del modo edicion.
- **Filtros activos**: Las secciones solo muestran lo filtrado, igual que hoy. No hay cambio de logica.
- **Proyecto sin entries**: Mantener el empty state actual (`emptyStateView`), ya tiene buen estilo.
- **Muchas entries (>30)**: Mantener la logica `shouldAutoCollapse` pero adaptada: en vez de colapsar cards, las secciones empiezan colapsadas (solo header visible, click para expandir).

## Fuera de Alcance

- **Edicion de tipo/categoria de la entry desde el UI inline** -- Solo se edita el texto. Reclasificar sigue siendo via context menu o drag & drop.
- **Rich text / markdown rendering** -- El texto se muestra y edita como plain text. No hay bold, italic, links clickeables, etc.
- **Reordenamiento manual de entries** (drag para reordenar dentro de una seccion) -- Solo drag entre secciones para reclasificar.
- **Eliminacion de la vista timeline** -- La vista timeline (`viewMode == .timeline`) se mantiene como esta. Este rediseno aplica al modo `grouped`.
- **Animaciones de transicion entre layout viejo y nuevo** -- Es un reemplazo directo, no una transicion animada.
- **Galeria de imagenes agrupada** -- La seccion `ImagesCardView` actual (grid de todas las imagenes) se elimina. Las imagenes se ven en contexto, debajo de su entry.
- **Edicion del campo de fecha/metadata** -- Solo el texto es editable inline.
- **Teclado-only navigation completa** (Tab entre entries, Enter para editar, etc.) -- Se puede agregar en una fase futura.

## Notas de Implementacion

### Archivos a CREAR

1. **`NotionEntryRow.swift`** en `/issue/Features/Home/Views/Components/` -- Nuevo componente que reemplaza a `EntryRow` en el modo grouped. Maneja: display readonly, transicion a edicion, hover con menu, checkbox para tareas, icono para no-tareas. Recibe un `Binding<UUID?>` para `editingEntryID` (la entry actualmente en edicion).

2. **`NotionSectionHeader.swift`** en `/issue/Features/Home/Views/Components/` -- Header ligero de seccion. Reemplaza a `CardHeaderView` en el modo grouped. Muestra: linea de acento vertical (2px) + nombre de categoria + contador + chevron de expand/collapse.

3. **`NotionCategorySection.swift`** en `/issue/Features/Home/Views/Components/` -- Reemplaza `CategoryCardView` y `CustomCategoryCardView`. Contiene: `NotionSectionHeader` + lista de `NotionEntryRow`. Mantiene `dropDestination`.

4. **`NotionTaskSection.swift`** en `/issue/Features/Home/Views/Components/` -- Reemplaza `TaskCardView`. Contiene: `NotionSectionHeader` + sub-secciones por `EntryType` + seccion colapsable de completadas.

5. **`NotionPinnedSection.swift`** en `/issue/Features/Home/Views/Components/` -- Reemplaza `PinnedCardView`. Misma logica pero con estilo ligero.

### Archivos a MODIFICAR

1. **`FeedView.swift`** -- Reemplazar `groupedView` para usar los nuevos componentes `Notion*`. Agregar `@State private var editingEntryID: UUID?` para tracking de edicion. Agregar max-width constraint al ScrollView content. Mantener `timelineView` sin cambios.

2. **`FeedViewModel.swift`** -- Agregar un metodo:
   - `updateEntryText(_ entry: Entry, newText: String)` que muta `entry.text`, setea `updatedAt`, y llama `entryStore.update(...)`.

### Archivos que NO cambian

- `FeedViewModel.swift` (salvo el metodo nuevo): toda la logica de filtrado, agrupacion, CRUD se mantiene.
- `EntryStore.swift`: `update(_:)` ya existe.
- `Entry.swift`: `text` ya es `var`.
- `AppTheme.swift`, `Color+Theme.swift`: se reutilizan tal cual.
- `TaskCheckbox.swift`: se reutiliza.
- `GroupedEntries.swift`: se reutiliza para agrupar por fecha.
- `FilterChipsBar`: se mantiene.
- `SearchBarView`: se mantiene.
- `TimeLineRow.swift`: no cambia (el rediseno solo afecta al modo grouped).

### Archivos que se dejan de usar (no eliminar, solo dejan de ser referenciados en grouped view)

- `CategoryCardView.swift`
- `TaskCardView.swift`
- `CustomCategoryCardView.swift`
- `CardHeaderView.swift` (si se usa en otros lados, mantener; sino, queda deprecated)
- `ImagesCardView.swift` (la galeria se reemplaza por thumbnails inline)
- `PinnedCardView.swift`
- `ShowAllButton.swift` (se reemplaza por expand/collapse de seccion)

### Patrones a seguir

- **Patron de EntryRow actual** como referencia: recibe `entry`, `accentColor`, `feedVM`, callbacks para acciones. Nuevo `NotionEntryRow` sigue la misma firma pero agrega `editingEntryID: Binding<UUID?>`.
- **Patron de hover** como en `EntryRow` y `TimeLineRow`: `@State private var isHovered`, `.onHover`, background condicional.
- **Patron de context menu**: copiar el `.contextMenu` de `EntryRow` exacto (toggle, pin, archive, reclassify, delete).
- **Patron de drag**: mantener `.draggable(entry.id.uuidString)` en cada fila.
- **Patron de drop**: mantener `.dropDestination(for: String.self)` en cada seccion.
- **Tema**: usar `@Environment(\.appTheme)` en todos los componentes nuevos.

### Directrices de estilo visual (referencia para el implementador)

```
Seccion:
  [2px linea vertical color]  CATEGORIA  (count)  [chevron]
  ---------------------------------------- (hairline separator, borderDefault)

    Hoy                                    <- sub-label fecha, caption2, textMuted
    [icon/checkbox] Texto de la entry       <- body, textPrimary
    [icon/checkbox] Texto de otra entry     <- hover: hoverOverlay bg + "..." menu

    Ayer
    [icon/checkbox] Otra entry mas

  (24px espacio antes de la siguiente seccion)

Seccion Tareas:
  [2px linea violeta]  TAREA  (3 pendientes)  [chevron]
  ----------------------------------------

    [2px linea tipo color]  FEATURE
      [checkbox] Implementar X
      [checkbox] Disenar Y

    [2px linea tipo color]  BUG
      [checkbox] Fix Z

    > Completadas (5)         <- colapsable, igual que CompletedSection actual
```
