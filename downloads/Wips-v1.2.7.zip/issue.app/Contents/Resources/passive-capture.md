# Spec: Captura Pasiva de Sesiones de Claude Code

## Decisiones Tomadas

| Pregunta | Decisión |
|---|---|
| Sandbox access | NSOpenPanel para ~/.claude/ al conectar repo, bookmark persistido |
| Transparencia | Sheet al conectar explicando qué se lee y que datos sensibles NO se envían |
| Sanitización | Stripear secrets (sk-, ghp_, AKIA, password, token=, .env) + excluir bloques de código, solo mensajes conversacionales |
| Frecuencia | Solo al abrir la app |
| Límite | Todas las sesiones nuevas, solo últimos 7 días |
| Re-procesamiento | File size + lastModified, si creció se re-procesa |
| Arquitectura | Protocolo SessionProvider para escalar a otros agentes |
| Toggle | Sí, por proyecto, para desactivar captura pasiva |
| Indicador visual | Sí, Wipsie indica cuando usa data de sesiones |
| Datos | 100% locales, del usuario, sin cloud |

## Resumen

Wips lee sesiones terminadas de Claude Code, extrae resúmenes via OpenAI (sanitizando secrets), y los guarda en un session log diario por proyecto. NO crea entries en el feed. Wipsie usa estos logs para el briefing.

## Arquitectura

### Protocolo

```swift
protocol SessionProvider {
    var providerName: String { get }
    func discoverSessions(for repoPath: String) -> [DiscoveredSession]
}

struct DiscoveredSession {
    let id: String
    let filePath: URL
    let lastModified: Date
    let fileSize: Int64
}
```

### Nuevo Service: SessionCaptureService

- @MainActor final class
- Inyectado en AppState
- Depende de: ProjectStore, EntryStore (para leer projects), APIKeyProvider, SessionProvider(s)

### Flow al abrir la app

1. AppState.init() → SessionCaptureService.processNewSessions()
2. Para cada proyecto vinculado con captura activa:
   a. ClaudeCodeSessionProvider busca en ~/.claude/projects/{path-dashified}/
   b. Filtra: solo últimos 7 días, solo archivos que cambiaron (size/lastModified vs registro)
   c. Lee JSONL, extrae mensajes user/assistant (ignora tool_use, thinking, system)
   d. Sanitiza: remueve líneas con patterns de secrets, excluye bloques de código
   e. Envía a gpt-4o-mini (1 call por sesión, ~3000 tokens input, ~500 output)
   f. Guarda resumen en sessions_log.json bajo la fecha del día
   g. Actualiza registro de sesiones procesadas

### Persistencia

**sessions_log.json** (por proyecto):
```json
{
  "2026-03-09": [
    {
      "sessionId": "abc-123",
      "provider": "claude-code",
      "summary": "Rediseñé Wipsie como briefing...",
      "extractedAt": "2026-03-09T21:00:00Z"
    }
  ]
}
```

**processed_sessions.json** (global):
```json
{
  "abc-123": { "fileSize": 45230, "lastModified": "2026-03-09T20:00:00Z", "processedAt": "2026-03-09T21:00:00Z" }
}
```

### Sandbox Access

Al vincular repo (o en setup de Claude Code):
1. NSOpenPanel apuntando a ~/.claude/
2. Security-scoped bookmark guardado en projects.json (campo claudeBookmark)
3. Resolver en cada launch via resolveAllBookmarks()

### Sheet de Transparencia

Al activar captura pasiva para un proyecto:
- Título: "Conectar con Claude Code"
- Texto: "Wips va a leer tus sesiones de Claude Code para generar un resumen diario de tu trabajo. Solo se extraen resúmenes — no se guardan las conversaciones completas. Los datos sensibles (API keys, passwords, tokens) se filtran antes de procesarlos. Todo queda en tu máquina."
- Botones: "Conectar" / "Cancelar"

### Sanitización

Patterns a stripear de líneas:
- sk-, ghp_, gho_, AKIA, password, passwd, secret, token=, API_KEY, .env, BEGIN RSA, BEGIN PRIVATE

Además: excluir mensajes de tipo tool_use y tool_result (contienen código y outputs), solo enviar mensajes role:user y role:assistant con content tipo text.

### Toggle por Proyecto

Nueva propiedad en Project:
```swift
var sessionCaptureEnabled: Bool = true
```

UI: toggle en el menú contextual del proyecto o en la config del repo linkado.

### Indicador en Wipsie

WipsieService.buildEntrySummary incluye sección:
```
Actividad reciente con agentes:
- 2026-03-09: [resumen de sesión]
- 2026-03-08: [resumen de sesión]
```

El briefing de Wipsie menciona la fuente: "Basado en tu sesión de ayer con Claude Code, ..."

### Archivos a crear
- issue/Core/Services/SessionCaptureService.swift
- issue/Core/Services/ClaudeCodeSessionProvider.swift
- issue/Core/Protocols/SessionProvider.swift

### Archivos a modificar
- issue/App/AppState.swift (DI + trigger)
- issue/Core/Models/Project.swift (sessionCaptureEnabled, claudeBookmark)
- issue/Core/Services/WipsieService.swift (leer session logs para briefing)
- issue/Features/Home/Views/Components/NotionEntryRow.swift o similar (indicador visual)
- issue/Localizable.xcstrings (strings del sheet y toggle)

## Estimación

3-4 días. Día 1: protocolo + provider + lectura JSONL. Día 2: sanitización + OpenAI call + persistencia. Día 3: integración Wipsie + sheet + toggle. Día 4: testing con sesiones reales + ajuste de prompts.
