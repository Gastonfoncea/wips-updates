# Wips — Estrategia de Monetizacion

Fecha: 2026-03-10

## Modelo propuesto: Freemium

### Free
- Captura manual (Cmd+I)
- Hasta 1-2 proyectos
- Sin captura automatica de sesiones
- Sin Wipsie briefings

### Pro ($5-8/mes)
- Captura automatica de sesiones con agentes
- Wipsie briefings contextuales
- Proyectos ilimitados
- Historial completo de sesiones
- Contexto dinamico para agentes (.wips/AGENT.md)

## Costos estimados (gpt-4o-mini via proxy)

- 1 resumen de sesion: ~500 tokens input + 200 output ≈ $0.0001
- 1 briefing de Wipsie: ~1000 tokens input + 200 output ≈ $0.0002
- Usuario activo (3-5 sesiones/dia + 1 briefing): ≈ $0.0007/dia ≈ $0.02/mes
- 100 usuarios activos: ≈ $2/mes
- 1000 usuarios activos: ≈ $20/mes
- 10000 usuarios activos: ≈ $200/mes

## Timing

- **Launch**: todo free, proxy absorbe costos (son despreciables)
- **Con traccion (100+ usuarios activos)**: meter paywall en captura automatica + Wipsie
- **Escala (1000+)**: evaluar si el proxy sigue siendo viable o migrar a auth por usuario con key propia

## El feature que justifica cobrar

La captura automatica + contexto acumulado es lo que no existe en ningun otro lado. Es el valor por el que alguien pagaria. El note-taking con shortcut es el complemento free que atrae usuarios al funnel.

## Notas

- El costo por usuario con gpt-4o-mini es tan bajo que se puede ser generoso con el free tier
- El moat (deteccion de patrones, context feed al agente) es lo que retiene usuarios Pro
- Considerar descuento anual ($50/año en vez de $8/mes) para mejorar retencion
