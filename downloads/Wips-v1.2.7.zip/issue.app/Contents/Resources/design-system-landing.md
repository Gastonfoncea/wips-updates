# Design System — Landing Page (Tailwind/React)

Traducido del design system nativo de la app (SwiftUI). Usar estos tokens en `tailwind.config.ts` para mantener consistencia visual entre la app y la landing.

## Colors

### Backgrounds
| Token | Hex | Uso |
|-------|-----|-----|
| `background` | `#101012` | Fondo principal |
| `sidebar` | `#0D0D0F` | Fondo secundario/footer |
| `card` | `#171719` | Cards, secciones elevadas |
| `card-hover` | `#1C1C1F` | Card en hover |
| `input` | `#171719` | Campos de input |

### Borders
| Token | Valor | Uso |
|-------|-------|-----|
| `border-default` | `rgba(255, 255, 255, 0.08)` | Bordes por defecto |
| `border-hover` | `rgba(255, 255, 255, 0.14)` | Bordes en hover |
| `border-focused` | `rgba(255, 255, 255, 0.22)` | Bordes en focus |

### Text
| Token | Valor | Uso |
|-------|-------|-----|
| `text-primary` | `rgba(255, 255, 255, 0.92)` | Títulos, texto principal |
| `text-secondary` | `rgba(255, 255, 255, 0.55)` | Subtítulos, descripciones |
| `text-muted` | `rgba(255, 255, 255, 0.35)` | Texto terciario, placeholders |

### Overlays
| Token | Valor | Uso |
|-------|-------|-----|
| `hover-overlay` | `rgba(255, 255, 255, 0.06)` | Hover en elementos interactivos |
| `selected-overlay` | `rgba(255, 255, 255, 0.10)` | Estado seleccionado |

### Accent
| Token | Hex | Uso |
|-------|-----|-----|
| `accent` | `#E0E0E4` | Botones primarios, links |
| `accent-hover` | `#CCCCD0` | Botón primario en hover |
| `accent-foreground` | `#1A1A1C` | Texto sobre accent |

### Semantic
| Token | RGB | Uso |
|-------|-----|-----|
| `success` | `rgb(115, 199, 148)` | Estados exitosos, confirmaciones |
| `warning` | `rgb(230, 179, 89)` | Alertas, atención |

### Category Colors (para badges/highlights en la landing)
| Categoría | RGB |
|-----------|-----|
| `idea` | `rgb(230, 191, 122)` |
| `tarea` | `rgb(122, 140, 222)` |
| `conocimiento` | `rgb(125, 201, 161)` |
| `pensamiento` | `rgb(107, 196, 209)` |
| `inspiracion` | `rgb(181, 143, 222)` |
| `bug` | `rgb(224, 122, 122)` |
| `feature` | `rgb(122, 140, 222)` |

## Typography

- Font: Inter (sans-serif)
- Weights: 400 (regular), 500 (medium), 600 (semibold), 700 (bold)

## Border Radius

| Token | Valor | Uso |
|-------|-------|-----|
| `radius-sm` | `5px` | Badges, chips |
| `radius-md` | `7px` | Botones, inputs |
| `radius-lg` | `12px` | Cards |
| `radius-xl` | `16px` | Secciones grandes |

## Animations

| Token | Duración | Curva | Uso |
|-------|----------|-------|-----|
| `micro` | `150ms` | `ease` | Hovers, cambios de opacity/color |
| `standard` | `250ms` | `cubic-bezier(0.2, 0, 0, 1)` | Expand/collapse, toggles |
| `emphasis` | `400ms` | `spring(response: 0.4, damping: 0.7)` | Transiciones de vista, entrada de secciones |

En Framer Motion:
```tsx
// micro
transition={{ duration: 0.15, ease: "easeOut" }}

// standard
transition={{ duration: 0.25, ease: [0.2, 0, 0, 1] }}

// emphasis
transition={{ type: "spring", stiffness: 300, damping: 24 }}
```

## Button Styles

### Primary (accent)
```css
background: #E0E0E4;
color: #1A1A1C;
border-radius: 7px;
font-weight: 500;
/* hover */
background: #CCCCD0;
transform: scale(0.97); /* on press */
```

### Secondary (outlined)
```css
background: transparent;
color: rgba(255, 255, 255, 0.55);
border: 1px solid rgba(255, 255, 255, 0.08);
border-radius: 7px;
font-weight: 500;
/* hover */
background: rgba(255, 255, 255, 0.06);
border-color: rgba(255, 255, 255, 0.14);
```

## Tailwind Config Reference

```ts
// tailwind.config.ts
const config = {
  theme: {
    extend: {
      colors: {
        background: "#101012",
        sidebar: "#0D0D0F",
        card: {
          DEFAULT: "#171719",
          hover: "#1C1C1F",
        },
        input: "#171719",
        border: {
          DEFAULT: "rgba(255, 255, 255, 0.08)",
          hover: "rgba(255, 255, 255, 0.14)",
          focused: "rgba(255, 255, 255, 0.22)",
        },
        text: {
          primary: "rgba(255, 255, 255, 0.92)",
          secondary: "rgba(255, 255, 255, 0.55)",
          muted: "rgba(255, 255, 255, 0.35)",
        },
        accent: {
          DEFAULT: "#E0E0E4",
          hover: "#CCCCD0",
          foreground: "#1A1A1C",
        },
        success: "rgb(115, 199, 148)",
        warning: "rgb(230, 179, 89)",
        category: {
          idea: "rgb(230, 191, 122)",
          tarea: "rgb(122, 140, 222)",
          conocimiento: "rgb(125, 201, 161)",
          pensamiento: "rgb(107, 196, 209)",
          inspiracion: "rgb(181, 143, 222)",
          bug: "rgb(224, 122, 122)",
          feature: "rgb(122, 140, 222)",
        },
      },
      borderRadius: {
        sm: "5px",
        md: "7px",
        lg: "12px",
        xl: "16px",
      },
      transitionDuration: {
        micro: "150ms",
        standard: "250ms",
        emphasis: "400ms",
      },
    },
  },
};
```

## Design Principles

- **Dark mode only** para la landing
- **Minimalista**: mucho espacio en blanco, pocos colores
- **Estilo referencia**: Linear, Raycast, Warp
- **Sin emojis** en la UI
- **Bordes sutiles**: usar border-default, no bordes sólidos
- **Overlays para hover**: no cambiar background, usar hover-overlay encima
