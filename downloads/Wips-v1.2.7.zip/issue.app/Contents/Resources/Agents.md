# AGENTS.md - Issues Classifier

## Sobre el proyecto

App macOS para capturar issues rápidamente mediante un shortcut global. Una IA clasifica automáticamente cada issue en categorías predefinidas. La app detecta si el usuario está trabajando con Claude en un proyecto para asociar el issue automáticamente.

## Stack

- Swift 5.9+
- SwiftUI
- macOS 13+ (Ventura y posteriores)
- SwiftData para persistencia local
- Arquitectura MVVM

## Categorías de Issues

- `Bug` - Errores o comportamiento inesperado
- `Feature` - Nueva funcionalidad deseada
- `Thought` - Ideas, notas, reflexiones
- `Unclassified` - No se pudo clasificar automáticamente

## Estructura del proyecto
```
IssuesClassifier/
├── App/
│   └── IssuesClassifierApp.swift
├── Features/
│   ├── Capture/                    # UI del shortcut
│   │   ├── Views/
│   │   │   └── CaptureView.swift
│   │   └── ViewModels/
│   │       └── CaptureViewModel.swift
│   ├── IssuesList/                 # Lista de issues
│   │   ├── Views/
│   │   └── ViewModels/
│   ├── ProjectDetection/           # Detectar proyecto Claude
│   │   └── Services/
│   └── Classification/             # Lógica de IA
│       └── Services/
├── Core/
│   ├── Models/
│   │   ├── Issue.swift
│   │   ├── Project.swift
│   │   └── IssueCategory.swift
│   ├── Services/
│   │   └── ShortcutManager.swift
│   └── Storage/
│       └── SwiftData/
├── Shared/
│   ├── Components/                 # UI reutilizable
│   ├── Extensions/
│   └── Utils/
└── Resources/
```

## Arquitectura MVVM

### Models
- Datos puros, sin lógica de UI
- Usar `@Model` de SwiftData para persistencia

### ViewModels
- Clase con `@Observable` (macOS 14+) o `ObservableObject` (macOS 13)
- Toda la lógica de negocio acá
- Nunca importar SwiftUI en ViewModels (solo Combine/Foundation)

### Views
- Solo UI, sin lógica
- Delegar acciones al ViewModel
```swift
// Ejemplo correcto
struct CaptureView: View {
    @State private var viewModel = CaptureViewModel()
    
    var body: some View {
        TextField("Describe el issue...", text: $viewModel.issueText)
        Button("Guardar") {
            viewModel.saveIssue()
        }
    }
}
```

## Convenciones de código

### Naming
- Views: `NombreView` (ej: `CaptureView`, `IssuesListView`)
- ViewModels: `NombreViewModel` (ej: `CaptureViewModel`)
- Models: nombre simple (ej: `Issue`, `Project`)
- Services: `NombreService` o `NombreManager` (ej: `ClassificationService`)

### Enums para categorías
```swift
enum IssueCategory: String, Codable, CaseIterable {
    case bug = "Bug"
    case feature = "Feature"
    case thought = "Thought"
    case unclassified = "Unclassified"
}
```

### Formato
- Indentación: 4 espacios
- Máximo 120 caracteres por línea
- Llaves en misma línea

### SwiftUI
- Un View por archivo
- Extraer subviews cuando superen 30 líneas
- Usar `#Preview` para previews

### Async/Await
- Usar async/await para operaciones asíncronas
- Clasificación de IA debe ser async

## Flujo principal

1. Usuario presiona shortcut global
2. Se abre ventana flotante de captura
3. App detecta proyecto Claude activo (si existe)
4. Usuario escribe el issue
5. Al guardar: IA clasifica → se guarda en SwiftData
6. Ventana se cierra

## Detección de proyecto Claude

La app debe detectar si hay una ventana de Claude activa y extraer el nombre del proyecto. Esto puede hacerse mediante:
- Accessibility API para leer título de ventana
- O parsear el título de la ventana activa del navegador

## Persistencia

- Usar SwiftData (no Core Data)
- Todo local, sin sincronización
- Cada usuario tiene su propia base de datos

## Compatibilidad

- macOS 13.0+ (Ventura)
- Testear en macOS 13, 14 y 15
- Si usás APIs nuevas de macOS 14+, agregar `if #available`

## Prohibido

- Force unwrap (`!`) sin justificación en comentario
- `print()` en código final, usar `Logger`
- Lógica de negocio en Views
- Singletons innecesarios
- Llamadas de red (es app 100% local)

## Testing

- ViewModels deben ser testeables
- Inyectar dependencias, no hardcodear

## Commits

- En español
- Formato: `tipo: descripción`
- Tipos: `feat`, `fix`, `refactor`, `docs`, `test`
