# Design System — Issue App

Reference document for replicating the UI across platforms (landing page, web app, etc.).
All values extracted from the SwiftUI macOS source code.

---

## 1. Color Tokens

### Dark Theme

| Token | Value | Usage |
|---|---|---|
| `background` | `#101012` | App background |
| `sidebarBackground` | `#0D0D0F` | Sidebar panel |
| `cardBackground` | `#171719` | Cards, sections |
| `cardBackgroundHover` | `#1C1C1F` | Card hover state |
| `inputBackground` | `#171719` | Text inputs, search bar |
| `borderDefault` | `white @ 8%` | Default borders |
| `borderHover` | `white @ 14%` | Hovered borders |
| `borderFocused` | `white @ 22%` | Focused input borders |
| `textPrimary` | `white @ 92%` | Main text |
| `textSecondary` | `white @ 55%` | Secondary labels |
| `textMuted` | `white @ 35%` | Subtle labels, metadata |
| `hoverOverlay` | `white @ 6%` | Hover backgrounds |
| `selectedOverlay` | `white @ 10%` | Selected item backgrounds |
| `accent` | `#E0E0E4` | Primary action buttons |
| `accentHover` | `#CCCCD0` | Accent hover state |
| `accentForeground` | `#1A1A1C` | Text on accent buttons |
| `shadowColor` | `black` | Drop shadows |

### Light Theme

| Token | Value | Usage |
|---|---|---|
| `background` | `#FCFCFF` | App background |
| `sidebarBackground` | `#F5F5F8` | Sidebar panel |
| `cardBackground` | `white` | Cards, sections |
| `cardBackgroundHover` | `#F8F8FB` | Card hover state |
| `inputBackground` | `#F0F0F4` | Text inputs, search bar |
| `borderDefault` | `black @ 8%` | Default borders |
| `borderHover` | `black @ 14%` | Hovered borders |
| `borderFocused` | `black @ 22%` | Focused input borders |
| `textPrimary` | `black @ 88%` | Main text |
| `textSecondary` | `black @ 50%` | Secondary labels |
| `textMuted` | `black @ 40%` | Subtle labels, metadata |
| `hoverOverlay` | `black @ 4%` | Hover backgrounds |
| `selectedOverlay` | `black @ 7%` | Selected item backgrounds |
| `accent` | `#2D2D30` | Primary action buttons |
| `accentHover` | `#3A3A3E` | Accent hover state |
| `accentForeground` | `white` | Text on accent buttons |
| `shadowColor` | `black @ 15%` | Drop shadows |

### Category Colors (Adaptive)

Each color has a light variant (darker/more saturated) and a dark variant (brighter/softer).

| Category | Light RGB | Dark RGB | Hex Dark (approx) |
|---|---|---|---|
| Idea | `(0.78, 0.66, 0.32)` | `(0.90, 0.75, 0.48)` | `#E6BF7A` |
| Conocimiento | `(0.32, 0.64, 0.50)` | `(0.49, 0.79, 0.63)` | `#7DC9A0` |
| Tarea | `(0.38, 0.44, 0.78)` | `(0.48, 0.55, 0.87)` | `#7A8CDE` |
| Inspiración | `(0.58, 0.44, 0.78)` | `(0.71, 0.56, 0.87)` | `#B58FDE` |
| Bitácora | `(0.38, 0.54, 0.72)` | `(0.48, 0.64, 0.80)` | `#7AA3CC` |
| Recordatorio | `(0.78, 0.50, 0.34)` | `(0.88, 0.58, 0.43)` | `#E0946E` |
| Fecha Importante | `(0.85, 0.22, 0.22)` | `(0.94, 0.56, 0.56)` | `#F08F8F` |
| Imagen | `(0.30, 0.62, 0.70)` | `(0.42, 0.77, 0.82)` | `#6BC4D1` |

### Task Subtype Colors (Adaptive)

| Type | Light RGB | Dark RGB | Hex Dark (approx) |
|---|---|---|---|
| Bug | `(0.78, 0.38, 0.38)` | `(0.88, 0.48, 0.48)` | `#E07A7A` |
| Feature | `(0.38, 0.44, 0.78)` | `(0.48, 0.55, 0.87)` | `#7A8CDE` |
| Thought | `(0.30, 0.62, 0.68)` | `(0.42, 0.77, 0.82)` | `#6BC4D1` |
| Unclassified | `(0.45, 0.50, 0.58)` | `(0.55, 0.58, 0.65)` | `#8C94A6` |
| Question | `(0.74, 0.58, 0.28)` | `(0.83, 0.66, 0.34)` | `#D4A856` |

**Color philosophy**: Muted, desaturated tones inspired by Linear/Raycast. Tech-forward, not playful. Light mode uses darker/more saturated variants; dark mode uses brighter/softer variants.

---

## 2. Typography

### System Font (SF Pro)

The app uses the system font exclusively. No custom fonts.

| Role | Size | Weight | Design | Tracking | Usage |
|---|---|---|---|---|---|
| Page title | 20px | `.semibold` | default | — | Project name in feed header |
| Section title | 15px | `.semibold` | default | `1.1` | Category section headers |
| Body | `.body` (~13px) | `.regular` | default | — | Entry text, input fields |
| Body compact | `.callout` (~12px) | `.regular` | default | — | Compact timeline entries |
| Subheadline | `.subheadline` (~11px) | `.medium`/`.semibold` | default | — | Buttons, sidebar items, labels |
| Caption | `.caption` (~10px) | `.regular` | default | — | Timestamps, secondary info |
| Caption2 | `.caption2` (~9px) | `.regular` | `.monospaced` | — | Counts, metadata, "nuevas" |
| Sidebar header | `.subheadline` | `.semibold` | default | `1.0` | "PROYECTOS" label |
| Task type header | `.caption` | `.medium` | default | `1.5` | "FEATURE", "BUG" labels |
| Empty state (large) | 40px | `.light` | default | — | Feed empty state icon |
| Empty state (medium) | 32px | `.light` | default | — | Category manager empty |

### Monospaced Usage

`.fontDesign(.monospaced)` is used for:
- Entry counts in parentheses
- "nuevas" unseen indicators
- Timestamps and dates
- Keyboard shortcut hints
- Sidebar entry count numbers

---

## 3. Spacing

### Padding Scale

| Size | Usage |
|---|---|
| `2px` | Minimal vertical padding (compact rows) |
| `4px` | Tight spacing (between sections, small gaps) |
| `5px` | Filter chip vertical padding |
| `6px` | Small input padding, icon+text gap |
| `8px` | Standard content padding, section spacing |
| `10px` | Search bar padding, filter chips horizontal |
| `12px` | Panel content padding, section gaps |
| `14px` | Button horizontal padding (LinearButtonStyle) |
| `16px` | Standard panel padding, sidebar horizontal |
| `20px` | Large section padding |
| `24px` | Section bottom margins (pinned, categories) |
| `32px` | Feed view main padding (all sides) |

### Stack Spacing

| Size | Usage |
|---|---|
| `0` | Tight lists (entry rows, no visual gap) |
| `4px` | Entry groups within sections |
| `6px` | Icon + text in HStack, FlowLayout default |
| `8px` | Standard VStack content spacing |
| `10px` | Timeline row icon + content |
| `12px` | Search/filter area spacing |
| `16px` | Large section spacing (task type groups) |

---

## 4. Border Radius

| Radius | Usage |
|---|---|
| `4px` | Small hover overlays, category item hover |
| `6px` | **Default** — buttons, cards, list rows, inputs, sections (most common) |
| `8px` | Search bar, large text fields, image containers |
| `10px` | Input panel text area, image thumbnails |
| `18px` | Input panel outer container (expanded) |
| `22px` | Input panel outer container (collapsed) |
| `28px` | Input panel initial/minimal state |

**Rule of thumb**: `6px` for interactive elements, `8px` for containers, `10px+` for panels.

---

## 5. Shadows

| Component | Radius | Offset (x, y) | Color/Opacity |
|---|---|---|---|
| Subtle (cards) | `2` | `(0, 1)` | `black @ 40%` |
| Medium (feed cards) | `8` | `(0, 4)` | `theme.shadowColor @ 12%` |
| Large (floating panels) | `30` | `(0, 10)` | `black @ 30%` |
| Large + subtle (panels) | `30` + `2` | `(0, 10)` + `(0, 1)` | `black @ 30%` + `black @ 10%` |

**Pattern**: Floating panels use a dual-shadow approach — one large diffuse shadow + one tight contact shadow.

---

## 6. Animation Tokens

| Token | Duration | Curve | Usage |
|---|---|---|---|
| `micro` | `150ms` | `.smooth` | Hover states, color changes, small transitions |
| `standard` | `250ms` | `.snappy` | Expand/collapse, checkbox, section reveal |
| `emphasis` | `350ms` | `.spring(response: 0.4, damping: 0.7)` | Toasts, view transitions, drag feedback |
| Input panel spring | `350ms` | `.spring(response: 0.35, damping: 0.78)` | Panel presentation |
| View mode crossfade | `200ms` | `.easeInOut` | Grouped ↔ timeline switch |
| Sidebar hover | `150ms` | `.easeInOut` | Project row hover |

### CSS equivalents

```css
/* micro */
transition: all 150ms cubic-bezier(0.4, 0, 0.2, 1);

/* standard */
transition: all 250ms cubic-bezier(0.2, 0, 0, 1);

/* emphasis */
transition: all 350ms cubic-bezier(0.34, 1.56, 0.64, 1);

/* easeInOut (crossfade, hover) */
transition: all 200ms ease-in-out;
```

---

## 7. Button Styles

### Ghost Button (secondary actions)

Used for: "+ Categoría", "Filtrar", most toolbar actions.

```
Font: 11px, weight medium
Padding: 10px horizontal, 5px vertical
Border radius: 6px
Border: borderDefault, 0.5px
Background: clear (default) → hoverOverlay (hover)
Text: textMuted (default) → textPrimary (hover)
Animation: micro (150ms)
```

### Linear Button (standard actions)

Used for: Save, Delete, form actions.

```
Font: subheadline (~11px), weight medium
Padding: 14px horizontal, 7px vertical
Border radius: 7px
Border: borderDefault, 1px
Background: clear (default) → hoverOverlay (hover)
Text: textSecondary
Scale: 0.97 on press
Animation: micro (150ms)
```

### Accent Button (primary actions)

Used for: Primary submit/confirm actions (reserved).

```
Background: accent (default) → accentHover (hover)
Text: accentForeground
```

### Icon Button (minimal)

Used for: Close, clear, small actions.

```
Size: 22–26px frame
Background: clear or hoverOverlay
Icon: textMuted (default) → textPrimary (hover)
```

---

## 8. Component Patterns

### Card / Section

```
Background: cardBackground
Border radius: 6–8px
Padding: 8–12px horizontal
Border: borderDefault (optional, 0.5px)
Hover: cardBackgroundHover or hoverOverlay
```

### Input Field

```
Background: inputBackground
Border radius: 6px (small) / 8px (large)
Padding: 8px horizontal, 6px vertical (small) / 12px horizontal, 8px vertical (large)
Border: borderDefault → borderFocused on focus
Font: subheadline
Placeholder: textMuted
```

### Section Header

```
Left accent bar: 3px wide × 16px tall, category color
Title: 15px semibold, tracking 1.1, textPrimary
Count: caption2 monospaced, textMuted
Unseen badge: caption2 monospaced, categoryColor @ 85%
Chevron: 9px semibold, rotates 0° → 90° on expand
Animation: standard (250ms)
```

### Task Checkbox

```
Size: 16×16
Border: 1.5px stroke, category accent color
Unchecked: stroke @ 70% opacity
Checked: filled circle + white checkmark (8px bold)
Ring pulse on complete: scales 1.0 → 2.2, opacity 0.5 → 0
Pulse duration: 350ms
```

### Sidebar Project Row

```
Font: subheadline
Selected: semibold, white text, system accent background
Normal: regular weight, textPrimary
Count: caption monospaced, textMuted (or white @ 70% when selected)
Hover: hoverOverlay background, 150ms easeInOut
```

### Filter Chip

```
Font: 11px, weight medium
Padding: 10px horizontal, 5px vertical
Border radius: 6px
Unselected: borderDefault stroke (0.5px), hoverOverlay on hover
Selected: color @ 12% background, color @ 30% stroke
Dot indicator: 6×6 circle, filled with category color
```

### Timeline Row

```
Bullet: 8×8 circle, category color
Spacing: 10px between bullet and content
Padding: 3–6px vertical, 8px horizontal
Compact mode: uses .callout font
Hover: categoryColor @ 8% background
```

### Image Grid (Pinterest-style)

```
Grid: adaptive columns, minimum 140px
Aspect ratio: square (1:1), content fill
Border radius: 10px
Hover overlay: black @ 40%, shows date + delete button
Click: opens full preview
```

---

## 9. Layout

### Window

```
Min size: 850 × 600
Ideal width: 1050
```

### Structure

```
┌─────────────────────────────────────────────┐
│ NavigationSplitView                         │
├──────────┬──────────────────────────────────┤
│ Sidebar  │ HSplitView (resizable)           │
│ 220px    │ ┌──────────────┬───────────────┐ │
│ min 180  │ │ FeedView     │ ChatPanel     │ │
│          │ │ ideal 400    │ ideal 340     │ │
│          │ │ min 300      │ min 280       │ │
│          │ │ padding 32   │ max 420       │ │
│          │ │ content 720  │               │ │
│          │ └──────────────┴───────────────┘ │
└──────────┴──────────────────────────────────┘
```

### Sidebar

```
Width: min 180px, ideal 220px
Padding: 16px horizontal, 16px top, 12px bottom
List style: macOS sidebar (native)
Divider: 1px, borderDefault
```

### Feed Content

```
Max content width: 720px (grouped view, centered)
Main padding: 32px all sides
Section bottom margin: 24px
```

---

## 10. Icons

System SF Symbols only. No custom icons.

### Common Icons

| Icon | Usage |
|---|---|
| `plus` | Add/create actions |
| `xmark` | Close, delete, clear |
| `xmark.circle.fill` | Clear search, remove item |
| `arrow.up.circle.fill` | Send/submit |
| `chevron.right` | Expand/collapse (rotates 90°) |
| `line.3.horizontal.decrease` | Filter |
| `magnifyingglass` | Search |
| `paperclip` | Attachments |
| `photo` | Images |
| `photo.on.rectangle.angled` | Image category |
| `trash` | Delete |
| `checkmark` | Task completion |
| `checkmark.circle.fill` | Completed state |
| `pin.fill` | Pinned entries |
| `archivebox` | Archive |
| `folder` | Folders |
| `cpu` | AI classification |
| `ellipsis` | More actions menu |

### Icon Sizes

| Size | Usage |
|---|---|
| `7–9px` | Chevrons, small indicators |
| `10–11px` | Toolbar action icons, filter icons |
| `20px` | Send button |
| `22px` | Modal action icons |

---

## 11. Interaction Patterns

### Hover

All interactive elements respond to hover with `150ms` timing:
- **Text**: `textMuted` → `textPrimary`
- **Background**: `clear` → `hoverOverlay`
- **Borders**: `borderDefault` → `borderHover`
- **Icons**: opacity or color shift

### Press

- **Scale**: `0.97` on buttons (LinearButtonStyle)
- **Timing**: `micro` (150ms)

### Drag & Drop

- **Visual**: Border color changes on drag-over
- **Drop indicator**: 2px height bar with rounded corners
- **Animation**: `micro` for state transitions

### View Mode Transition

- **Type**: Crossfade (opacity)
- **Duration**: 200ms easeInOut
- **Triggers**: Segmented picker toggle

### Section Expand/Collapse

- **Chevron rotation**: 0° → 90°
- **Content**: Conditional render (no animation on content, chevron animates with `standard`)

---

## 12. CSS Custom Properties (for web implementation)

```css
:root {
  /* Dark theme */
  --bg: #101012;
  --bg-sidebar: #0D0D0F;
  --bg-card: #171719;
  --bg-card-hover: #1C1C1F;
  --bg-input: #171719;
  --border: rgba(255, 255, 255, 0.08);
  --border-hover: rgba(255, 255, 255, 0.14);
  --border-focus: rgba(255, 255, 255, 0.22);
  --text-primary: rgba(255, 255, 255, 0.92);
  --text-secondary: rgba(255, 255, 255, 0.55);
  --text-muted: rgba(255, 255, 255, 0.35);
  --hover-overlay: rgba(255, 255, 255, 0.06);
  --selected-overlay: rgba(255, 255, 255, 0.10);
  --accent: #E0E0E4;
  --accent-hover: #CCCCD0;
  --accent-fg: #1A1A1C;
  --shadow: 0, 0, 0;
  --radius-sm: 4px;
  --radius-default: 6px;
  --radius-md: 8px;
  --radius-lg: 10px;
  --radius-xl: 18px;
}

[data-theme="light"] {
  --bg: #FCFCFF;
  --bg-sidebar: #F5F5F8;
  --bg-card: #FFFFFF;
  --bg-card-hover: #F8F8FB;
  --bg-input: #F0F0F4;
  --border: rgba(0, 0, 0, 0.08);
  --border-hover: rgba(0, 0, 0, 0.14);
  --border-focus: rgba(0, 0, 0, 0.22);
  --text-primary: rgba(0, 0, 0, 0.88);
  --text-secondary: rgba(0, 0, 0, 0.50);
  --text-muted: rgba(0, 0, 0, 0.40);
  --hover-overlay: rgba(0, 0, 0, 0.04);
  --selected-overlay: rgba(0, 0, 0, 0.07);
  --accent: #2D2D30;
  --accent-hover: #3A3A3E;
  --accent-fg: #FFFFFF;
  --shadow: 0, 0, 0;
}
```

### Category Colors as CSS (dark theme)

```css
:root {
  --color-idea: rgb(230, 191, 122);
  --color-conocimiento: rgb(125, 201, 160);
  --color-tarea: rgb(122, 140, 222);
  --color-inspiracion: rgb(181, 143, 222);
  --color-bitacora: rgb(122, 163, 204);
  --color-recordatorio: rgb(224, 148, 110);
  --color-fecha-importante: rgb(240, 143, 143);
  --color-imagen: rgb(107, 196, 209);
  --color-bug: rgb(224, 122, 122);
  --color-feature: rgb(122, 140, 222);
  --color-thought: rgb(107, 196, 209);
  --color-unclassified: rgb(140, 148, 166);
  --color-question: rgb(212, 168, 86);
}
```

### Animation Utilities as CSS

```css
.transition-micro { transition: all 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.transition-standard { transition: all 250ms cubic-bezier(0.2, 0, 0, 1); }
.transition-emphasis { transition: all 350ms cubic-bezier(0.34, 1.56, 0.64, 1); }
```
