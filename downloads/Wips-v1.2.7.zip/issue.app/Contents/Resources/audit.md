# Auditoría del Proyecto — 2026-02-09

## 1. Archivos sin usar

### GeminiService.swift
- **Ruta**: `issue/Services/GeminiService.swift`
- El propio archivo dice: *"Este servicio no está siendo usado actualmente. Fue reemplazado por OpenAIService debido a restricciones regionales del free tier de Gemini."*
- No se referencia en ningún otro archivo. Se puede eliminar.

### SectionView.swift (legacy)
- **Ruta**: `issue/Features/Home/Views/Components/SectionView.swift`
- Marcado como `// MARK: - Legacy SectionView (mantener compatibilidad)`
- `SectionView(` no se instancia en ningún lugar del proyecto. Fue reemplazado por `SubcategorySectionView`.
- El `#Preview` del archivo muestra otras vistas (CategoryCardView, TaskCardView), no SectionView en sí.
- Se puede eliminar.

### InputView.swift
- **Ruta**: `issue/Features/Capture/InputView.swift`
- Define `struct InputView: View` pero nunca se instancia (`InputView(` no aparece en el proyecto).
- `InputPanelController.swift` tiene su propia `InputPanelView` privada (línea 96) que duplica toda la funcionalidad.
- Se puede eliminar.

### Entry.issueTypes (propiedad muerta)
- **Ruta**: `issue/Core/Models/Entry.swift:52`
- `static let issueTypes: [EntryType] = [.feature, .bug, .thought, .unclassified]`
- No se usa en ningún lugar del proyecto. Se puede eliminar.

### Typealiases sin usar
- `issue/Features/Home/Views/Components/CategoryCardView.swift:108` → `typealias CategorySectionView = CategoryCardView`
- `issue/Features/Home/Views/Components/TaskCardView.swift:86` → `typealias TaskSectionView = TaskCardView`
- Ninguno de los dos se referencia. Son restos del refactor anterior. Se pueden eliminar.

---

## 2. Código duplicado

### InputView vs InputPanelView (duplicación mayor)
- `issue/Features/Capture/InputView.swift` (líneas 11-154)
- `issue/Services/InputPanelController.swift` → `InputPanelView` privada (líneas 96-240)
- Casi idénticos: TextEditor, manejo de imágenes, drag-and-drop, file importer.
- Diferencia: InputPanelView tiene botón dismiss y callback `onDismiss`.
- **Solución**: Eliminar InputView.swift (no se usa), o refactorizar InputPanelController para reutilizar InputView con un parámetro de dismiss.

### Inline text fields: ProjectTabsView vs RootView
- `issue/Shared/Components/ProjectTabsView.swift` (líneas 107-140): implementa campos de texto inline con `TextField` crudo.
- `issue/Features/Home/Views/RootView.swift` (líneas 270-316): implementa lo mismo usando `ThemedTextField`.
- **Solución**: ProjectTabsView debería usar `ThemedTextField` para ser consistente.

### Lógica de rename duplicada
- **ProjectTabsView.swift**: `@State renamingProject`, `renameText`, `commitRename()`, `cancelRename()` (líneas 19-21, 160-171)
- **RootView.swift**: mismo patrón exacto para projects y folders (líneas 23-29, 344-368)
- **Solución**: Extraer en un ViewModifier o helper reutilizable.

---

## 3. Patrones inconsistentes

### Naming: TimeLineRow vs el resto
- Archivo: `TimeLineRow.swift`, struct: `TimeLineRow` (L mayúscula en "Line")
- Convención del resto del proyecto: palabras compuestas sin separar (ej: `SubcategorySectionView`, `TimelineEntries`)
- **Solución**: Renombrar a `TimelineRow` / `TimelineRow.swift`.

### Ubicación de componentes compartidos
- `ImagePreviewSheet` está definido dentro de `ImagesCardView.swift` (línea 44) pero se usa también desde `EntryRow.swift` vía `AttachmentThumbnailsView`.
- No es un error funcional (mismo módulo), pero la ubicación es confusa.
- **Solución**: Mover `ImagePreviewSheet` a `Shared/Components/`.

### HomeView.swift no contiene HomeView
- `issue/Features/Home/Views/HomeView.swift` solo contiene `FilterChipsBar` y `FlowLayout`.
- El nombre del archivo no refleja su contenido.
- **Solución**: Renombrar a `FilterChipsBar.swift` o mover a `Shared/Components/`.

### autoCollapse inconsistente entre cards
- `TaskCardView`, `CategoryCardView`, `CustomCategoryCardView` tienen `autoCollapse` con lógica en `onAppear`.
- `PinnedCardView` e `ImagesCardView` no lo tienen.
- No es un bug, pero es inconsistente si el feed crece.

---

## 4. Resumen

| Tipo | Cantidad | Impacto |
|------|----------|---------|
| Archivos eliminables | 3 | Reduce complejidad |
| Código muerto (props/typealiases) | 3 | Limpieza menor |
| Duplicaciones mayores | 2 | Deuda técnica |
| Duplicaciones menores | 1 | Consistencia |
| Inconsistencias de naming | 2 | Legibilidad |
| Componentes mal ubicados | 2 | Organización |
