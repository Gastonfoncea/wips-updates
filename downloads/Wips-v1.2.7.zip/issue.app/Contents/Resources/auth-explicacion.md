# Auth: Problema y Solucion

## El problema original

La app usa OpenAI (clasificacion, chat, Wipsie, etc.) pero no queremos que cada usuario ponga su propia API key. Entonces creamos un **proxy** en Vercel que guarda la API key de OpenAI y la app le habla al proxy.

Para que no cualquiera use el proxy, teniamos un **token estatico** (`WIPS_PROXY_TOKEN`) embebido en la app. El proxy lo verificaba en el header `X-Issue-Token`.

**El problema:** los usuarios son devs. Pueden abrir el binario de la app, extraer ese token, y usar el proxy (y nuestra plata de OpenAI) para lo que quieran. Un solo token compartido por todos, imposible de revocar sin romperle la app a todos.

## La solucion: Apple Sign In + JWT

En vez de un token estatico compartido, ahora cada usuario se autentica con su Apple ID y recibe su propio **JWT temporal** (1 hora). Si alguien abusa, le revocamos la sesion sin afectar a nadie mas.

**Flujo:**
1. El usuario hace Sign In with Apple en la app
2. La app manda el identity token de Apple al proxy (`/api/auth/apple`)
3. El proxy verifica con Apple que es legitimo, crea un JWT de 1h + un refresh token de 30 dias, y los devuelve
4. La app usa el JWT en `Authorization: Bearer` para cada request
5. Cuando el JWT expira, la app usa el refresh token para pedir uno nuevo (`/api/auth/refresh`)
6. Si el usuario revoca acceso desde su Apple ID, Apple le avisa al proxy (`/api/auth/apple-revoke`) y se borran todas sus sesiones

## Lo que se hizo (2026-03-15 y 2026-03-16)

### Implementacion (2026-03-15)
- Proxy: endpoints de auth (login, refresh, revoke), Redis (Upstash), rate limiting por usuario
- App: AuthService, AppleSignInCoordinator, AuthView, APIKeyProvider con executeRequest() y retry en 401

### Limpieza del legacy (2026-03-16)
- Se borro `ISSUE_APP_TOKEN` de Vercel (el proxy ya no acepta `X-Issue-Token`)
- Se limpio de la app toda referencia a `WIPS_PROXY_TOKEN`, `proxyToken`, `X-Issue-Token` y `WipsProxyToken` de Info.plist
- Se configuro el webhook de revocacion en Apple Developer Portal

### Resultado

Antes: un token estatico extraible → cualquier dev podia usar el proxy gratis.
Ahora: JWT por sesion + Apple Sign In → cada usuario tiene su propia sesion, revocable individualmente, con rate limiting por usuario.
