# Backlog Urgente

## BUG: Pérdida de datos al cambiar bundle identifier

**Prioridad:** CRITICA
**Estado:** Pendiente
**Detectado:** 2026-03-15

### Qué pasó

Al cambiar el bundle identifier de `Noone.issue` a `com.gastonfoncea.wips`, macOS crea un nuevo sandbox container vacío (`~/Library/Containers/com.gastonfoncea.wips/`). Los datos del usuario quedan en el container viejo (`~/Library/Containers/Noone.issue/`) y la app arranca como si fuera nueva — todos los proyectos y entries desaparecen.

### Por qué es crítico

- El usuario pierde todos sus datos sin aviso
- No hay backup automático ni forma de recuperar desde la app
- Cualquier usuario que actualice desde una versión con el bundle ID viejo va a perder todo

### Qué hay que hacer

1. **MigrationService**: Agregar detección del container viejo (`Noone.issue`). Si existe y tiene datos, copiarlos al container nuevo antes de inicializar los stores.
2. **Backup automático**: Implementar backup periódico de `projects.json` y entries para que haya forma de recuperar ante cualquier pérdida.
3. **Verificación en AppState.init**: Antes de crear stores, verificar si el directorio de datos está vacío y existe un container legacy — si es así, migrar.

### Containers involucrados

- Viejo: `~/Library/Containers/Noone.issue/Data/Library/Application Support/Wips/`
- Nuevo: `~/Library/Containers/com.gastonfoncea.wips/Data/Library/Application Support/Wips/`

### Fix temporal aplicado (2026-03-15)

Se copiaron manualmente los archivos del container viejo al nuevo:
- `projects.json` (7 proyectos)
- `projects/` (entries de cada proyecto)
- `folders.json`, `seen_entries.json`, `wipsie_cache.json`
