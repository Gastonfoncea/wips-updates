# Classification System Log

Registro de iteraciones del sistema de clasificacion AI. Cada version documenta el enfoque usado, cuanto duro, y por que se cambio.

---

## V1 — Sistema inicial (05/02/2026 – 13/02/2026)

**Modelo:** `gpt-4o-mini` | **Temperature:** 0 | **Max tokens:** 20

### Pipeline

Dos pasos secuenciales:
1. **Texto → Categoria** (idea, conocimiento, tarea, inspiracion, bitacora, recordatorio, fecha_importante, + custom categories)
2. **Texto → Tipo** (solo si categoria == tarea): feature, bug, thought, question

### Prompt de categoria

```
Classify the following text into exactly ONE of these categories:
- "idea": a new concept, creative thought, or innovation proposal
- "conocimiento": learning, reference material, documentation, or acquired knowledge
- "tarea": a task, action item, feature request, bug report, or something to do
- "inspiracion": visual inspiration, design reference, or creative stimulus
- "bitacora": a log entry, journal note, daily record, or progress update
- "recordatorio": a reminder, something to remember, follow-up, or pending action to revisit later
- "fecha_importante": an important date, deadline, event, or scheduled item
[+ custom categories dinamicamente]

Respond with ONLY the category name in lowercase (use underscore instead of spaces). No explanation.

Text: [input]
```

### Prompt de tipo (solo tareas)

```
Classify the following task into exactly ONE of these types:
- "feature": a new functionality, enhancement, or improvement request
- "bug": a problem, error, defect, or something broken that needs fixing
- "thought": a reflection, consideration, or observation about the project
- "question": a doubt, question to investigate, or something to ask/research

Respond with ONLY the type name in lowercase. No explanation.

Text: [input]
```

### Configuracion tecnica

- Sin system prompt (solo user message)
- Matching por `String.contains()` en la respuesta
- Custom categories se checkean primero (mas especificas)
- Custom categories se asignan con `category: .tarea` + `customCategoryId`

### Problemas detectados

1. **Sesgo fuerte hacia `.tarea`** — La mayoria de los inputs terminan como tarea
2. **Fallbacks todos a `.tarea`:**
   - API falla → `.tarea` (OpenAIService.swift:74)
   - Respuesta no reconocida → `.tarea` (OpenAIService.swift:100)
   - `ClassificationResult.unclassified` = `.tarea` (ClassificationService.swift:22)
3. **Descripcion de "tarea" demasiado amplia:** "a task, action item, feature request, bug report, or something to do" — captura casi cualquier input accionable
4. **Descripcion de "idea" demasiado restrictiva:** "a new concept, creative thought, or innovation proposal" — solo cubre conceptos abstractos
5. **Sin system prompt:** El modelo no tiene contexto del dominio ni instrucciones sobre como desambiguar
6. **Overlap entre categorias:** "feature request" esta en tarea, pero podria ser idea. "something to remember" podria ser recordatorio o bitacora
7. **Prompts en ingles, inputs en espanol:** Posible mismatch linguistico

### Motivo de cambio

Sesgo fuerte a tarea, fallbacks hardcodeados, sin system prompt, sin categoria para pensamientos. Reemplazado por V2.

---

## V2 — Desambiguacion + pensamiento (13/02/2026 – presente)

**Modelo:** `gpt-4o-mini` | **Temperature:** 0 | **Max tokens:** 20

### Cambios respecto a V1

1. **Nueva categoria `.pensamiento`**: reflexiones, observaciones, preguntas, feedback, notas sueltas. Ya no son subtipo oculto de tarea.
2. **Eliminados `EntryType.thought` y `.question`**: Solo quedan `feature`, `bug`, `unclassified` como subtipos de tarea.
3. **System prompt nuevo**: Contexto del dominio + reglas de desambiguacion explicitas (bilingue ES/EN).
4. **Prompts bilingues reescritos**: Descripciones expandidas en espanol e ingles para cada categoria.
5. **Retry + fallback neutral**: Si la API falla o la respuesta no matchea, reintenta 1 vez. Si falla 2 veces, fallback a `.pensamiento` (no `.tarea`).
6. **`ClassificationResult.unclassified`** cambiado de `.tarea` a `.pensamiento`.
7. **Migracion de datos**: Decoder en `Entry.swift` convierte entries con type "Thought"/"Question" a `.pensamiento` automaticamente al cargar.

### System prompt

```
Sos un clasificador de texto para una app de captura rapida de ideas, tareas y notas.
Los usuarios escriben en espanol o ingles, textos cortos sobre proyectos personales y de desarrollo de producto.

You are a text classifier for a quick-capture app for ideas, tasks, and notes.
Users write in Spanish or English, short texts about personal and product/development projects.

REGLAS DE DESAMBIGUACION:
- No todo lo que contiene un verbo de accion es una tarea.
- "Averiguar X", "Investigar Y", "Pensar sobre Z" son pensamientos, NO tareas.
- Una TAREA es algo concreto y accionable con un resultado claro.
- Una IDEA es una propuesta, sugerencia o concepto nuevo.
- Un PENSAMIENTO es una reflexion, observacion, pregunta, feedback, o nota suelta.
```

### Prompt de categoria

```
Clasifica el siguiente texto en exactamente UNA de estas categorias:
Classify the following text into exactly ONE of these categories:

- "idea": propuesta, sugerencia, concepto nuevo, mejora potencial, "podriamos...", "seria bueno..."
  / a proposal, suggestion, new concept, potential improvement
- "tarea": accion concreta y accionable con resultado claro: arreglar bug, implementar feature, deploy
  / a concrete, actionable item with a clear outcome: fix, implement, deploy, build
- "pensamiento": reflexion, observacion, pregunta, feedback de usuario, nota suelta, "me pregunto si..."
  / a reflection, observation, question, user feedback, loose note
- "conocimiento": aprendizaje, referencia, documentacion, dato util, TIL, "aprendi que..."
  / learning, reference material, documentation, useful fact
- "inspiracion": inspiracion visual, referencia de diseno, estimulo creativo
  / visual inspiration, design reference, creative stimulus
- "bitacora": registro diario, progreso, "hoy hice...", log de trabajo
  / daily log, progress note, work journal
- "recordatorio": algo a recordar, follow-up, accion pendiente para despues
  / a reminder, follow-up, pending action for later
- "fecha_importante": fecha limite, evento, deadline programado
  / an important date, deadline, scheduled event
[+ custom categories]

Responde SOLO con el nombre de la categoria en minusculas (usa _ en vez de espacios). Sin explicacion.
Respond with ONLY the category name in lowercase (use _ instead of spaces). No explanation.

Texto / Text: [input]
```

### Prompt de tipo (solo tareas)

```
Clasifica la siguiente tarea en exactamente UNO de estos tipos:
Classify the following task into exactly ONE of these types:

- "feature": funcionalidad nueva, mejora, enhancement
  / new functionality, enhancement, improvement
- "bug": problema, error, defecto, algo roto que hay que arreglar
  / a problem, error, defect, something broken to fix

Responde SOLO con el nombre del tipo en minusculas. Sin explicacion.
Respond with ONLY the type name in lowercase. No explanation.

Texto / Text: [input]
```

### Configuracion tecnica

- System prompt con contexto del dominio y reglas de desambiguacion
- Prompts bilingues (ES/EN)
- Retry: 1 reintento si la respuesta no matchea ninguna categoria
- Fallback: `.pensamiento` despues de 2 intentos fallidos (neutral, no sesga a tarea)
- `ClassificationResult.unclassified` = `.pensamiento`
- Matching sigue siendo por `String.contains()` en la respuesta

### Resultados observados

Pendiente — documentar despues de testing en produccion.

### Motivo de cambio

Pendiente — documentar cuando se implemente V3.

---

## Template para futuras versiones

```
## VX — [nombre descriptivo] (fecha inicio – fecha fin)

**Modelo:** ... | **Temperature:** ... | **Max tokens:** ...

### Cambios respecto a V(X-1)
- ...

### Prompt de categoria
[prompt completo]

### Prompt de tipo
[prompt completo]

### Resultados observados
- ...

### Motivo de cambio
- ...
```
