# Wips — Mapa de Arquitectura

Este documento es el mapa mental de toda la app. Explica que hace cada parte, por que esta asi, y como se conecta con el resto. Se actualiza despues de cada cambio arquitectural importante via `/architecture-log`.

Ultima actualizacion: 2026-03-10

---

## 1. Como arranca la app

```
issueApp (@main)
  → AppDelegate.applicationDidFinishLaunching()
    → ShortcutManager.shared.registerCmdI()     // Registra Cmd+I global
  → issueApp.init()
    → AppState()                                  // DI container, crea todo
    → SidebarViewModel, FeedViewModel, InputViewModel, ChatViewModel
  → WindowGroup { RootView }
  → Settings { SettingsView }
  → appDelegate.setupInputPanel(inputVM:)         // Panel flotante Cmd+I
```

**AppState** es el cerebro de la inicializacion. En orden:
1. Migra carpeta vieja (`~/Issue/` → `~/Wips/`)
2. Crea todos los stores y servicios
3. Resuelve bookmarks de repos linkeados (sandbox)
4. Importa cambios de markdown de todos los repos
5. Arma file watchers para cada repo linkeado
6. Exporta estado actual a markdown
7. Lanza procesamiento de sesiones de Claude Code (en background)

---

## 2. Donde vive la data

Todo en `~/Library/Application Support/Wips/`:

```
Wips/
├── projects.json                           # Lista de proyectos
├── folders.json                            # Carpetas del sidebar
├── custom_categories.json                  # Categorias custom del usuario
├── seen_entries.json                        # IDs de entries ya vistos
├── wipsie_cache.json                        # Cache de briefings (1 por dia)
├── processed_sessions.json                  # Metadata de sesiones ya procesadas
└── projects/
    └── {projectID}/
        ├── entries.json                     # Entries de este proyecto
        ├── sessions_log.json                # Resumenes de sesiones de agentes
        └── attachments/
            └── {entryID}-001.png            # Imagenes adjuntas
```

En repos linkeados:
```
repo/
└── .wips/
    ├── ISSUES.md    # Mirror bidireccional de entries
    └── AGENT.md     # Instrucciones para agentes AI
```

**Persistencia**: JSON plano, save manual en cada operacion CRUD. No hay base de datos.

---

## 3. Modelos de datos

### Entry (la unidad principal)
- `id`, `text`, `category` (EntryCategory enum), `createdAt`
- Optional: `type` (Feature/Bug, solo si category==.tarea), `customCategoryId`, `attachmentFileNames`, `sortOrder`, `updatedAt`
- Flags: `isCompleted`, `isPinned`, `isArchived`
- Tiene migracion legacy: entries viejos con "Thought"/"Question" se convierten a `.pensamiento`

### Project (contenedor de entries)
- `id`, `name`, optional `repoPath` + `repoBookmark` (para sync con repos)
- `sessionCaptureEnabled` (bool, para captura pasiva)
- `lastOpenedAt` (usado por Wipsie para detectar cuanto tiempo estuvo ausente)
- Proyectos especiales: `.all` (virtual, todos los entries) y `.general` (default)

### CustomCategory (categorias del usuario)
- `name`, `descriptionForAI` (prompt para el clasificador), `colorHex`, `iconName`
- `nameSlug`: version normalizada para matching con la AI

### Folder
- Solo `id` y `name`. Los proyectos referencian un `folderID` opcional. Sin jerarquia.

---

## 4. Stores (persistencia local)

Todos son `@MainActor ObservableObject`. Notifican cambios via Combine.

| Store | Archivo | Que hace |
|-------|---------|----------|
| **ProjectStore** | `projects.json` + `folders.json` | CRUD de proyectos y carpetas. Linkeo de repos (crea bookmarks). Guarda ultimo proyecto seleccionado en UserDefaults |
| **EntryStore** | `projects/{id}/entries.json` | CRUD de entries. Carga por proyecto. Tiene `addEntry(toProject:)` para el panel flotante sin cambiar el proyecto activo |
| **CustomCategoryStore** | `custom_categories.json` | CRUD de categorias custom. Validacion de nombre + descripcion |

---

## 5. Servicios

| Servicio | Que hace | Secrets que necesita |
|----------|----------|---------------------|
| **OpenAIService** | Clasificacion AI en 2 pasos (categoria → tipo) | API key via APIKeyProvider |
| **APIKeyProvider** | Rutea auth: proxy o key directa del usuario | `WIPS_PROXY_TOKEN` (xcconfig → Info.plist), Keychain para key del usuario |
| **WipsieService** | Genera briefings contextuales por proyecto (JSON estructurado → `WipsieSummary`) | Mismo auth que OpenAI |
| **ChatService** | Asistente in-app con proteccion anti-injection | Mismo auth que OpenAI |
| **SessionCaptureService** | Procesa logs de Claude Code, genera resumenes | Mismo auth que OpenAI |
| **ClaudeCodeSessionProvider** | Descubre y lee archivos JSONL de sesiones | Ninguno (lee filesystem local) |
| **AttachmentService** | Guarda/carga/borra imagenes PNG | Ninguno |
| **MarkdownBridgeService** | Sync bidireccional con .wips/ISSUES.md | Security-scoped bookmarks |
| **RepoDetectorService** | Escanea home buscando repos de agentes AI | Ninguno |
| **MigrationService** | Migra estructura legacy (una vez) | Ninguno |
| **KeychainHelper** | Utilidad para leer/escribir/borrar en Keychain | Ninguno |

---

## 6. Pipeline de clasificacion AI

```
Usuario escribe texto
  → InputViewModel.submitEntry()
    → OpenAIService.classify(text, customCategories)
      → Paso 1: "Clasifica este texto en: [categorias]"
         ← Respuesta: "tarea" / "idea" / "mi_custom_slug" / etc.
         → Si es custom: category = .tarea, customCategoryId = UUID
         → Si es .tarea:
            → Paso 2: "Es Feature o Bug?"
               ← Respuesta: "feature" / "bug"
      → Return: ClassificationResult(category, type?, customCategoryId?)
    → Crea Entry con resultado
    → Guarda en EntryStore
```

- Modelo: gpt-4o-mini, temperature 0, max_tokens 20
- Fallback: si falla 2 veces → default a `.pensamiento`
- Custom categories se detectan por `nameSlug` matching

---

## 7. Sistema de auth (APIKeyProvider)

```
                    ┌─ Keychain tiene key? ─┐
                    │                        │
                   SI                       NO
                    │                        │
              Modo DIRECTO             Modo PROXY
                    │                        │
        api.openai.com/v1        majestic-proxy.vercel.app
        Header: Bearer sk-...    Header: Bearer <jwt>
```

**Modo proxy** (default): el usuario se autentica con Apple Sign In → el proxy devuelve un JWT (1h) + refresh token (30 dias) → la app usa el JWT en `Authorization: Bearer`. Si el JWT expira, `APIKeyProvider.executeRequest()` detecta el 401, refresca el token, y reintenta automaticamente.

**Modo directo**: el usuario guarda su API key de OpenAI en Settings → se persiste en Keychain → se usa como Bearer token directo contra OpenAI.

---

## 8. Markdown Bridge (sync con repos)

**Direccion App → Markdown (export)**:
- Se dispara automatico cuando cambian entries (500ms debounce via Combine)
- Genera `.wips/ISSUES.md` con entries agrupados por categoria
- Tareas tienen checkboxes `- [ ]`/`- [x]`, agrupadas por tipo
- Cada linea tiene `<!-- entry:uuid -->` para identificacion

**Direccion Markdown → App (import)**:
- File watcher (DispatchSource) detecta cambios externos
- 3 segundos de debounce
- Solo actualiza `text` e `isCompleted` de entries existentes
- NO crea entries nuevos (limitacion V1)
- `suppressNextExport` evita loops: import → update → export → import

**Seguridad sandbox**:
- Bookmarks se crean cuando el usuario linkea un repo (NSOpenPanel)
- Se resuelven en cada launch
- `ensureAccess(for:)` valida acceso antes de cada operacion de archivo

---

## 9. Integracion con agentes AI

Wips se conecta con agentes de codigo (Claude Code, Codex, etc.) por tres vias:

### 9a. Markdown Bridge (bidireccional)
El agente lee y edita `.wips/ISSUES.md`. Puede ver entries, marcar tareas como completadas, y editar texto. Los cambios se sincronizan a la app en ~3 segundos. Ver seccion 8.

### 9b. CLAUDE.md (descubrimiento automatico)
Cuando el usuario linkea un repo que tiene `CLAUDE.md`, la `RepoLinkedSheet` le pregunta si quiere agregar una seccion de Wips. Si acepta, `MarkdownBridgeService.appendWipsToClaudeMD()` appenda:

```markdown
## Wips Integration
This project is linked to Wips. Read `.wips/ISSUES.md` for current tasks...
```

Esto hace que agentes como Claude Code descubran las entries automaticamente sin que el usuario tenga que decirles donde buscar. La deteccion (`shouldOfferClaudeMDIntegration`) verifica que CLAUDE.md exista y que no tenga ya la seccion.

### 9c. Session Capture (captura pasiva)

```
App launch
  → SessionCaptureService.processNewSessions()
    → Para cada proyecto con repoPath + sessionCaptureEnabled:
      → ClaudeCodeSessionProvider.discoverSessions(repoPath)
        → Busca ~/.claude/projects/*/sessions/*.jsonl
        → Filtra por sessions que matcheen el repoPath
        → Retorna DiscoveredSession (id, path, fileSize, lastModified)
      → Filtra sessions ya procesadas (por fileSize + lastModified)
      → Para cada session nueva:
        → extractMessages(): lee JSONL, filtra mensajes relevantes, sanitiza secrets
        → generateSummary(): GPT resume la session en 3-5 lineas
        → saveSummary(): guarda en projects/{id}/sessions_log.json bajo la fecha
```

**Como llega a Wipsie:**
```
FeedViewModel.loadWipsieSummary()
  → sessionCaptureService.sessionLogs(for: projectID, lastDays: 3)
  → Pasa los summaries al prompt de WipsieService
  → GPT los integra en la narrativa del briefing
```

**Sanitizacion de secrets**: `ClaudeCodeSessionProvider` filtra patrones como `sk-`, `ghp_`, `AKIA`, passwords y tokens antes de enviar contenido a GPT.

---

## 10. Features

### Home (FeedView + SidebarView)
- **SidebarViewModel**: seleccion de proyecto/carpeta, CRUD, guarda `previousOpenedAt` para Wipsie
- **FeedViewModel**: el VM mas grande. Filtra, agrupa, busca, maneja drag&drop, calcula datos para Today view, carga Wipsie. Todo pre-computado para que las views sean thin
- **RootView**: `NavigationSplitView` con sidebar | feed | chat panel opcional

### Input (Panel flotante Cmd+I)
- **InputPanelController**: NSPanel custom que acepta teclas, cross-Space con `.accessory` activation policy
- **InputViewModel**: texto + imagenes pendientes + selector de proyecto + submit
- **ShortcutManager**: event tap global para Cmd+I

### Today (Briefing)
- **TodayView**: muestra briefing de Wipsie + pinned + actionable + recent
- Se alimenta de FeedViewModel (`todayActionableEntries`, `todayRecentEntries`, `wipsieSummary`)
- **Wipsie** pide JSON estructurado a GPT → `WipsieSummary` (context + highlights[])
  - `context`: sintesis narrativa (2-3 oraciones), no lista entries
  - `highlights`: solo info que NO esta en el feed (sesiones de agentes, sugerencias, patrones). Puede ser array vacio
  - UI: card con borde accent (0.25 opacity), context en `.callout` regular, items en `.callout` + textSecondary

### Settings
- UI para guardar/borrar API key de OpenAI
- Muestra modo actual (proxy vs directo)

---

## 11. Seguridad

| Que | Como | Donde |
|-----|------|-------|
| Auth tokens (refresh, userID, email) | JSON file in sandboxed Application Support (`auth_tokens.json`) | TokenStorage.swift |
| Proxy token | Build-time via xcconfig → Info.plist (gitignored) | Secrets.xcconfig, APIKeyProvider.swift |
| Acceso a repos | Security-scoped bookmarks + entitlement `com.apple.security.files.bookmarks.app-scope` | ProjectStore, MarkdownBridgeService |
| Anti prompt injection | 27+ patrones detectados, sanitizacion de tokens peligrosos | ChatService.swift |
| Sanitizacion de secrets en sesiones | Filtra sk-, ghp_, AKIA, passwords, tokens antes de enviar a OpenAI | ClaudeCodeSessionProvider.swift |

---

## 12. Theme

- `AppTheme` struct con ~25 colores semanticos (textPrimary, cardBackground, etc.)
- Dos presets: `.dark` y `.light`
- Se inyecta via `@Environment(\.appTheme)` usando `ThemedView` modifier
- Colores de categorias en `Color+Theme.swift`

---

## 13. Patrones clave

- **MVVM + @MainActor**: todo en main thread, seguro para UI
- **Combine reactivo**: stores publican → VMs recalculan → views se actualizan
- **Debounce en todos lados**: search (150ms), store changes (500ms), seen IDs (2s)
- **Protocol-based AI**: `ClassificationService` permite swappear implementaciones
- **SessionProvider protocol**: extensible para otros agentes (Cursor, etc.)
- **Thin Views**: la logica vive en ViewModels, las views solo renderizan
- **Fallback graceful**: si la AI falla → default a `.pensamiento`, si el proxy falla → se puede usar key directa

---

## Decision Log

### 2026-03-10 — Proxy token: de env vars a xcconfig + Info.plist (OBSOLETO)
**Nota:** Este paso fue reemplazado por Apple Sign In + JWT (2026-03-15). El token estatico ya no existe.

### 2026-03-15 — Apple Sign In + JWT reemplaza token estatico
**Categoria:** [seguridad] [auth]
**Que se hizo:** Se reemplazo el token estatico compartido (`WIPS_PROXY_TOKEN` / `X-Issue-Token`) por Apple Sign In + JWT por sesion. Cada usuario recibe su propio JWT temporal (1h) con refresh token (30 dias). El proxy valida JWTs y rate-limitea por usuario.
**Por que:** El token estatico embebido en el binario era extraible por cualquier dev, permitiendo uso no autorizado del proxy (y de la API key de OpenAI).
**Archivos clave:** `Core/Services/Auth/AuthService.swift`, `Core/Services/Auth/WebAuthCoordinator.swift`, `Core/Services/APIKeyProvider.swift`, `Features/Auth/AuthView.swift`
**Impacto:** La app ya no contiene ningun secret. Toda autenticacion es por sesion individual.

### 2026-03-24 — Token storage: de Keychain a archivo JSON en Application Support
**Categoria:** [seguridad] [auth]
**Que se hizo:** Se reemplazo `KeychainHelper` (Keychain API) con `TokenStorage` (archivo JSON en el container sandboxed). Se elimino el entitlement `keychain-access-groups` del entitlements file.
**Por que:** Keychain era incompatible con sandboxed + Developer ID: `kSecUseDataProtectionKeychain` requiere `keychain-access-groups` (que rompe code signing para Developer ID), y sin el flag el file-based keychain pide password en cada nuevo build. Cada fix generaba un nuevo problema (app no abre → sesion se pierde → prompt de keychain → loop). Archivo en Application Support es el patron usado por Raycast, CleanShot X y otras apps sandboxed Developer ID.
**Archivos clave:** `Core/Services/Auth/TokenStorage.swift` (nuevo), `Core/Services/Auth/AuthService.swift`, `issue.entitlements`
**Impacto:** Cero prompts, funciona igual en debug y release, tokens persisten entre versiones. `KeychainHelper.swift` eliminado.
