# Unknown Unknowns — Aprendizajes

Documento vivo con blind spots detectados durante el desarrollo de Wips. Cada sección es un aprendizaje concreto.

---

## 2026-03-09 — Análisis de Producto (Pivot a Briefing)

### Capture-Retrieval Gap
- Capturar es fácil y satisfactorio. Recuperar es costoso y nadie lo hace.
- Notion tiene el mismo problema: millones de páginas que nadie relee.
- La solución no es mejor UI para navegar, es que el sistema digiera por vos.

### El chat vacío es peor que el feed
- Si reemplazás el feed por un chat, el usuario ve un cursor parpadeando y no sabe qué preguntar.
- Solución: el sistema habla primero. "Esto es lo importante hoy" sin que preguntes.

### Validar antes de construir
- "Me agobia el feed" puede tener soluciones más baratas que reescribir la UI: auto-archivo, caps más agresivos, resúmenes periódicos.
- Siempre probar la solución más barata primero.

### Memoria sin acción es archivo muerto
- "Wips es tu memoria" suena bien pero la gente no paga por memoria — paga por resultados.
- Evernote era "tu segunda memoria" y nadie lo abre.
- El valor tiene que estar en lo que Wips HACE con lo que recuerda, no en recordar.

### Switching cost
- Sin lock-in ni cloud, cada usuario es prestado.
- La memoria acumulada ES el switching cost si se hace valiosa.
- "Wips tiene 6 meses de contexto de tu trabajo" es difícil de replicar.

### Competencia inminente
- Claude ya tiene memory, ChatGPT tiene memory, Cursor va a tener persistencia entre sesiones.
- Los LLM providers están resolviendo "el agente que recuerda".
- La ventaja de Wips tiene que ser algo que ellos NO van a construir.

### Costo por usuario
- Cada query al LLM tiene costo. 10-20 queries/día = $3-18/mes por usuario solo en API.
- Modelar costos ANTES de construir features que dependen de LLM.

---

## 2026-03-09 — Análisis Técnico (Captura Pasiva)

### Sandbox bloquea acceso a archivos externos
- macOS App Sandbox impide leer archivos fuera del container de la app.
- `~/.claude/projects/` está fuera del sandbox.
- Solución: security-scoped bookmarks. El usuario selecciona la carpeta una vez, se guarda el bookmark, y se resuelve en cada launch.
- Patrón ya implementado en MarkdownBridge para repos.

### Enviar datos del usuario a terceros
- Las sesiones de Claude Code pueden contener secrets, API keys, passwords.
- Enviar eso a OpenAI para summarizar es un riesgo de privacidad.
- Solución: sanitizar input (stripear patrones de secrets), documentar qué se envía.
- Futuro: summarización local (MLX/llama.cpp) para privacidad total.

### Dependencia de formatos internos
- Leer JSONL de `~/.claude/projects/` depende de un formato interno que Anthropic puede cambiar en cualquier update.
- No es una API pública, es un detalle de implementación.
- Solución: validación defensiva, fallar silenciosamente, loguear cambios de formato.

### "Sesión terminada" es difícil de definir
- 30 min de inactividad no significa que la sesión terminó — el dev puede estar almorzando.
- Procesar una sesión incompleta y no re-procesarla después pierde información.
- Solución: dedup por file size/lastModified en vez de timeout. Si el archivo creció, re-procesar.

### Costos escalan con usuarios
- Cada sesión procesada = 1 call a OpenAI.
- 5 sesiones/día × 100 usuarios = 500 calls/día.
- Proxy token hardcodeado en la app es extraíble — cualquiera puede usar tu proxy gratis.
- Solución: limitar sesiones por scan, migrar proxy auth a algo más seguro.

### JSON files crecen indefinidamente
- sessions_log.json, entries.json, wipsie_cache.json — ninguno tiene rotación.
- En 6 meses con uso diario pueden ser grandes.
- Solución: cap de 90 días para session logs, auto-archivo para entries viejas.

---

## Principios Generales Aprendidos

1. **Probar la solución más barata primero** antes de construir features complejas.
2. **Modelar costos de API** antes de escribir código que dependa de LLM.
3. **Nunca asumir acceso a archivos** en macOS — siempre considerar sandbox.
4. **Sanitizar datos** antes de enviarlos a servicios externos.
5. **No depender de formatos internos** de otras herramientas sin validación defensiva.
6. **Definir "sesión terminada"** es más difícil de lo que parece.
7. **El usuario es dueño de sus datos** — siempre. Transparencia sobre qué se procesa y dónde va.
