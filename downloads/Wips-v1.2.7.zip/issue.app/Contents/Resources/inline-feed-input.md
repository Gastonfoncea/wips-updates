# Spec: Input Inline en FeedView

## Problema

Hoy, para crear una entrada, el usuario tiene que abrir un panel flotante (Cmd+I o click en "Nueva entrada"). Esto interrumpe el flujo de trabajo: estás mirando el feed de un proyecto, tenés una idea, y tenés que hacer una acción extra para capturarla. En herramientas como Slack o Linear, el campo de texto siempre está visible al fondo — escribís, enter, listo.

## Solución

Textbox inline permanente al fondo del FeedView, estilo chat input. El floating panel (Cmd+I) se mantiene para captura global con selector de proyecto.

## Criterios de Aceptación

### CA-1: Input visible permanentemente al fondo del FeedView
- Campo de texto con placeholder "Qué estás pensando?", botón adjuntar (paperclip) y botón enviar (arrow.up.circle.fill)
- Fijo al fondo del VStack principal, no se scrollea con el contenido
- Separado del feed por un SectionSeparator

### CA-2: El botón "Nueva entrada" ya no existe
- Se elimina el botón "Nueva entrada" del fondo del FeedView
- Se actualiza el empty state

### CA-3: Submit con Enter
- Enter envía la entrada al proyecto actualmente seleccionado en el sidebar
- Se limpia el campo, aparece toast "Clasificando..." → "Clasificada"
- La entrada aparece en el feed tras clasificación

### CA-4: Shift+Enter para nueva línea
- Shift+Enter inserta salto de línea, campo crece hasta 3 líneas, NO envía

### CA-5: Proyecto destino automático
- Proyecto activo del sidebar. Si es "Todos" (.all), fallback a "General" (.general)

### CA-6: Botón de envío deshabilitado sin texto
- Sin texto válido → botón en textMuted, no hace nada

### CA-7: Adjuntar imágenes via botón y drag & drop
- Botón paperclip abre file importer (múltiples imágenes)
- Drag & drop sobre el input con feedback visual (borde accent)
- Thumbnails debajo del campo con botón X para remover

### CA-8: Floating panel (Cmd+I) sigue funcionando independientemente
- Estado separado, sin conflicto con el inline input

## Archivos a crear

1. **`InlineFeedInput.swift`** en `issue/Features/Home/Views/Components/`
   - Vista con estado local (@State): inputText, pendingImages, isDragOver, showingFileImporter
   - Recibe `feedVM: FeedViewModel`
   - Layout: TextField + paperclip + send, thumbnails debajo si hay imágenes

## Archivos a modificar

1. **`FeedViewModel.swift`**: Agregar `submitInlineEntry(text:images:)` replicando pipeline de InputViewModel.submitEntry()
2. **`FeedView.swift`**: Eliminar botón "Nueva entrada", agregar InlineFeedInput al fondo, ajustar padding del toast
3. **`InputPanelView.swift`**: Extraer PendingImageCard de private a shared (o duplicar)

## Layout

```
+------------------------------------------------------------------+
|  +------------------------------------------------------------+  |
|  | Qué estás pensando?                        [clip]    [->]  |  |
|  +------------------------------------------------------------+  |
|  [img1] [img2]               (solo si hay imágenes pendientes)   |
+------------------------------------------------------------------+
```

- Fondo: theme.inputBackground, RoundedRectangle(cornerRadius: 10)
- Borde: theme.borderDefault 1px, accent en drag
- TextField: .body, .plain, lineLimit(1...3)
- Send: Color.accentColor si válido, textMuted si no, arrow.up.circle.fill 20pt

## Fuera de Alcance

- Selector de proyecto en inline (usar floating panel para eso)
- Paste de imágenes desde clipboard (Cmd+V)
- Preview de clasificación antes de enviar
- Animación de entrada apareciendo en feed
