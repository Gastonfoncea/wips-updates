# Arquitectura, Seguridad y Conexion con OpenAI

Documento de estudio sobre las decisiones de arquitectura, seguridad y conexion con APIs externas en la app Issue.

---

## 1. Arquitectura: MVVM

### Que es MVVM

MVVM significa **Model - View - ViewModel**. Es un patron de arquitectura que separa la app en tres capas:

```
┌─────────┐      ┌──────────────┐      ┌──────────┐
│  Model   │ ←──→ │  ViewModel   │ ←──→ │   View   │
│ (datos)  │      │  (logica)    │      │   (UI)   │
└─────────┘      └──────────────┘      └──────────┘
```

- **Model**: Los datos puros. En nuestro caso: `Entry`, `Project`, `CustomCategory`. No saben nada de UI.
- **ViewModel**: La logica de negocio. Transforma los datos del Model en algo que la View pueda mostrar. Ejemplo: `FeedViewModel` recibe entries crudas y las agrupa por categoria.
- **View**: Solo muestra lo que el ViewModel le da. No hace calculos, no filtra, no ordena.

### Por que usamos MVVM

La alternativa mas simple es poner toda la logica en la View. Funciona para apps chicas, pero cuando crece:

- Las Views se vuelven enormes y dificiles de leer
- No podes testear la logica sin levantar la UI
- Si cambias la UI, rompes la logica

Con MVVM, la logica vive en el ViewModel. Podes testear `FeedViewModel` sin necesitar una pantalla. Si cambias la UI, el ViewModel no se entera.

### Stores vs Services vs ViewModels

Tenemos tres tipos de objetos con roles distintos:

| Tipo | Responsabilidad | Ejemplo |
|------|----------------|---------|
| **Store** | Persistencia local (leer/escribir JSON) | `EntryStore`, `ProjectStore` |
| **Service** | Comunicacion con APIs externas o utilidades | `OpenAIService`, `ChatService` |
| **ViewModel** | Logica de presentacion para una pantalla | `FeedViewModel`, `SidebarViewModel` |

La regla es: un **Store** nunca llama a una API externa. Un **Service** nunca guarda datos locales. Un **ViewModel** nunca hace ninguna de las dos — solo consume lo que le dan.

### Dependency Injection (DI)

En vez de que cada objeto cree sus propias dependencias, se las pasamos desde afuera. Esto se llama **inyeccion de dependencias**.

```
// MAL — el ViewModel crea su propia dependencia
class FeedViewModel {
    let store = EntryStore()  // acoplado, no testeable
}

// BIEN — la dependencia se inyecta
class FeedViewModel {
    let store: EntryStore
    init(store: EntryStore) {
        self.store = store  // viene de afuera
    }
}
```

**Por que importa**: en los tests, podes pasar un Store falso (mock) que no toca el disco. En produccion, pasas el real. El ViewModel no sabe la diferencia.

En nuestra app, `AppState` es el **contenedor de DI** — crea todas las dependencias y se las pasa a quien las necesite:

```
AppState (crea todo)
  ├── ProjectStore
  ├── EntryStore
  ├── APIKeyProvider ──→ OpenAIService
  │                  └─→ ChatService
  ├── AttachmentService
  └── MarkdownBridgeService
```

---

## 2. Conexion con OpenAI

### Que es una API

Una API (Application Programming Interface) es un "contrato" entre dos programas. Vos mandas un request con cierto formato, y te devuelven un response con cierto formato.

OpenAI expone una API HTTP. Le mandas un mensaje JSON con tus mensajes, y te devuelve la respuesta del modelo.

### Request a OpenAI (simplificado)

```
POST https://api.openai.com/v1/chat/completions

Headers:
  Content-Type: application/json
  Authorization: Bearer sk-tu-api-key

Body:
{
  "model": "gpt-4o-mini",
  "messages": [
    {"role": "system", "content": "Sos un clasificador..."},
    {"role": "user", "content": "Implementar dark mode"}
  ],
  "max_tokens": 20,
  "temperature": 0
}
```

### Response de OpenAI

```json
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "tarea"
      }
    }
  ]
}
```

### Conceptos clave

- **model**: Que modelo de IA usar. `gpt-4o-mini` es rapido y barato.
- **messages**: La conversacion. Cada mensaje tiene un `role` (system, user, assistant) y `content`.
- **system prompt**: El primer mensaje con `role: "system"`. Le dice al modelo como comportarse. El usuario no lo ve.
- **max_tokens**: Limite de longitud de la respuesta. 1 token ≈ 3/4 de una palabra.
- **temperature**: Que tan "creativo" es el modelo. 0 = deterministico, 1 = mas variado.
- **API key**: Una clave secreta que identifica tu cuenta. OpenAI te cobra segun el uso.

### Nuestra app usa OpenAI para dos cosas

1. **Clasificacion**: Manda el texto de una entrada → OpenAI responde con la categoria (idea, tarea, pensamiento, etc.)
2. **Chat de ayuda**: Un asistente que responde preguntas sobre como usar la app.

---

## 3. El Proxy: por que existe y como funciona

### El problema

Para llamar a OpenAI necesitas una API key. Si metes la key en la app:

- Cualquiera puede extraerla del binario (con herramientas basicas)
- Un usuario malicioso la usa para sus propios fines
- Te llega una factura de miles de dolares

Si le pedis al usuario que ponga su propia key:

- Friccion enorme — tiene que crear cuenta en OpenAI, cargar credito, generar key
- El 90% de los usuarios abandona

### La solucion: un proxy

Un proxy es un servidor intermedio que actua de "puente" entre tu app y OpenAI:

```
App del usuario  ──→  Tu proxy (Vercel)  ──→  OpenAI
                      (tiene tu API key)
```

- El usuario no necesita key — el proxy la tiene
- Tu key nunca sale del servidor — el usuario no la ve
- Vos controlas que se puede hacer — limitas modelo, tokens, rate limit

### Que es Vercel

Vercel es una plataforma de hosting que ejecuta funciones serverless. "Serverless" significa que no tenes un servidor corriendo 24/7 — Vercel ejecuta tu funcion solo cuando llega un request, y te cobra por ejecucion.

Nuestro proxy es **un solo archivo TypeScript** (`api/openai.ts`) que Vercel ejecuta como funcion. No es una app, no tiene framework, no tiene base de datos.

### Que es una Edge Function

Una Edge Function corre en servidores distribuidos por el mundo (edge = "borde" de la red). Cuando un usuario en Argentina hace un request, se ejecuta en un servidor cercano, no en uno en Virginia. Esto reduce la latencia.

### Que hace nuestro proxy

1. **Verifica autenticacion** — Requiere un token secreto en el header `X-Issue-Token`
2. **Valida el request** — Cada mensaje debe tener `role` y `content` como strings
3. **Fuerza limites** — Modelo fijo (`gpt-4o-mini`), max 800 tokens, temperature 0-1
4. **Rate limiting** — 30 req/min por IP + 5000 req/dia global
5. **Agrega la API key** — La lee de las variables de entorno de Vercel
6. **Reenvia a OpenAI** — Y devuelve la respuesta tal cual

### Costos

| Componente | Costo |
|-----------|-------|
| Vercel (free tier) | $0 — 100k invocaciones/mes |
| OpenAI gpt-4o-mini | ~$0.15/millon tokens input, ~$0.60/millon tokens output |
| Una clasificacion (~200 tokens) | ~$0.00003 |
| Un mensaje de chat (~1000 tokens) | ~$0.0002 |
| Usuario activo por mes | Centavos |

---

## 4. Seguridad

### 4.1 El token compartido (shared secret)

**Problema**: Si alguien descubre la URL del proxy, puede mandar requests y gastar tus creditos.

**Solucion**: Un token secreto que la app envia en cada request:

```
Header: X-Issue-Token: PXY_iss_7k2Qm9Xv4nR1wL8pTjYd3sB6hF0eAcZo
```

El proxy verifica que el token coincida con el que tiene guardado como variable de entorno en Vercel. Si no coincide → 401 Unauthorized.

**Limitacion conocida**: El token esta en el binario de la app. Alguien con conocimientos de reverse engineering puede extraerlo. Pero sube la barrera de "cero esfuerzo" a "necesita herramientas y conocimiento especifico". Para una app indie, es suficiente.

### 4.2 Validacion de mensajes

**Problema**: Sin validacion, alguien podria mandar un mensaje con `role: "system"` para sobreescribir tu system prompt y usar el proxy para cualquier cosa.

**Solucion**: El proxy valida cada mensaje:

- `role` debe ser `"system"`, `"user"` o `"assistant"` (strings)
- `content` debe ser string
- Contenido de user/assistant: max 2000 caracteres
- Contenido de system: max 5000 caracteres
- Maximo 15 mensajes por request

### 4.3 Rate limiting

**Problema**: Incluso con autenticacion, un usuario o bot podria hacer miles de requests y generar costos altos.

**Solucion**: Dos capas de limite:

1. **Per-IP**: 30 requests por minuto — protege contra un solo usuario abusivo
2. **Global**: 5000 requests por dia — pone un techo al costo maximo diario (worst case ~$1-2 USD)

**Limitacion conocida**: Los limites estan en memoria del Edge Function. Se resetean en cada "cold start" (cuando Vercel recicla la instancia). Para V1 es aceptable — el techo global limita el dano. Post-lanzamiento se puede migrar a Upstash Redis (servicio de base de datos en memoria) para limites persistentes.

### 4.4 Forzar modelo y tokens

El proxy ignora el modelo que mande el cliente y siempre usa `gpt-4o-mini`. Tambien capea `max_tokens` a 800. Esto evita que alguien intente usar `gpt-4` (10x mas caro) o pida respuestas enormes.

### 4.5 Token Storage

**Problema**: Los auth tokens (refresh token, user ID, email) deben persistir entre sesiones de forma segura.

**Solucion anterior (Keychain)**: Intentamos usar el Keychain de macOS, pero resulto incompatible con nuestra combinacion de sandbox + Developer ID:
- `kSecUseDataProtectionKeychain = true` necesita el entitlement `keychain-access-groups` → rompe code signing para Developer ID (la app no abre)
- Sin ese flag, el file-based keychain pide password al usuario en cada nuevo build
- Cada fix generaba un nuevo problema → loop infinito

**Solucion actual (archivo JSON en sandbox)**: Guardamos los tokens en `auth_tokens.json` dentro del directorio sandboxed de Application Support (`~/Library/Containers/com.gastonfoncea.wips/Data/Library/Application Support/Wips/`). Es el mismo directorio donde ya se guardan `projects.json` y `entries.json`.

| Proteccion | Como funciona |
|------------|---------------|
| **App Sandbox** | Ninguna otra app puede leer el container de Wips |
| **FileVault** | Si esta activo (mayoria de Macs), el disco esta cifrado at rest |
| **Consistencia** | Funciona igual en debug y release, no depende de code signing ni entitlements |

Este patron es el mismo que usan Raycast y CleanShot X (apps sandboxed distribuidas con Developer ID).

**Implementacion**: `TokenStorage.swift` (`Core/Services/Auth/`). API simple: `save(account:data:)`, `read(account:)`, `delete(account:)`. AuthService valida que los saves fueron exitosos — si fallan, lanza error en vez de continuar silenciosamente.

### 4.6 Logs seguros

Los logs del sistema (visibles en Console.app) pueden contener informacion sensible. Usamos el modificador `.private` de OSLog para que los response bodies de OpenAI se redacten:

```swift
// Se ve en Console como: "OpenAI HTTP 401: <private>"
logger.error("OpenAI HTTP \(code, privacy: .public): \(body, privacy: .private)")
```

Solo se ven los valores reales si el usuario habilita explicitamente logging privado.

### 4.7 Sanitizacion de input (chat)

El chat tiene proteccion contra **prompt injection** — cuando un usuario intenta manipular el system prompt a traves de su mensaje:

- **Patron matching**: Detecta frases como "ignore previous instructions", "act as", "jailbreak"
- **Sanitizacion**: Elimina delimitadores peligrosos (`"""`, ` ``` `, `<|`, etc.)
- **System prompt defensivo**: El prompt del chat incluye instrucciones explicitas de no cambiar de rol

**Importante**: Esta proteccion es **client-side** (en la app). Si alguien llama al proxy directamente, la bypasea. Por eso el token de autenticacion (4.1) es la primera linea de defensa.

### 4.8 HTTPS obligatorio

Todas las URLs usan HTTPS (conexion encriptada). La app valida que el override de `ISSUE_PROXY_URL` sea HTTPS — si alguien la setea con `http://`, la app la ignora y usa la URL por defecto.

---

## 5. Flujo completo: que pasa cuando el usuario escribe una entrada

```
1. Usuario escribe "Implementar dark mode" en el input
2. InputViewModel envia el texto a FeedViewModel
3. FeedViewModel crea la Entry con categoria .pensamiento (temporal)
4. FeedViewModel llama a OpenAIService.classify("Implementar dark mode")
5. OpenAIService pregunta a APIKeyProvider: ¿que modo estamos?
   - Si hay key en Keychain → modo directo → URL: api.openai.com
   - Si no hay key → modo proxy → URL: majestic-proxy.vercel.app
6. OpenAIService arma el request con el system prompt de clasificacion
7. Si es modo proxy, agrega el header X-Issue-Token
8. Manda el request HTTP
9. El proxy (o OpenAI directo) responde: "tarea"
10. OpenAIService parsea "tarea" → como es tarea, hace un 2do request
    para clasificar el subtipo
11. OpenAI responde: "feature"
12. OpenAIService devuelve ClassificationResult(category: .tarea, type: .feature)
13. FeedViewModel actualiza la Entry con la categoria real
14. EntryStore guarda la Entry en el JSON
15. La UI se actualiza automaticamente (SwiftUI reactivo)
```

---

## 6. Deuda tecnica y mejoras futuras

### Prioridad alta (post-lanzamiento)

| Item | Descripcion | Por que |
|------|-------------|---------|
| **Rate limit persistente** | Migrar de `Map` en memoria a Upstash Redis | Los limites actuales se resetean en cold starts de Vercel. Con Redis, persisten. Free tier de Upstash alcanza. |
| **Monitoreo de costos** | Dashboard en Vercel Analytics o OpenAI usage page | Hoy no tenes visibilidad de cuanto se esta gastando en tiempo real. |
| **Circuit breaker** | Si el proxy falla N veces seguidas, dejar de intentar por X minutos | Hoy `isAvailable` siempre es `true`. Si el proxy esta caido, la app intenta en cada clasificacion y falla. |

### Prioridad media

| Item | Descripcion |
|------|-------------|
| **Rotar el token** | Cambiar `proxyAppToken` en cada version de la app. Si alguien lo extrae de una version, deja de funcionar en la siguiente. |
| **System prompt en el proxy** | Mover el system prompt del chat al proxy server-side. Hoy se envia desde la app — si alguien llama al proxy directo, puede usar su propio system prompt. |
| **Streaming** | OpenAI soporta respuestas en streaming (van llegando palabra por palabra). Mejora la UX del chat. Requiere cambiar el proxy para que haga forwarding de Server-Sent Events. |

### Prioridad baja

| Item | Descripcion |
|------|-------------|
| **Certificate pinning** | Verificar que el certificado TLS sea exactamente el de OpenAI/Vercel. Protege contra man-in-the-middle en redes corporativas. |
| **Multiples providers** | Soporte para Anthropic, Gemini u otros LLMs ademas de OpenAI. El protocol `ClassificationService` ya esta preparado para esto. |
| **Cache de clasificaciones** | Si el mismo texto ya fue clasificado, devolver el resultado cacheado sin llamar a OpenAI. Ahorra costos y latencia. |

---

## 7. Glosario

| Termino | Definicion |
|---------|-----------|
| **API** | Interfaz que permite a dos programas comunicarse. Nuestra app habla con OpenAI via su API HTTP. |
| **API Key** | Clave secreta que identifica tu cuenta ante un servicio. OpenAI la usa para saber quien paga. |
| **Token (LLM)** | Unidad de texto para modelos de lenguaje. 1 token ≈ 3/4 de una palabra en ingles. |
| **Token (auth)** | Cadena secreta usada para autenticar requests. Diferente al token de LLM. |
| **Proxy** | Servidor intermedio que reenvia requests. Permite ocultar secretos del cliente. |
| **Serverless** | Modelo donde no tenes un servidor corriendo 24/7. La plataforma ejecuta tu codigo on-demand. |
| **Edge Function** | Funcion serverless que corre en servidores distribuidos geograficamente. |
| **Cold start** | Cuando una funcion serverless se inicia desde cero (no estaba en memoria). Tarda mas que una ejecucion "caliente". |
| **Rate limiting** | Limitar la cantidad de requests que un cliente puede hacer en un periodo de tiempo. |
| **Keychain** | Sistema de almacenamiento seguro de macOS. Encripta datos con la clave del usuario. |
| **System prompt** | Instrucciones ocultas que le das al modelo antes del mensaje del usuario. Define el comportamiento. |
| **Prompt injection** | Ataque donde el usuario intenta manipular el system prompt a traves de su input. |
| **HTTPS** | HTTP con encriptacion TLS. Los datos viajan encriptados entre cliente y servidor. |
| **DI (Dependency Injection)** | Patron donde las dependencias se pasan desde afuera en vez de crearse internamente. |
| **Circuit breaker** | Patron que deja de intentar una operacion que falla repetidamente, para no desperdiciar recursos. |
| **Upstash Redis** | Base de datos en memoria (key-value) que funciona como servicio serverless. Util para rate limiting persistente. |
