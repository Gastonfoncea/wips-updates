# Spec: Resolver — Lifecycle unificado para todas las entries

## Problema

Los usuarios de Wips acumulan entries (ideas, pensamientos, conocimientos, inspiraciones, etc.) que nunca "se van" del feed. Solo las tareas tienen un concepto de "completado", pero el resto de categorias no tiene forma de cerrarse. Con 115+ entries en pocos meses, el feed se llena de ruido — entries viejas que ya no son relevantes pero siguen apareciendo. No hay forma de decir "esto ya lo procese, que desaparezca" sin recurrir a borrar (que pierde historial) o archivar (que tiene connotacion de "guardar para despues").

## Contexto Tecnico

### Modelo actual
- `Entry` ya tiene `isCompleted: Bool`, `isPinned: Bool`, `isArchived: Bool` (en `/issue/Core/Models/Entry.swift`)
- `isCompleted` hoy solo se usa visualmente para tareas (`isTask: true` en `EntryRow`). El campo existe en todas las entries pero solo las tareas muestran checkbox y strikethrough.
- `isArchived` existe pero se usa como "ocultar" — `recalculateFilteredEntries()` filtra `!$0.isArchived` por defecto.

### Filtrado actual (`FeedViewModel`)
- `recalculateFilteredEntries()` filtra archivados por defecto, tiene `showPendingOnly` filter, y `showArchived` toggle.
- `entrySort()` ya ordena completados al final: `if a.isCompleted != b.isCompleted { return !a.isCompleted }`
- `TodayViewModel` filtra: `!$0.isArchived && !$0.isCompleted` para actionables, `!$0.isArchived` para recently captured.

### Vista de entries (`EntryRow`)
- El `isTask` flag determina si muestra checkbox (true) o bullet (false).
- El menu contextual solo muestra "Marcar completada/pendiente" si `isTask == true`.
- El strikethrough y estilo muted solo se aplica si `isTask && visuallyDone`.

### Acciones (`EntryAction` enum)
- Ya existe `.toggle(Entry)` que llama a `FeedViewModel.toggleEntry()` — toggle de `isCompleted`.
- Ya existe `.archive(Entry)` para archivar.

### MarkdownBridge
- Exporta tareas con `[ ]`/`[x]` checkbox. Entries no-tarea se exportan como bullets sin checkbox.
- Importa `isCompleted` solo para entries que tienen checkbox pattern.

### Archivos clave involucrados
- `issue/Core/Models/Entry.swift` — modelo, no necesita cambios de schema
- `issue/Core/Models/EntryAction.swift` — enum de acciones, agregar `.resolve`
- `issue/Features/Feed/Components/EntryRow.swift` — UI de cada entry
- `issue/Features/Feed/FeedViewModel.swift` — filtrado y acciones
- `issue/Features/Feed/FeedView.swift` — contenedor principal
- `issue/Features/Categories/CategoriesView.swift` — vista de categorias
- `issue/Features/Categories/CategoriesViewModel.swift` — datos agrupados
- `issue/Features/Today/TodayView.swift` — vista Today
- `issue/Features/Today/TodayViewModel.swift` — datos Today
- `issue/Features/Feed/Components/CategorySection.swift` — seccion por categoria
- `issue/Features/Feed/Components/TaskSection.swift` — seccion de tareas (ya tiene CompletedSection colapsable)
- `issue/Shared/Components/TaskCheckbox.swift` — checkbox animado
- `issue/Core/Services/MarkdownBridge/MarkdownBridgeService.swift` — export/import markdown

## Historias de Usuario

1. **Como** usuario con 100+ entries, **quiero** poder marcar cualquier entry como "resuelta" (no solo tareas), **para** que desaparezca del feed activo sin perderla.
2. **Como** usuario revisando mi feed, **quiero** acceder a un historial de entries resueltas, **para** poder consultar o revertir decisiones pasadas.
3. **Como** usuario capturando rapido, **quiero** que el gesto de resolver sea igual de rapido que completar una tarea, **para** no romper mi flujo de trabajo.

## Criterios de Aceptacion

### CA-1: Resolver entries no-tarea desde el menu contextual
- **Given** una entry de cualquier categoria que no sea tarea (idea, pensamiento, conocimiento, inspiracion, bitacora, recordatorio, fecha importante, imagen, o categoria custom)
- **When** el usuario hace click derecho (o click en el menu ellipsis) sobre la entry
- **Then** aparece una opcion "Resolver" con icono `checkmark.circle` en el menu contextual
- **And** al seleccionarla, la entry se marca como `isCompleted = true` y desaparece del feed activo con animacion

### CA-2: Resolver tareas mantiene el comportamiento actual de checkbox
- **Given** una entry de categoria `.tarea`
- **When** el usuario hace click en el checkbox
- **Then** el comportamiento es identico al actual (toggle `isCompleted`, animacion de ring pulse, strikethrough)
- **And** ademas, la opcion del menu contextual cambia de "Marcar completada" a "Resolver" para mantener consistencia de lenguaje

### CA-3: Entries resueltas desaparecen del feed activo
- **Given** una entry de cualquier categoria que es marcada como resuelta/completada
- **When** el feed se recalcula (tanto en vista Today como en Categories)
- **Then** la entry NO aparece en el feed activo por defecto
- **And** el contador de entries de la seccion se actualiza (baja en 1)

### CA-4: Seccion "Historial" en la vista Categories
- **Given** que existen entries resueltas en el proyecto actual
- **When** el usuario esta en la vista Categories
- **Then** aparece una seccion "Historial" al final de todas las categorias
- **And** la seccion esta colapsada por defecto
- **And** al expandirla muestra las entries resueltas agrupadas por categoria, con texto en `textMuted` y un indicador visual de "resuelto"
- **And** muestra el conteo total de entries resueltas en el header

### CA-5: Revertir una entry resuelta
- **Given** una entry que fue marcada como resuelta, visible en la seccion Historial
- **When** el usuario hace click derecho sobre ella
- **Then** aparece la opcion "Reactivar" con icono `arrow.uturn.backward`
- **And** al seleccionarla, la entry vuelve al feed activo con `isCompleted = false`

### CA-6: Gesto rapido de swipe/doble-click para resolver
- **Given** una entry de cualquier categoria en el feed activo
- **When** el usuario hace doble-click en el bullet/icono de la entry (no en el texto, que abre edicion)
- **Then** la entry se marca como resuelta con una animacion breve de fade-out
- **And** para tareas, el doble-click en el checkbox sigue funcionando como toggle normal (no cambiar)

### CA-7: Markdown Bridge exporta estado resuelto para no-tareas
- **Given** una entry no-tarea que fue marcada como resuelta
- **When** el Markdown Bridge exporta a `.wips/ISSUES.md`
- **Then** la entry resuelta se exporta con prefijo `~~texto~~` (strikethrough markdown) y sufijo `(resuelto)`
- **And** al importar, si una entry tiene el patron `~~...~~ (resuelto)`, se interpreta como `isCompleted = true`

## Casos Borde

- **Entry pinneada que se resuelve**: Debe perder el pin automaticamente (`isPinned = false`) al resolver. Una entry resuelta no tiene sentido fijada arriba del feed.
- **Entry resuelta que se edita en markdown por un agente**: Si un agente externo quita el strikethrough/`(resuelto)` del markdown, la importacion debe reactivar la entry (`isCompleted = false`).
- **Proyecto "Todos" (`.all`)**: El historial debe funcionar tambien en la vista agregada, mostrando entries resueltas de todos los proyectos.
- **Filtro "Solo pendientes" activo**: Con `showPendingOnly = true`, las entries resueltas ya estan filtradas. El historial NO debe aparecer cuando este filtro esta activo (seria contradictorio).
- **Entry sin texto (solo imagen)**: Se puede resolver igual que cualquier otra entry. En el historial se muestra con el fallback "Imagen adjunta".
- **Resolver muchas entries rapido**: Si el usuario resuelve varias entries seguidas, cada una debe animarse y desaparecer individualmente, sin saltos bruscos en el layout (usar `withAnimation(.standard)`).
- **Contadores en SectionHeader**: Los contadores deben reflejar solo entries activas (no resueltas). El conteo de "nuevas" (`newCount`) ignora entries resueltas.
- **Categories custom**: Las entries con `customCategoryId` tambien pueden resolverse. En el historial se agrupan bajo su categoria custom.

## Fuera de Alcance

- **No incluye auto-resolver por tiempo**. El usuario decide explicitamente que resolver. Una idea de hace 3 meses puede seguir siendo valida.
- **No incluye bulk resolve** (seleccionar multiples entries y resolver de una vez). Es una mejora futura natural pero agrega complejidad de seleccion multiple que hoy no existe.
- **No incluye fecha de resolucion** (`resolvedAt`). Reutilizamos `isCompleted` y `updatedAt` ya existentes. Si en el futuro se necesita un campo dedicado, es una migracion simple.
- **No incluye razon de resolucion** (ej: "descartada", "convertida a tarea", "ya no aplica"). Agrega complejidad de UI sin valor claro para V1. El usuario sabe por que resolvio algo.
- **No incluye historial en la vista Today**. Today muestra lo accionable y reciente. El historial vive en Categories.
- **No incluye estadisticas de resolucion** (cuantas entries resolves por semana, etc.). Feature separada de analytics.

## Notas de Implementacion

### 1. No se necesita migracion de modelo
El campo `isCompleted` ya existe en todas las entries. Hoy simplemente no se usa para no-tareas. El cambio es puramente de UI y logica de filtrado.

### 2. Renombrar el concepto en la UI
- En el `EntryAction` enum: agregar case `.resolve(Entry)` como alias semantico, o renombrar `.toggle` internamente. Recomendacion: mantener `.toggle` internamente pero cambiar el label del menu segun el contexto.
- Menu contextual para tareas: "Resolver" (en vez de "Marcar completada") / "Reactivar" (en vez de "Marcar pendiente")
- Menu contextual para no-tareas: "Resolver" / "Reactivar"

### 3. Filtrado en FeedViewModel
- `recalculateFilteredEntries()` ya filtra archivados. Agregar filtro: `result = result.filter { !$0.isCompleted }` DESPUES del filtro de archivados. Esto es el cambio central.
- Agregar propiedad `resolvedEntries: [Entry]` que retorne todas las entries completadas del proyecto actual (sin filtro de archivado).
- Considerar que `showPendingOnly` hoy ya filtra por `!isCompleted`. Con el nuevo comportamiento base, `showPendingOnly` se vuelve redundante. Evaluar si eliminarlo o dejarlo como toggle explicito.

### 4. Seccion Historial en CategoriesView
- Crear un componente `HistorialSection` siguiendo el patron de `CompletedSection` en `TaskSection.swift` (colapsable, header con conteo, entries en estilo muted).
- Ubicarlo al final del `LazyVStack` en `CategoriesView`, despues de las custom categories.
- Recibir entries resueltas del `CategoriesViewModel` (nueva computed property `resolvedEntriesByCategory`).

### 5. EntryRow — gesto de resolver para no-tareas
- Donde hoy hay un bullet (`Circle().fill(bulletColor)`) para no-tareas, hacerlo clickeable.
- Al hacer doble-click, disparar `.resolve(entry)` → mismo efecto que toggle.
- Animacion: fade out + slide left sutil, similar al `pendingComplete` delay de 0.35s que ya existe para tareas.
- En el menu contextual: agregar "Resolver"/"Reactivar" para TODAS las categorias (hoy solo aparece para `isTask`).

### 6. Visual del Historial
- Entries resueltas en el historial: texto en `theme.textMuted`, con un icono `checkmark.circle.fill` pequeño (en `theme.textMuted`) reemplazando el bullet.
- Header del historial: "Historial (N)" con icono `clock.arrow.circlepath`, estilo similar a `SectionHeader` pero mas discreto.
- Agrupacion interna: por categoria (Tareas resueltas, Ideas resueltas, etc.), cada grupo colapsable.

### 7. MarkdownBridge
- En `exportMarkdown()`: entries no-tarea con `isCompleted == true` se exportan como `- ~~texto~~ (resuelto) <!-- entry:uuid -->`.
- En `parseMarkdown()`: agregar pattern matching para `~~(.+?)~~\s*\(resuelto\)` que setee `isCompleted = true` en el `MarkdownChange`.
- Tareas siguen usando `[x]`/`[ ]` como hasta ahora.

### 8. Patron a seguir
- `CompletedSection` en `TaskSection.swift` (linea 167-219) es el patron exacto para la seccion colapsable del historial. Copiar estructura: boton toggle + chevron + conteo + lista condicional.
- `entrySort()` en `FeedViewModel` ya pone completados al final. Con el nuevo filtro base esto se vuelve irrelevante para el feed activo, pero sigue siendo util para el historial.
- Animaciones: usar `.standard` (definido en `Animation+Tokens`) para transiciones, `.micro` para hovers.

### 9. Archivos a crear
- `issue/Features/Feed/Components/HistorialSection.swift` — seccion colapsable del historial

### 10. Archivos a modificar
- `issue/Features/Feed/FeedViewModel.swift` — filtrado base, nueva computed `resolvedEntries`
- `issue/Features/Feed/Components/EntryRow.swift` — menu "Resolver" para todas las categorias, doble-click en bullet, estilo visual resuelto
- `issue/Features/Categories/CategoriesView.swift` — agregar HistorialSection al final
- `issue/Features/Categories/CategoriesViewModel.swift` — nueva computed `resolvedEntriesByCategory`
- `issue/Features/Today/TodayViewModel.swift` — verificar que los filtros existentes (`!$0.isCompleted`) ya cubren el caso
- `issue/Core/Services/MarkdownBridge/MarkdownBridgeService.swift` — export/import del estado resuelto para no-tareas

## Estimacion

**2 dias** para un solo desarrollador.

- Dia 1: Filtrado base en FeedViewModel (el cambio core), menu contextual "Resolver" en EntryRow para todas las categorias, animacion de fade-out al resolver.
- Dia 2: Componente HistorialSection, integracion en CategoriesView, ajuste de MarkdownBridge, testing manual de casos borde.

La mayoria del trabajo es UI. El modelo no cambia. El filtrado es una linea. Lo que toma tiempo es el componente del historial y asegurar que las animaciones se sientan bien.
