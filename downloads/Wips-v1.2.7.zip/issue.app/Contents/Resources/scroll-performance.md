# Scroll Performance — Diagnóstico y Plan

## Estado actual

Se aplicaron fixes iniciales que mejoraron el scroll pero no lo dejaron 100% smooth:
- Removidas `.animation()` de contenedores LazyVStack (6 lugares)
- Removidas `.transition(.opacity)` de rows
- Convertidos LazyVStack internos a VStack (solo el outer es lazy)
- Removidos `withAnimation` de `.onAppear` callbacks
- `seenEntryIDs` ya no es `@Published` + debounce en escritura a disco

## Causas restantes (por prioridad)

### 1. `@ObservedObject feedVM` compartido — CRÍTICO

Cualquier cambio en cualquier `@Published` de FeedViewModel (searchText, isClassifying, showClassifiedToast, filteredEntries...) invalida `FeedView.body` → re-evalúa `groupedView` → TODAS las secciones → TODOS los rows.

**Fix**: Migrar `FeedViewModel` de `ObservableObject` a `@Observable` macro (requiere macOS 14+). Con `@Observable`, solo las vistas que leen la propiedad específica que cambió se re-renderizan.

**Refs**:
- https://www.avanderlee.com/swiftui/observable-macro-performance-increase-observableobject/
- https://www.donnywals.com/understanding-how-and-when-swiftui-decides-to-redraw-views/

### 2. `.onHover` con `withAnimation` en cada row — ALTO

En macOS, mientras se scrollea con trackpad, el cursor se mueve → `.onHover` se dispara en cada row que pasa por debajo → `withAnimation(.micro)` arranca transacciones de animación. Bug conocido en macOS 15 Sequoia: `_hitTestForEvent` consume ~85% del CPU durante scroll (FB15241636).

**Fix**: Quitar `withAnimation` del `.onHover`. Cambio de estado directo sin animación.

**Archivos**: `NotionEntryRow.swift:166-170`, `TimeLineRow.swift:94-98`

### 3. ~100 `.dropDestination` activos siempre — ALTO

Cada entry tiene 2 `EntryDropGap` (antes y después) con `.dropDestination`. Con 50 entries = ~100 drop targets en el hit-test tree permanentemente, aunque nadie está arrastrando nada.

**Fix**: Agregar `@Published var isDragging: Bool` al ViewModel. Solo renderizar `EntryDropGap` cuando `isDragging == true`. Quita ~100 drop targets del view tree durante scroll normal.

**Archivos**: `EntryDropGap.swift`, `NotionCategorySection.swift:bucketEntries()`, `NotionTaskSection.swift`

### 4. `@Binding editingEntryID` compartido — MEDIO-ALTO

Todos los rows reciben el mismo `@Binding var editingEntryID: UUID?`. Cuando cualquier row empieza a editar, `.onChange(of: editingEntryID)` se dispara en TODOS los rows visibles.

**Fix**: Cada row maneja su propio `@State private var isEditing`. Usar callback o environment action para notificar al parent. O usar focused-field approach.

**Archivos**: `NotionEntryRow.swift`, `FeedView.swift`, todas las secciones

### 5. `.contextMenu` + `Menu` duplicados — MEDIO

Cada row tiene un `Menu {}` (botón ellipsis) Y `.contextMenu {}`. El `.contextMenu` no es lazy — evalúa el builder (incluyendo `reclassifyOptions()`) en cada body evaluation.

**Fix**: Quedarse con uno solo. O envolver `menuContent` en un view struct dedicado que solo evalúa cuando se abre.

**Archivos**: `NotionEntryRow.swift:134-192`

### 6. `.alert` en cada row — MEDIO

Cada `NotionEntryRow` tiene `.alert(isPresented: $showDeleteConfirmation)`. Tener un alert modifier en cada row visible = SwiftUI chequea el binding en cada body evaluation.

**Fix**: Mover el alert a `FeedView`. Un solo `@State private var entryToDelete: Entry?` compartido.

### 7. `groupedEntries` computado en la vista — MEDIO

`NotionCategorySection.groupedEntries` ejecuta `GroupedEntries.group(entries)` en cada body evaluation. Debería pre-computarse en el ViewModel (principio "Thin Views").

### 8. Bug macOS 15 Sequoia — SIN FIX

Bug del framework: hit-testing ineficiente (`_hitTestForEvent`). Se mitiga reduciendo cantidad de views con hit-testing (menos `.onHover`, `.dropDestination`, `.draggable`). Apple lo reconoció (FB15241636), fix pendiente en futuro OS update.

**Refs**:
- https://developer.apple.com/forums/thread/764264
- https://news.ycombinator.com/item?id=41139144

### 9. List vs ScrollView+LazyVStack

`List` usa `NSTableView` con reciclaje real de celdas. En benchmarks: List tuvo 4.6 hangs vs LazyVStack 78 hangs. Pero `List` en macOS limita la customización visual. Última opción.

**Refs**:
- https://www.strv.com/blog/swiftui-list-vs-lazyvstack
- https://fatbobman.com/en/posts/list-or-lazyvstack/

## Plan de implementación sugerido

1. **Quick wins** (sin refactor): Quitar `withAnimation` de `.onHover`, renderizar drop gaps solo durante drag
2. **Medio**: Mover `.alert` al parent, eliminar `.contextMenu` duplicado, pre-computar `groupedEntries`
3. **Refactor mayor**: Migrar a `@Observable`, eliminar `@Binding editingEntryID` compartido
