# Wips — Estrategia de Monetizacion (Freemium)

Fecha: 2026-04-03
Status: **Definido, pendiente de implementacion**

---

## Modelo elegido: Trial 14 dias + Free tier limitado + Pro

### Por que este modelo

Gaston es solo founder/inversor. No puede costear miles de usuarios free indefinidamente.
El trial de 14 dias deja que el usuario pruebe todo y se enamore. Despues cae a un free
tier restrictivo que retiene usuarios (word of mouth) pero incentiva fuerte el upgrade.
Conversion esperada: 8-12% (vs 5% del freemium puro).

---

## Tiers

### Trial (14 dias desde primer sign in)

Todo desbloqueado como si fuera Pro. El objetivo es que el usuario experimente el valor
completo antes de decidir.

- Proyectos: ilimitados
- Clasificacion AI: ilimitada
- Session Summaries (Agent Observability): 3/dia
- Chat: free (informativo)
- Custom Categories: free
- Repo Linking + Markdown Bridge: ilimitado
- Imagenes/Attachments: free

### Free (despues del trial)

Restrictivo. El usuario puede seguir usando la app pero siente la diferencia.

| Feature                  | Limite                              |
|--------------------------|-------------------------------------|
| Proyectos                | 1                                   |
| Clasificacion AI         | 10 entries/dia                      |
| Session Summaries        | 0 (deshabilitado)                   |
| Chat                     | Free (informativo)                  |
| Custom Categories        | Free                                |
| Repo Linking             | 1 repo (ligado al proyecto)         |
| Imagenes/Attachments     | Free                                |

**Proyecto "General" no existe.** Solo proyectos creados por el usuario.

**Proyectos excedentes post-trial:** quedan en modo **read-only**. El usuario puede leer
sus entries pero no crear nuevas ni editar. Puede elegir cual mantener activo.

**Cuando se alcanza el limite de clasificacion:** la entry se crea y se guarda (no se
pierde trabajo), pero **sin clasificacion AI**. Se muestra CTA de upgrade.

### Pro ($5 USD/mes)

| Feature                  | Limite       |
|--------------------------|--------------|
| Proyectos                | Ilimitados   |
| Clasificacion AI         | Ilimitada    |
| Session Summaries        | Ilimitadas   |
| Chat                     | Free         |
| Custom Categories        | Free         |
| Repo Linking             | Ilimitado    |
| Imagenes/Attachments     | Free         |

**Descuento anual a evaluar:** ~$50/ano ($4.17/mes) para mejorar retencion.

---

## Pricing: por que $5 USD/mes

### Costos estimados por usuario activo (gpt-4o-mini via proxy)

| Feature              | Calls/dia | Tokens/call (in+out) | Costo/mes estimado |
|----------------------|-----------|----------------------|--------------------|
| Clasificacion        | ~20       | ~500 + 20            | ~$0.15             |
| Session Summaries    | ~5        | ~2000 + 2500         | ~$0.50             |
| Chat                 | ~5        | ~300 + 800           | ~$0.05             |
| **Total**            |           |                      | **~$0.70/mes**     |

**Margen a $5/mes: ~$4.30/usuario (~86%).** Muy sano.

### Comparables en el mercado

- Linear: $8/user/mes
- Raycast Pro: $8/mes
- Wips a $5: precio de entrada bajo, bueno para launch. Se puede subir despues.

---

## Pasarela de pago: Stripe

### Por que Stripe

- 2.9% + $0.30/transaccion (el mas barato en fees)
- Maneja suscripciones, renovaciones, cancelaciones, facturas
- Stripe Checkout: pagina de pago hosted (0 UI custom que construir)
- Webhooks a Vercel (donde ya esta el proxy)
- Portal de billing para que el usuario gestione su suscripcion sin soporte

### Alternativas descartadas

| Opcion         | Razon de descarte                                      |
|----------------|--------------------------------------------------------|
| RevenueCat     | Pensado para App Store, overkill para distribucion fuera de store |
| Lemon Squeezy  | 5% + $0.50/tx, mas caro                               |
| Polar.sh       | Muy nuevo, poca documentacion                          |

### Flow de pago

1. Usuario toca "Upgrade a Pro" en la app
2. Se abre el browser con Stripe Checkout (hosted por Stripe)
3. Usuario paga con tarjeta
4. Webhook de Stripe llega al proxy (`/api/stripe/webhook`)
5. Proxy actualiza el plan del usuario en Redis
6. App consulta `/api/account/status` → desbloquea features Pro

---

## Arquitectura: quien controla que

### Proxy (Vercel + Upstash Redis) — controla TODO lo de billing y limites

El proxy es la fuente de verdad. La app no decide si puede o no hacer algo;
le pregunta al proxy.

**Redis ya tiene:**
- `user:{appleUserID}` — UserRecord con email, nombre, fechas
- `refresh:{token}` — refresh tokens con TTL
- Rate limiting generico (`checkRateLimit`)

**Redis necesita (nuevo):**
- `user:{appleUserID}` agregar campos: `plan` (trial/free/pro), `trialStartDate`, `stripeCustomerId`, `stripeSubscriptionId`
- `usage:{appleUserID}:{date}:classifications` — counter diario con TTL 24h
- `usage:{appleUserID}:{date}:summaries` — counter diario con TTL 24h

**Endpoints nuevos en proxy:**
- `GET /api/account/status` — devuelve plan, dias restantes de trial, usage del dia, limites
- `POST /api/stripe/webhook` — recibe eventos de Stripe (subscription.created, .deleted, invoice.paid, etc.)
- `GET /api/account/checkout` — genera Stripe Checkout session URL
- `GET /api/account/portal` — genera Stripe billing portal URL

**Middleware en `/api/openai`:**
- Antes de procesar cualquier request AI, consulta plan + usage
- Si excede limite → responde 403 con `{ "error": "limit_reached", "limit": "classifications", "upgrade_url": "..." }`
- La app interpreta el 403 y muestra UI de upgrade

### App (SwiftUI) — solo UI y cache

La app no toma decisiones de billing. Solo:
- Consulta `/api/account/status` al iniciar y periodicamente
- Cachea el status localmente para UI responsiva
- Muestra estados: trial (dias restantes), free (limites), pro
- Muestra CTAs de upgrade cuando corresponde
- Maneja read-only en proyectos excedentes
- Abre browser para Stripe Checkout/Portal

---

## Logica de trial

- **Inicio:** primer sign in con Apple (el proxy registra `trialStartDate` en Redis)
- **Duracion:** 14 dias
- **Calculo:** `trialStartDate + 14 dias < hoy` → trial expirado → cae a free
- **UI:** banner con "Te quedan X dias de prueba" en la app
- **Fin del trial:** notificacion clara + transicion a free tier

---

## Comportamiento en limites

| Situacion                                | Que pasa                                                |
|------------------------------------------|---------------------------------------------------------|
| Free + crea entry #11 del dia            | Entry se crea SIN clasificacion AI. CTA upgrade.        |
| Free + intenta crear proyecto #2         | Bloqueado. CTA upgrade.                                 |
| Free + intenta ver Session Summary       | Feature deshabilitada. CTA upgrade.                     |
| Post-trial + tiene 4 proyectos           | 3 quedan read-only. Puede elegir cual mantener activo.  |
| Pro + suscripcion vence                  | Cae a free. Proyectos extra → read-only.                |

---

## Pendiente de definir

- [ ] Descuento anual ($50/ano?)
- [ ] Onboarding: como comunicar el trial al usuario nuevo
- [ ] Emails transaccionales (trial ending, payment failed) — Stripe puede manejar algunos
- [ ] Analytics: tracking de conversion, churn, feature usage
