# Spec: Agent Observability — Session Summary Pipeline

> Reemplaza y supersede `passive-capture.md`. Esta es la spec definitiva del pipeline de procesamiento de sesiones de agentes.

## Problema

El usuario trabaja con agentes de codigo (Claude Code, eventualmente Cursor/Codex) y cuando vuelve a la app no tiene visibilidad de que paso en esas sesiones. No sabe que archivos se tocaron, que decisiones se tomaron, ni puede reconstruir el contexto sin leer logs crudos JSONL. Necesita resumenes automaticos por sesion que capturen lo relevante sin esfuerzo manual.

## Contexto Tecnico

### Infraestructura existente que se reutiliza

- **`LLMCompletionService`** (`Core/Services/LLM/LLMCompletionService.swift`): protocolo ya abstraido con `complete(prompt:model:maxTokens:temperature:systemMessage:jsonMode:)`. La implementacion `OpenAICompletionService` usa `ProxyClient` internamente.
- **`ProxyClient`** (`Core/Services/ProxyClient.swift`): maneja auth JWT + retry automatico en 401. Toda request de red pasa por aca.
- **`AppState`** (`App/AppState.swift`): DI container singleton. Ya instancia `OpenAICompletionService(proxyClient: proxy)` como `llm` local, usado por `WipsieService`. El nuevo service se conecta igual.
- **Patron de security-scoped bookmarks** (`MarkdownBridgeService`): `resolveBookmark(for:)`, `ensureAccess(for:)`, `startAccessingSecurityScopedResource()`. El patron esta probado y funciona para acceso sandbox a carpetas externas.
- **Patron de file watching** (`MarkdownBridgeService`): `DispatchSource.makeFileSystemObjectSource` con debounce de 3s. Probado en produccion.
- **Patron de JSON persistence** (`EntryStore`, `ProjectStore`): save manual en cada operacion, archivo JSON en `~/Library/Application Support/Wips/`.
- **`Project` model** (`Core/Models/Project.swift`): ya tiene `repoPath`, `repoBookmark`, `agentIntegrations: Set<AgentIntegration>`.
- **`AgentIntegration` enum** (`Core/Models/AgentIntegration.swift`): `.claudeCode`, `.cursor`, `.codex`.

### Formato JSONL de Claude Code

Ubicacion: `~/.claude/projects/{path-dashified}/{sessionId}.jsonl`

Cada linea es JSON con campos clave:
- `type`: `user`, `assistant`, `progress`, `file-history-snapshot`, `system`
- `message.content[]`: array de bloques `text`, `tool_use`, `thinking`, `tool_result`
- `sessionId`, `timestamp`, `cwd`, `gitBranch`, `version`, `entrypoint`
- `tool_use` tiene: `name` (Edit, Read, Bash, Grep, Glob, Write), `input` (con `file_path`, `pattern`, `command`, etc.)

### Lo que NO existe aun en el codigo

No hay ningun archivo de SessionCaptureService, ClaudeCodeSessionProvider, SessionParser, ni modelos de sesion. El `architecture-map.md` fue actualizado anticipando esta feature, pero el codigo es 100% por escribir.

## Historias de Usuario

1. **Como** desarrollador indie, **quiero** que Wips procese automaticamente mis sesiones de Claude Code al abrir la app, **para** tener un resumen estructurado sin leer logs JSONL.

2. **Como** usuario con multiples proyectos, **quiero** que cada resumen se asocie al proyecto correcto automaticamente (via `cwd`), **para** ver la actividad de agentes en contexto.

3. **Como** usuario consciente de seguridad, **quiero** que mis API keys, tokens y secrets se filtren antes de enviar nada a OpenAI, **para** no exponer credenciales accidentalmente.

## Criterios de Aceptacion

### CA-1: Procesamiento automatico al abrir la app
- **Given** el usuario tiene sesiones de Claude Code no procesadas en `~/.claude/` y el bookmark de acceso esta vigente
- **When** la app se inicia (o el usuario abre un proyecto)
- **Then** las sesiones nuevas se procesan en background: se parsean, se resumen via LLM, y se guardan en `sessions_log.json` del proyecto correspondiente

### CA-2: Matching sesion-proyecto por cwd
- **Given** una sesion de Claude Code tiene `cwd: "/Users/gaston/Desktop/myproject"` y existe un proyecto con `repoPath: "/Users/gaston/Desktop/myproject"`
- **When** el pipeline procesa esa sesion
- **Then** el resumen se asocia al proyecto correcto y se persiste en su directorio

### CA-3: Deduplicacion de sesiones
- **Given** una sesion ya fue procesada (su `sessionID` esta registrado con su `fileSize` y `lastModified`)
- **When** el pipeline corre de nuevo
- **Then** esa sesion se omite (no se reprocesa ni se llama al LLM)

### CA-4: Re-procesamiento si la sesion crecio
- **Given** una sesion ya procesada cuyo archivo JSONL crecio en tamano (el agente siguio trabajando)
- **When** el pipeline detecta que `fileSize` o `lastModified` cambiaron
- **Then** se re-procesa la sesion y se actualiza el resumen existente

### CA-5: Sanitizacion de secrets
- **Given** el contenido JSONL contiene patrones como `sk-...`, `ghp_...`, `AKIA...`, `password`, `token=`, `BEGIN RSA PRIVATE`
- **When** el parser extrae los mensajes
- **Then** las lineas con esos patrones se sanitizan (reemplazadas por `[REDACTED]`) antes de construir el prompt

### CA-6: Filtrado de contenido irrelevante
- **Given** un archivo JSONL con mensajes de tipo `thinking`, `tool_result`, `progress`, `file-history-snapshot`
- **When** el parser procesa el archivo
- **Then** esos tipos se descartan; solo se retienen: mensajes `user` (texto), mensajes `assistant` (texto + nombre de tool_use con file_path del input)

### CA-7: Truncado para limite de tokens
- **Given** una sesion larga cuyo transcript filtrado supera ~8000 tokens estimados
- **When** el prompt builder construye el prompt para gpt-4o-mini
- **Then** el contenido se trunca (cortando mensajes antiguos primero) para caber en el limite

### CA-8: Modelo SessionSummary persistido correctamente
- **Given** el LLM retorna un resumen exitoso
- **When** el pipeline guarda el resultado
- **Then** se persiste un `SessionSummary` con: `id`, `sessionID`, `projectID`, `date`, `duration` (calculada de timestamps), `branch`, `filesModified` (paths relativos), `toolsUsed` (conteo por herramienta), `summary` (texto del LLM), `decisions` (lista del LLM), `userMessages` (conteo), `agentMessages` (conteo)

### CA-9: Bookmark global para ~/.claude
- **Given** el usuario no ha otorgado acceso a `~/.claude/` todavia
- **When** el pipeline necesita leer sesiones por primera vez
- **Then** se presenta un NSOpenPanel apuntando a `~/.claude/`, el bookmark se persiste globalmente (no por proyecto), y se reutiliza en futuros launches

### CA-10: Tolerancia a fallos
- **Given** el LLM falla (red, timeout, rate limit) al procesar una sesion
- **When** ocurre el error
- **Then** esa sesion se salta silenciosamente (se loggea con OSLog), las demas sesiones siguen procesandose, y la sesion fallida se reintenta en el proximo launch

## Casos Borde

- **Sesion sin `cwd`**: se ignora — no se puede asociar a un proyecto.
- **`cwd` no matchea ningun proyecto**: la sesion se ignora. No se crea un resumen huerfano.
- **Sesion en curso** (el agente sigue activo): el archivo JSONL puede no tener un "final" claro. Se procesa lo que hay; si crece, CA-4 lo maneja.
- **Multiples sesiones para el mismo proyecto el mismo dia**: se generan resumenes independientes (uno por sesion, no se agrupan por dia).
- **Bookmark de `~/.claude/` stale**: intentar recrear. Si falla, loggear y no procesar sesiones (no bloquear la app).
- **Archivo JSONL corrupto** (linea no es JSON valido): saltear esa linea con `try?` y seguir parseando.
- **Sesion muy corta** (1-2 mensajes): procesarla igual — el LLM decidira si hay algo util que resumir.
- **Proyecto sin `repoPath`**: no participa del matching, se ignora para sesiones.
- **`~/.claude/` no existe**: el provider retorna lista vacia, sin error.

## Fuera de Alcance

- **UI/presentacion**: no se incluye ninguna vista, card, ni integracion con el feed. Es un task separado.
- **Pattern detection**: analizar N resumenes para detectar patrones de trabajo es una feature futura.
- **Providers para Cursor/Codex**: solo se implementa `ClaudeCodeSessionProvider`. El protocolo queda listo para extension.
- **Cambios a Wipsie**: el briefing sigue igual por ahora. La integracion de session logs en Wipsie es un task separado.
- **File watcher en `~/.claude/`**: el MVP solo procesa sesiones al abrir la app / cambiar de proyecto. El watcher es una optimizacion futura.
- **Creacion de entries desde sesiones**: los resumenes NO generan entries en el feed.
- **Configuracion de modelo LLM**: hardcoded a gpt-4o-mini. No hay UI para elegir otro modelo.
- **Rate limiting local**: no se limita cuantas sesiones se procesan por launch. Si hay 50, se procesan las 50.

## Notas de Implementacion

### Estructura de archivos a crear

```
issue/Core/Services/AgentSessions/
  AgentSessionProvider.swift        -- Protocolo: discoverSessions(matching:) -> [DiscoveredSession]
  ClaudeCodeSessionProvider.swift   -- Implementacion para Claude Code (lee ~/.claude/projects/*/*.jsonl)
  SessionParser.swift               -- Parsea JSONL -> SessionTranscript (filtra, sanitiza)
  SessionPromptBuilder.swift        -- SessionTranscript -> String (prompt listo para LLM)
  SessionSummaryService.swift       -- Orquestador: provider -> parser -> prompt -> LLM -> store
  Models/
    RawSessionMessage.swift         -- Struct Codable para deserializar cada linea JSONL
    SessionTranscript.swift         -- Modelo intermedio (mensajes filtrados + metadata)
    SessionSummary.swift            -- Modelo final persistido

issue/Core/Stores/
  SessionSummaryStore.swift         -- Persistence: projects/{id}/sessions_log.json + processed_sessions.json global
```

### Patron de service a seguir

Seguir el patron de `WipsieService`: `@MainActor final class`, recibe `LLMCompletionService` en init, usa `OSLog` para logging. Referencia: `Core/Services/Wipsie/WipsieService.swift`.

### DI en AppState

`SessionSummaryService` se instancia en `AppState.init()` despues de crear `llm` (que ya existe como local). Recibe: `llm`, `projectStore`, nuevo `SessionSummaryStore`. Se llama `sessionSummaryService.processNewSessions()` al final del init (como el ultimo paso, en background con `Task {}`).

### Bookmark global

A diferencia de `MarkdownBridgeService` que guarda bookmarks por proyecto en `Project.repoBookmark`, el bookmark de `~/.claude/` es **global** (aplica a todos los proyectos). Opciones de persistencia:
- Nuevo archivo `claude_sessions_bookmark.json` en Application Support
- O una propiedad en UserDefaults (es solo Data del bookmark)

El NSOpenPanel se presenta la primera vez que se necesita acceso. Patron a seguir para resolver: `MarkdownBridgeService.resolveBookmark(for:)`.

### Matching sesion-proyecto

`ClaudeCodeSessionProvider` lee el `cwd` del primer mensaje de cada sesion. `SessionSummaryService` compara con `project.repoPath` de todos los proyectos vinculados. Match exacto o por prefijo (para monorepos con subcarpetas).

### Persistencia

Dos archivos JSON:
- `projects/{projectID}/sessions_log.json` — array de `SessionSummary` (uno por sesion procesada)
- `processed_sessions.json` (global, en raiz de Wips/) — dict de `sessionID -> { fileSize, lastModified, processedAt }` para deduplicacion

Seguir el patron de `EntryStore` para paths y save/load.

### Prompt para gpt-4o-mini

El `SessionPromptBuilder` estructura el transcript como:

```
Resume esta sesion de desarrollo entre un usuario y un agente de codigo.

## Sesion
- Fecha: {date}
- Branch: {branch}
- Duracion: ~{minutes} minutos
- Archivos tocados: {fileList}

## Conversacion (resumida)
User: {mensaje 1}
Agent: {accion 1} -> {archivos tocados}
User: {mensaje 2}
...

## Instrucciones
Responde en JSON con este formato:
{
  "summary": "3-5 oraciones describiendo que se hizo y por que",
  "decisions": ["decision clave 1", "decision clave 2"]
}
```

Parametros del LLM call: model `gpt-4o-mini`, maxTokens `800`, temperature `0.3`, jsonMode `true`.

### Debug: log del prompt en consola de Xcode

Antes de enviar al proxy, el `SessionSummaryService` loggea el prompt completo en la consola de Xcode via `OSLog` con nivel `.debug`. Esto permite:
- Verificar visualmente que el prompt esta bien armado antes de gastar tokens
- Detectar problemas de sanitizacion (si se filtra un secret)
- Iterar rapido el formato del prompt sin necesidad de inspeccionar variables en el debugger

```swift
logger.debug("📋 [SessionSummary] Prompt para sesion \(sessionID):\n\(prompt)")
```

**Importante**: este log se activa solo en builds DEBUG (no en release). Usar `#if DEBUG` o el nivel `.debug` de OSLog que no se persiste en produccion por defecto.

### Extraccion de metadata del JSONL

Del parsing directo (sin LLM):
- `filesModified`: extraer de `tool_use.input.file_path` de herramientas Edit, Write
- `toolsUsed`: contar `tool_use.name` por tipo
- `duration`: diferencia entre primer y ultimo timestamp
- `branch`: del campo `gitBranch` del primer mensaje
- `userMessages` / `agentMessages`: conteo por `type`

Del LLM:
- `summary`: texto narrativo
- `decisions`: lista de decisiones clave

## Estimacion

**3 dias** para un solo dev.

- **Dia 1**: Modelos (`RawSessionMessage`, `SessionTranscript`, `SessionSummary`) + `AgentSessionProvider` protocolo + `ClaudeCodeSessionProvider` (descubrimiento de sesiones + parsing JSONL + sanitizacion). Incluye `SessionParser`.
- **Dia 2**: `SessionPromptBuilder` + `SessionSummaryService` (orquestador completo) + `SessionSummaryStore` (persistencia + deduplicacion). Integracion con `AppState`.
- **Dia 3**: Bookmark global (NSOpenPanel + persistencia) + matching cwd-proyecto + testing con sesiones reales + ajuste de prompts.
