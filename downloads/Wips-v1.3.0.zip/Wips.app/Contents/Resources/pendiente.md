# Fix: Sparkle auto-updates fallan al instalar

## Contexto

Cuando el usuario presiona "Buscar ahora" en Settings, Sparkle descarga la actualización (barra de progreso avanza), pero después salta un error genérico: "No se puede actualizar, ocurrió un error, probá más tarde." El update nunca se instala.

## Causa raíz encontrada

### 1. App name mismatch en el zip de Sparkle (causa principal)

El zip que Sparkle descarga contiene `issue.app/` (el PRODUCT_NAME del proyecto), pero la app instalada en `/Applications/` se llama `Wips.app` (DISPLAY_NAME, copiada así desde el DMG).

**En `release.yml`:**
- DMG: `cp -R "$RUNNER_TEMP/export/$PRODUCT_NAME.app" "$RUNNER_TEMP/dmg-content/$DISPLAY_NAME.app"` → crea `Wips.app`
- Sparkle zip: `ditto -c -k --keepParent "$RUNNER_TEMP/export/$PRODUCT_NAME.app"` → contiene `issue.app`

Cuando Sparkle extrae el zip, encuentra `issue.app` pero necesita reemplazar `/Applications/Wips.app`. Aunque Sparkle matchea por bundle ID, el nombre distinto del .app bundle puede causar que el `Installer.xpc` falle al hacer el reemplazo del archivo.

**Evidencia:**
- `zipinfo` del zip v1.2.7 confirma: raíz es `issue.app/`
- `/Applications/Wips.app` confirmado como ubicación de instalación
- `CFBundleName = issue`, `CFBundleIdentifier = com.gastonfoncea.wips`

### 2. Re-signing incompleto de componentes Sparkle

El paso de re-sign en CI solo matchea `*.framework`, `*.dylib`, `*.xpc`:
```bash
find ... -depth \( -name "*.framework" -o -name "*.dylib" -o -name "*.xpc" \)
```

Esto NO incluye `Updater.app` dentro de `Sparkle.framework/Versions/B/Updater.app/`, que es la UI que muestra el progreso del update. Aunque actualmente pasa `codesign --verify --deep --strict`, agregar `*.app` al patrón es más robusto.

### 3. Sin logging de errores

`SPUStandardUpdaterController` se inicializa con `updaterDelegate: nil` y `userDriverDelegate: nil`. No hay forma de saber qué error exacto reporta Sparkle.

## Plan de implementación

### Paso 1: Fix del zip en `release.yml`

**Archivo:** `.github/workflows/release.yml` (líneas 158-160)

Cambiar el paso "Create Sparkle zip (post-staple)" para usar el DISPLAY_NAME:

```yaml
- name: Create Sparkle zip (post-staple)
  run: |
    # Copy app with display name (matches DMG distribution)
    mkdir -p "$RUNNER_TEMP/sparkle-staging"
    cp -R "$RUNNER_TEMP/export/$PRODUCT_NAME.app" "$RUNNER_TEMP/sparkle-staging/$DISPLAY_NAME.app"
    ditto -c -k --keepParent "$RUNNER_TEMP/sparkle-staging/$DISPLAY_NAME.app" "$RUNNER_TEMP/$DISPLAY_NAME.zip"
```

Esto asegura que el zip contenga `Wips.app/` — el mismo nombre que el usuario tiene instalado.

### Paso 2: Fix del re-signing para incluir .app bundles

**Archivo:** `.github/workflows/release.yml` (líneas 104-110)

Agregar `-o -name "*.app"` al patrón de find:

```bash
find "$RUNNER_TEMP/export/$PRODUCT_NAME.app/Contents/Frameworks" \
  -depth \( -name "*.framework" -o -name "*.dylib" -o -name "*.xpc" -o -name "*.app" \) | while read item; do
```

### Paso 3: Agregar SPUUpdaterDelegate para logging

**Archivo:** `issue/App/issueApp.swift`

Crear una clase `SparkleDelegate` que implemente `SPUUpdaterDelegate` para capturar errores:

```swift
final class SparkleDelegate: NSObject, SPUUpdaterDelegate {
    func updater(_ updater: SPUUpdater, didAbortWithError error: Error) {
        print("[Sparkle] Update aborted: \(error.localizedDescription)")
    }

    func updater(_ updater: SPUUpdater, didFinishLoadingAppcast appcast: SUAppcast) {
        print("[Sparkle] Appcast loaded, \(appcast.items.count) items")
    }
}
```

Usar en `issueApp`:
```swift
private let sparkleDelegate = SparkleDelegate()
private let updaterController: SPUStandardUpdaterController

init() {
    updaterController = SPUStandardUpdaterController(
        startingUpdater: true,
        updaterDelegate: sparkleDelegate,
        userDriverDelegate: nil
    )
    // ... resto del init
}
```

## Archivos a modificar

1. `.github/workflows/release.yml` — fix zip name + fix re-sign patterns
2. `issue/App/issueApp.swift` — agregar SparkleDelegate para logging

## Verificación

1. **Local**: Correr la app desde `/Applications/` y buscar actualizaciones. Verificar en Console.app los logs `[Sparkle]` para ver errores detallados.
2. **CI**: Hacer un release de prueba (bump version a 1.2.8, push tag `v1.2.8`). Verificar que:
   - `zipinfo` del nuevo zip muestre `Wips.app/` como raíz (no `issue.app/`)
   - La app instalada pueda detectar y descargar el update
   - El update se instale correctamente
3. **Appcast**: Verificar que el nuevo item en appcast.xml apunte al zip correcto.

## Nota sobre el appcast existente

Los releases anteriores (v1.0 a v1.2.7) tienen zips con `issue.app`. Usuarios en esas versiones necesitarán este fix para poder actualizar. Una vez que se publique v1.2.8 con el fix, los nuevos updates funcionarán. Los usuarios que ya están en 1.2.7 y no pueden actualizar deberán instalar manualmente una vez más vía DMG.
